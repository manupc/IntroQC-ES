"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""


from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
from qiskit_aer import AerSimulator
import numpy as np

# Tam. del registro a sumar
register_size= 4

# Registros cuanticos para almacenar X, Y y Z
qrX= QuantumRegister(size=register_size, name='qX')
qrY= QuantumRegister(size=register_size, name='qY')
qrZ= QuantumRegister(size=register_size, name='qZ')

# Registro cuantico de acarreo
qrCarry= QuantumRegister(size=1, name='qCarry')

# Registro clasico de salida
cOutput= ClassicalRegister(size=register_size+1, name='cOutput')


# Circuito modular: Sumador de 1 qubit
def SingleQubitAdder():
    
    # Operacion CCCNOT
    CCCNOT_001= XGate().control(num_ctrl_qubits=3, ctrl_state='001'[::-1])
    CCCNOT_110= XGate().control(num_ctrl_qubits=3, ctrl_state='110'[::-1])
    
    # Asignacion de qubits:
    #  q0: q_x; q1: q_y; q2: q_c; q3: q_z
    adder= QuantumCircuit(4, name='Adder')
    
    # Calculo de qz= q_x+q_y+q_c
    adder.cx(0, 3)
    adder.cx(1, 3)
    adder.cx(2, 3)
    
    # Actualizacion de CARRY
    adder.append(CCCNOT_001, [0, 1, 3, 2])
    adder.append(CCCNOT_110, [0, 1, 3, 2])
    return adder.to_instruction()
    

# Circuito cuantico sumador de dos registros de 4 qubits
qc= QuantumCircuit(qrX, qrY, qrZ, qrCarry, cOutput)

# Entrada de datos
X= ParameterVector('X', register_size)
Y= ParameterVector('Y', register_size)

for i in range(register_size):
    qc.rx(theta= X[i]*np.pi, qubit= qrX[i])
    qc.rx(theta= Y[i]*np.pi, qubit= qrY[i])

# Sumador
qc_adder= SingleQubitAdder()
for i in range(register_size):
    qc.append(qc_adder, [qrX[i], qrY[i], qrCarry[0], qrZ[i]])
qc.measure(qrZ[0:register_size]+[qrCarry[0]], cOutput)


# Preparacion de circuitos con entradas de datos
sim= AerSimulator()
qcs= []
results= {}
for x_number in range(2**register_size):
    bin_x= bin(x_number)[2:].rjust(register_size, '0')
        
    for y_number in range(2**register_size):
        bin_y= bin(y_number)[2:].rjust(register_size, '0')
        qcp= qc.assign_parameters( {X : [int(v) for v in bin_x[::-1]], 
                                    Y : [int(v) for v in bin_y[::-1]]})
        qcs.append(transpile(qcp, sim))
        if bin_x not in results:
            results[bin_x]= {}
        results[bin_x][bin_y]= [qcp, 0]


# Simulacion
r= sim.run(qcs, shots=1).result()
for bin_x in results:
    for bin_y in results[bin_x]:
        qcp= results[bin_x][bin_y][0]
        results[bin_x][bin_y][1]= list(r.get_counts(qcp).keys())[0]


# Mostrar resultados
sumas_ok= 0
for bin_x in results:
    for bin_y in results[bin_x]:
        bin_o= results[bin_x][bin_y][1]
        int_x, int_y, int_o= int(bin_x, 2), int(bin_y, 2), int(bin_o, 2)
        if int_x+int_y == int_o:
            sumas_ok+= 1
        print('{} + {} =  {}'.format(bin_x, bin_y, bin_o))

print('Total de sumas bien realizadas: {} / {}'.format(sumas_ok, 2**(2*register_size)))
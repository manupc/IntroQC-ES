"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np

# Circuito de la alternativa 1 con |q0q1>=|00>
qc_1= QuantumCircuit(3)
qc_1.cx(control_qubit= 0, target_qubit= 2)
qc_1.ccx(control_qubit1= 0, control_qubit2= 1, target_qubit= 2, ctrl_state='00')
qc_1.save_unitary()


# Circuito de la alternativa 2 con |q0q1>=|00>
qc_aux= QuantumCircuit(3)
qc_aux.cx(control_qubit= 0, target_qubit= 2)
qc_aux.cx(control_qubit= 1, target_qubit= 2, ctrl_state='0')
qc_aux.ccx(control_qubit1= 0, control_qubit2= 1, target_qubit= 2, ctrl_state='10'[::-1])

qc_2= qc_aux.copy()
qc_2.save_unitary()


sim= AerSimulator()
r= sim.run([transpile(qc_1), transpile(qc_2)], shots= 1).result()
U_1= r.get_unitary(qc_1)
U_2= r.get_unitary(qc_2)

print('Matriz unitaria de la alternativa 1:')
print(np.asarray(np.real(U_1)).astype(int))
print('\nMatriz unitaria de la alternativa 2:')
print(np.asarray(np.real(U_2)).astype(int))

print('\nLas matrices de las alternativas son iguales: ', np.all(U_1==U_2))


# Ejemplo para la entrada |q0q1> = |11>
qc_input= QuantumCircuit(3)
qc_input.x([0, 1])

qc= qc_input.compose(qc_aux)
qc.measure_all()

r= sim.run(qc, shots= 1024).result()
counts= list( r.get_counts(qc).keys() )
print('\nEjemplo para la entrada |q0q1> = |11>')
print('Medicion realizada: ', counts)

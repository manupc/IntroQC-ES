"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from time import sleep

# Funcion de seleccion de acciones
def SeleccionarAccion(s_t):
    if s_t == 36: # Casilla (3,0)
        return 0
    elif s_t== 35: # Casilla (2,11)
        return 2
    else: # Casillas (2,0)-(2,10)
        return 1
    return None


render= False # Cambiar a True para visualizar con metodo render()
env= gym.make('CliffWalking-v1', render_mode='human' if render else None) # Crear entorno de simulacion

s, info= env.reset() # Inicializacion del entorno
if render:
    sleep(0.01)
    env.render() # Visualizacion grafica

# Ejemplo de interaccion personaje-entorno en 10 iteraciones
R_T= 0 # Recompensa total obtenida
terminated, truncated= False, False
while not (terminated or truncated):
    
    s_t= s # Actualizar estado actual
    a_t= SeleccionarAccion(s_t) # Seleccion de accion a realizar
    
    # Ejecucion de accion y cambio del entorno
    s, r, terminated, truncated, info= env.step( a_t )
    R_T+= r # Actualizar recompensa total
    
    if render:
        sleep(0.01)
        env.render()

print('Recompensa total obtenida: R(T)={}'.format(R_T))
print('Problema resuelto: {}'.format(terminated))

if render:
    print('Presione una tecla para continuar...')
    _= input()
    env.close()

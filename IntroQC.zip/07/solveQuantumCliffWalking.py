"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
from qiskit_aer import AerSimulator
import numpy as np


# Creacion de registros cuanticos
qrF= QuantumRegister(size=1, name='qF')
qrC= QuantumRegister(size=3, name='qC')
qrA= QuantumRegister(size=3, name='qA')
crA= ClassicalRegister(size=3, name='cA')

# Parametros de entrada
paramF= ParameterVector(name='f', length=1)
paramC= ParameterVector(name='c', length=3)


# Circuito de codificacion y toma de decisiones
qc= QuantumCircuit(qrF, qrC, qrA, crA)

# Codificacion de datos
qc.rx(paramF[0]*np.pi, qrF[0])
for i in range(3):
    qc.rx(paramC[i]*np.pi, qrC[i])

# Regla R1
qc.cx(qrF[0], qrA[0])

# Regla R2
CCCNOT= XGate().control(num_ctrl_qubits=3)
qc.append(CCCNOT, [qrC[0], qrC[1], qrC[2], qrA[2]])

# Regla R3
qc.ccx(qrA[0], qrA[2], qrA[1], ctrl_state='00')

# Medicion 
qc.measure(qrA, crA)


sim= AerSimulator()

# Funcion de seleccion de acciones
def SeleccionarAccion(s_t):
    
    # Pasamos s a (f,c) en binario
    f_bin= bin(s_t//12)[2:][::-1].rjust(2, '0')
    c_bin= bin(s_t%12)[2:][::-1].rjust(4, '0')
    c_bin= [c_bin[0], c_bin[1], c_bin[3]]

    # codificacion de entradas al circuito
    qc_par= transpile(qc.assign_parameters( {paramF: [int(f_bin[0])],
                                             paramC: [int(x) for x in c_bin]
                                            } ), sim)
    
    # Simulacion
    counts= sim.run(qc_par, shots= 1).result().get_counts(qc_par)
    ket= list(counts.keys())[0][::-1] # '100', '010', '001'
    a_t= ket.find('1') # Obtener posicion 0, 1, 2 donde se encuentra '1'
    return a_t


# Simulacion en el entorno
env= gym.make('CliffWalking-v1') # Crear entorno de simulacion

s, info= env.reset() # Inicializacion del entorno

# Ejemplo de interaccion personaje-entorno en 10 iteraciones
R_T= 0 # Recompensa total obtenida
terminated, truncated= False, False
while not (terminated or truncated):
    
    s_t= s # Actualizar estado actual
    a_t= SeleccionarAccion(s_t) # Seleccion de accion a realizar
    
    # Ejecucion de accion y cambio del entorno
    s, r, terminated, truncated, info= env.step( a_t )
    R_T+= r # Actualizar recompensa total
    

print('Recompensa total obtenida: R(T)={}'.format(R_T))
print('Problema resuelto: {}'.format(terminated))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym

# Listado de acciones a ejecutar
lista_acciones= [0, 1, 2, 0, 3, 0]


# Creacion del entorno de simulacion para CliffWalking-v0
env= gym.make('CliffWalking-v1')

# Ejemplo de llamada al metodo reset
s, info= env.reset()
print('Inicio de simulacion. Casilla: {} -> ({}, {})'.format(s, s//12, s % 12))

# Ejemplo de interaccion personaje-entorno en 10 iteraciones
R_T= 0 # Recompensa total obtenida
t= 0
while lista_acciones:
    
    # Seleccion de accion a realizar
    s_t= s
    a_t= lista_acciones.pop(0)
    
    print('Iteracion t={}'.format(t))
    print('\tEstoy en la casilla: s(t)={} -> ({}, {})'.format(s_t, s_t//12, s_t % 12))
    print('\tSelecciono accion: a(t)={}'.format(a_t))

    # Ejecucion de accion y cambio del entorno
    s, r, terminated, truncated, info= env.step( a_t )
    R_T+= r # Actualizar recompensa total
    print('\tEllo hace que obtenga r(t+1)={} y me mueva a s(t+1)={}'.format(r, s))
    print('\tEl calculo de R(T) actual es R(T)={}'.format(R_T))
    
    t= t+1 # Paso a la siguiente iteracion

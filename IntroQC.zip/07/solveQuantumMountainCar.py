"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
import numpy as np



# Creacion de registros cuanticos
qrPos= QuantumRegister(size=1, name='qPos')
qrVel= QuantumRegister(size=1, name='qVel')
qrA= QuantumRegister(size=3, name='qA')
crA= ClassicalRegister(size=3, name='cA')

# Parametros de entrada
paramPos= Parameter(name='Pos')
paramVel= Parameter(name='Vel')


# Circuito de codificacion y toma de decisiones
qc= QuantumCircuit(qrPos, qrVel, qrA, crA)

# Codificacion de datos
qc.rx(paramPos, qrPos[0])
qc.rx(paramVel, qrVel[0])

# Regla R1
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[2])

# Regla R2
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[1], ctrl_state='0')

# Regla R3
qc.cx(control_qubit=qrPos[0], target_qubit=qrA[1])

# Regla R4
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[0], ctrl_state='0')


# Medicion 
qc.measure(qrA, crA)
sim= AerSimulator()

# Funcion de seleccion de acciones
def SeleccionarAccion(s_t):
    
    posMinMax= [-1.2, 0.6]
    velMinMax= [-0.07, 0.07]
    
    # Transformacion de posicion y velocidad a angulos
    angle_pos= np.pi*(s_t[0] - posMinMax[0])/(posMinMax[1] - posMinMax[0])
    angle_vel= np.pi*(s_t[1] - velMinMax[0])/(velMinMax[1] - velMinMax[0])
    
    
    # codificacion de entradas al circuito
    qc_par= transpile(qc.assign_parameters( {paramPos: angle_pos,
                                             paramVel: angle_vel
                                            } ), sim)
    
    # Simulacion
    counts= sim.run(qc_par, shots= 50).result().get_counts(qc_par)
    action_counts= [0, 0, 0]
    for ket in counts:
        if ket[::-1] == '100': # qL=1, qN= 0, qR=0
            action_counts[0]= counts[ket]
        elif ket[::-1] == '010':  # qL=0, qN= 1, qR=0
            action_counts[1]= counts[ket]
        elif ket[::-1] == '001':  # qL=0, qN= 0, qR=1
            action_counts[2]= counts[ket]
            
    a_t= np.argmax(action_counts) # a(t)= accion con mayor probabilidad de |1>
    return a_t


# Simulacion en el entorno
env= gym.make('MountainCar-v0') # Crear entorno de simulacion
s, info= env.reset() # Inicializacion del entorno

# Ejemplo de interaccion personaje-entorno en 10 iteraciones
R_T= 0 # Recompensa total obtenida
terminated, truncated= False, False
while not (terminated or truncated):
    
    s_t= s # Actualizar estado actual
    a_t= SeleccionarAccion(s_t) # Seleccion de accion a realizar
    
    # Ejecucion de accion y cambio del entorno
    s, r, terminated, truncated, info= env.step( a_t )
    R_T+= r # Actualizar recompensa total
    

print('Recompensa total obtenida: R(T)={}'.format(R_T))
print('Hemos llegado al destino: {}'.format(terminated))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
import numpy as np


# Creacion de registros cuanticos
qrAngle= QuantumRegister(size=1, name='qAngle')
qrAngleVel= QuantumRegister(size=1, name='qAngleVel')
qrA= QuantumRegister(size=2, name='qA')
crA= ClassicalRegister(size=2, name='cA')

# Parametros de entrada
paramAngle= Parameter(name='Angle')
paramAngleVel= Parameter(name='AngleVel')


# Circuito de codificacion y toma de decisiones
qc= QuantumCircuit(qrAngle, qrAngleVel, qrA, crA)

# Codificacion de datos
qc.rx(paramAngle, qrAngle[0])
qc.rx(paramAngleVel, qrAngleVel[0])

# Regla R1
qc.cx(qrAngle[0], qrA[1])

# Regla R2
qc.cx(qrAngleVel[0], qrA[0], ctrl_state='0')


# Medicion 
qc.measure(qrA, crA)
sim= AerSimulator()

# Funcion de seleccion de acciones
def SeleccionarAccion(s_t):
    
    angle_bounds= 0.419
    angle= (s_t[2] + angle_bounds)/angle_bounds*np.pi*0.5
    angle_vel= np.arctan(s_t[3])+0.5*np.pi
    

    # codificacion de entradas al circuito
    qc_par= transpile(qc.assign_parameters( {paramAngle: angle,
                                             paramAngleVel: angle_vel
                                            } ), sim)
    
    # Simulacion
    counts= sim.run(qc_par, shots= 50).result().get_counts(qc_par)
    action_counts= [0,0]
    for ket in counts:
        if ket[::-1] == '10': # qL=1, qR=0
            action_counts[0]= counts[ket]
        elif ket[::-1] == '01':  # qL=0, qR=1
            action_counts[1]= counts[ket]
            
    a_t= np.argmax(action_counts) # a(t)= accion con mayor probabilidad de |1>
    return a_t


# Simulacion en el entorno
env= gym.make('CartPole-v1') # Crear entorno de simulacion
s, info= env.reset() # Inicializacion del entorno

# Ejemplo de interaccion personaje-entorno en 10 iteraciones
R_T= 0 # Recompensa total obtenida
terminated, truncated= False, False
while not (terminated or truncated):
    
    s_t= s # Actualizar estado actual
    a_t= SeleccionarAccion(s_t) # Seleccion de accion a realizar
    
    # Ejecucion de accion y cambio del entorno
    s, r, terminated, truncated, info= env.step( a_t )
    R_T+= r # Actualizar recompensa total
    

print('Recompensa total obtenida: R(T)={}'.format(R_T))
print('El poste ha caido: {}'.format(terminated))


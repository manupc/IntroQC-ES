"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Funcion para resolver el problema del camarero. Tiene como entrada los tiempos
# de atencion de cada cliente. Como salida, devuelve una lista L donde L[i]
# contiene el cliente que se debe despachar en i-esimo lugar
def adhoc_optimizer(t : np.ndarray):
    
    x= np.argsort(t)
    return x


# Procedimiento para implementar la funcion de coste. Tiene como entrada
# la solucion x y la descripcion t del problema con los tiempos de cada cliente.
# Como salida, devuelve un valor escalar con la funcion del coste
def f(x : np.ndarray, t : np.ndarray):
    
    n= len(x)  # Numero de clientes
    fx= 0 # Valor de la funcion de coste
    for i in range(1, n+1):
        fx+= np.sum(t[ x[:i] ])
    return fx


# Caso de n=3 clientes. Tiempos de cada cliente.
t= np.array([7, 1, 4])

# Llamada al algoritmo de optimizacion
x= adhoc_optimizer(t)
fx= f(x, t) # Calcular funcion de coste


# Mostrar solucion 
print('Numeracion de {} clientes: {} con tiempos t={}'.format(len(x), list(range(len(x))), t))
print('Atender a los clientes en orden x={}, con f(x)={}'.format(x, fx))


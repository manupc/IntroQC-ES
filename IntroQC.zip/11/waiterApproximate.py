"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np


# Algoritmo de enfriamiento simulado. Necesita:
#   x_init: Solucion inicial valida al problema
#   cost_f: Funcion de costo cost_f(x)
#   neighbor_f: Funcion de generacion de vecino neighbor_f(x)
#   T_init: Temperatura inicial
#   T_factor: Factor multiplicativo de enfriamiento de la temperatura
#   max_iter: Maximo de iteraciones del algoritmo sin mejora de la mejor solucion
# Devuelve una solucion x al problema (np.ndarray)
def SA_optimizer(x_init : np.ndarray, cost_f : callable, 
                 neighbor_f : callable, T_init : float, T_factor : float, 
                 max_iter : int):
    
    # Inicializacion de parametros
    T= T_init # Temperatura
    x, fx= x_init.copy() , cost_f(x_init) # Solucion actual y coste
    bx, fbx = x.copy(), fx # Mejor solucion encontrada hasta el momento y coste
    
    iter_count= 0 # Contador de numero de iteraciones del algoritmo sin mejora de bx
    while iter_count < max_iter: # Bucle principal
    
        update= False # Para comprobar si hemos actualizado la mejor solucion
    
        # Generar una solucion vecina
        xp= neighbor_f(x) 
        fxp = cost_f(xp)
        
        # Decision sobre la aceptacion de la solucion generada
        f_diff= fxp - fx
        
        # Si la nueva solucion es mejor, la aceptamos siempre.
        # Si es peor, la aceptamos con una probabilidad decreciente (Criterio de Metropolis).
        if f_diff < 0 or np.random.uniform() < np.exp(-f_diff / T):
            x, fx = xp, fxp
            
            # Actualizamos la mejor solucion encontrada hasta ahora si es necesario
            if fx < fbx:
                bx, fbx = x.copy(), fx
                update= True

        # Reiniciamos el contador de iteraciones porque hemos mejorado
        # o lo actualizamos si no es asi
        iter_count= 0 if update else iter_count+1
            
        # Enfriamiento del sistema r el sistema
        T*= T_factor

    return bx



# Procedimiento para implementar la funcion de coste. Tiene como entrada
# la solucion x y la descripcion t del problema con los tiempos de cada cliente.
# Como salida, devuelve un valor escalar con la funcion del coste
def f(x : np.ndarray, t : np.ndarray):
    
    n= len(x)  # Numero de clientes
    fx= 0 # Valor de la funcion de coste
    for i in range(1, n+1):
        fx+= np.sum(t[ x[:i] ])
    return fx


# Funcion para devolver una solucion vecina a la solucion x
# Genera una permutacion de la solucion x intercambiando dos de sus elementos
def neighbour_generator(x : np.array):
    pos= np.random.randint(low=0, high=len(x), size=2)
    x_prime= x.copy()
    x_prime[pos[0]]= x[pos[1]]
    x_prime[pos[1]]= x[pos[0]]
    return x_prime


# Caso de n=3 clientes. Tiempos de cada cliente.
t= np.array([7, 1, 4])


# Funcion de coste como lambda para ajustar la funcion f al formato del solver
cost_f= lambda x: f(x, t)

n= len(t) # Numero de variables

# Solucion inicial: [0, 1, 2, ..., n-1]
x_init= np.array(list(range(n)), dtype=int)

# Parametros del algoritmo
T_init= 200 # Temperatura inicial
T_factor= 0.9 # Factor de enfriamiento
max_iter= 10

# Llamada al algoritmo de optimizacion
x= SA_optimizer(x_init, cost_f, neighbour_generator, T_init, T_factor, max_iter)

fx= f(x, t) # Calcular funcion de coste


# Mostrar solucion 
print('Numeracion de {} clientes: {} con tiempos t={}'.format(len(x), list(range(len(x))), t))
print('Atender a los clientes en orden x={}, con f(x)={}'.format(x, fx))


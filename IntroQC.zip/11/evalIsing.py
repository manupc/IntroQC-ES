"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getMaxCutProblem, getVertexCoverProblem, getGraphColoringProblem
from OptimizationTools import energy_classic, energy_hamiltonian, IsingToPauli, IsingHamiltonian

problems= {
    'MaxCut'        : lambda M : getMaxCutProblem(M),
    'VertexCover'   : lambda M : getVertexCoverProblem(M, P=1),
    'GraphColoring' : lambda M : getGraphColoringProblem(M, K=2, P1=1, P2=1)
    }


# Matriz de adyacencia del grafo
M= np.array([[0 , 1 , 1],
             [1 , 0 , 0],
             [1, 0 , 0]])

print('Representacion inicial del problema con la matriz de adyacencia:')
print(M)


for problem in problems:
    
    # Creamos modelo teorico
    print('\nResolucion del problema de {}'.format(problem))
    print('-'*50, '\n')
    z, model= problems[problem](M)
    
    # Pasamos a Ising
    ising= model.to_ising()
    
    # Construimos secuencia de operadores de Pauli
    pauli= IsingToPauli(z, ising)
    
    # Generamos matriz H del hamiltoniano
    H= IsingHamiltonian(pauli)
    
    # Evaluamos todas las posibles soluciones
    n= np.prod(z.shape) # Numero total de combinaciones
    for x in range(2**n):
        
        # pasamos x a binario
        x_bin= np.array([int(xi) for xi in bin(x)[2:].rjust(n, '0')])
        
        cost_classic= energy_classic(x_bin, pauli)
        cost_hamiltonian= energy_hamiltonian(x, H)
        print('\tLa solucion x={} tiene coste {} con evaluacion clasica y coste {} con evaluacion con hamiltoniano'.format(x_bin, cost_classic, cost_hamiltonian))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from itertools import product


# Algoritmo exacto por fuerza bruta para encontrar 
# la solucion optima a un problema de optimizacion (minimizacion)
# Como entrada necesita el numero de variables del problema (n), una lista D de
# n listas con los valores posibles de cada variable, una funcion
# constraints_f(x) booleana para verificar que una solucion x al problema cumple
# con las restricciones del mismo (devuelve True) o no (devuelve False), 
# y una funcion de coste cost_f(x) que devuelve el coste de una solucion
# Como salida, devuelve una solucion x optima al problema (np.ndarray)
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx= None # Inicializacion de la solucion optima
    fbx= np.inf # Coste de la solucion optima
    
    all_solutions_generator= product(*D) # Generador de todas las posibles soluciones
    for x in all_solutions_generator:
        
        x= np.array(x)
        
        # Comprobar si x cumple las restricciones
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx= cost_f(x) # Calcular coste de la solucion
        if fx < fbx: # Actualizamos mejor solucion encontrada
            bx, fbx= x, fx
    return np.array(bx)


# Procedimiento para implementar la funcion de coste. Tiene como entrada
# la solucion x y la descripcion t del problema con los tiempos de cada cliente.
# Como salida, devuelve un valor escalar con la funcion del coste
def f(x : np.ndarray, t : np.ndarray):
    
    n= len(x)  # Numero de clientes
    fx= 0 # Valor de la funcion de coste
    for i in range(1, n+1):
        fx+= np.sum(t[ x[:i] ])
    return fx


# Funcion para comprobar si una solucion x cumple las restricciones del problema
# del camarero. Devuelve True si es asi, y False en otro caso
def check_constraints(x : np.array):
    return len(np.unique(x)) == len(x) # Comprueba que no hay elementos repetidos en x


# Caso de n=3 clientes. Tiempos de cada cliente.
t= np.array([7, 1, 4])


# Funcion de coste como lambda para ajustar la funcion f al formato del solver
cost_f= lambda x: f(x, t)

n= len(t) # Numero de variables
D= [list(range(n))]*n # Dominio de cada variable

# Llamada al algoritmo de optimizacion
x= exact_optimizer(n, D, check_constraints, cost_f)

fx= f(x, t) # Calcular funcion de coste


# Mostrar solucion 
print('Numeracion de {} clientes: {} con tiempos t={}'.format(len(x), list(range(len(x))), t))
print('Atender a los clientes en orden x={}, con f(x)={}'.format(x, fx))


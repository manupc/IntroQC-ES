"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getVertexCoverProblem, ProblemCircuit, IsingToPauli, IsingHamiltonian
from qiskit import transpile
from qiskit_aer import AerSimulator
from IPython.display import display
from scipy.linalg import expm

# Matriz de adyacencia del grafo
M= np.array([[0 , 1 , 1, 1],
             [1 , 0 , 0, 0],
             [1 , 0 , 0, 0],
             [1 , 0 , 0, 0]])

print('Representacion inicial del problema con la matriz de adyacencia:')
print(M)

# Creacion del modelo Ising
P= 1 # Factor de penalizacion 
z, model= getVertexCoverProblem(M, P)
ising= model.to_ising()

# Transformar modelo Ising a secuencia de operadores de Pauli
pauli= IsingToPauli(z, ising)

# Creacion del circuito del exponencial del hamiltoniano con valor t prefijado
t= 1
qc= ProblemCircuit(pauli, t, reverse_ops=True)
qc.save_unitary()

# Mostramos el circuito graficamente
f=qc.draw('mpl')
display(f)

# Simulacion del circuito para obtener la matriz unitarya
sim= AerSimulator()
n_shots= 1
U= sim.run(transpile(qc, sim), shots=n_shots).result().get_unitary()
U= U.data

# Calculamos exponencial de H manualmente
H= IsingHamiltonian(pauli)
expH= expm(-1.j*t*H)

# Obtenemos factor de escala entre matrices 
# desde la coordenada superior izquierda de ambas
factor= np.diag(U)[0] / np.diag(expH)[0] 

# Multiplicamos el exponencial calculado manualmente por el factor,
# Para comparar ambas matrices
expH*= factor

# Comparamos ambas matrices
if np.all(np.isclose(expH, U.data)):
    print('La matriz del circuito es igual a exp(H) con factor= {}'.format(factor))
else:
    print('La matriz del circuito no es igual a exp(H)')


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import exact_optimizer


# Definicion de la matriz de adyacencia del problema
M= np.array([[0, 1, 0, 0, 0, 0],
             [1, 0, 0, 0, 1, 0],
             [0, 0, 0, 0, 1, 0],
             [0, 0, 0, 0, 0, 1],
             [0, 1, 1, 0, 0, 1],
             [0, 0, 0, 1, 1, 0]
            ], dtype= int)

print('Matriz de adyacencia del problema:')
print(M)


# Procedimiento para implementar la funcion de coste. Devuelve valor constante
def f(x : np.ndarray):
    return 0


# Funcion para comprobar que una solucion x de entrada cumple con las restricciones
# impuestas por el problema dadas por la matriz de adyacencia M
# Devuelve True si x cumple con las restricciones y False en otro caso
def is_valid(x : np.ndarray, M : np.ndarray):
    
    n= len(x) # Numero de variables
    
    # Recorremos cada arista e_ij del grafo
    for i in range(n):
        for j in range(i+1, n):
            if M[i][j]>0:
                # Comprobamos que dos nodos adyacentes tienen el mismo color
                if x[i] == x[j]:
                    return False # La solucion no es valida
    return True # No existen dos nodos adyacentes con el mismo color

# Adaptacion de la funcion is_valid al formato requerido por el optimizador
check_constraints= lambda x : is_valid(x, M)

K= 2 # Numero de coloresa usar
n= len(M) # Numero de variables del problema
D= [ list(range(K)) ]*n # Dominio de cada variable

# Llamada al algoritmo de optimizacion
x= exact_optimizer(n, D, check_constraints, f)

fx= f(x) # Calcular funcion de coste

# Mostrar solucion 
print('Solucion x={}, con f(x)={}'.format(x, fx))


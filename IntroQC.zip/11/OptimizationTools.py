"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import re
from pyqubo import Array, DecodedSample
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit.quantum_info import SparsePauliOp
from itertools import product


###########################################################
# METODO DE FUERZA BRUTA 
###########################################################


# Algoritmo exacto por fuerza bruta para encontrar 
# la solucion optima a un problema de optimizacion (minimizacion)
# Como entrada necesita el numero de variables del problema (n), una lista D de
# n listas con los valores posibles de cada variable, una funcion
# constraints_f(x) booleana para verificar que una solucion x al problema cumple
# con las restricciones del mismo (devuelve True) o no (devuelve False), 
# y una funcion de coste cost_f(x) que devuelve el coste de una solucion
# Como salida, devuelve una solucion x optima al problema (np.ndarray)
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx= None # Inicializacion de la solucion optima
    fbx= np.inf # Coste de la solucion optima
    
    all_solutions_generator= product(*D) # Generador de todas las posibles soluciones
    for x in all_solutions_generator:
        
        x= np.array(x)
        
        # Comprobar si x cumple las restricciones
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx= cost_f(x) # Calcular coste de la solucion
        if fx < fbx: # Actualizamos mejor solucion encontrada
            bx, fbx= x, fx
    return np.array(bx)



###########################################################
# UTILIDADES 
###########################################################



# A partir de una solucion de un solver dada como entrada
# y de un conjunto de variables z sobre el que se contruye la solucion,
# la funcion devuelve un array Numpy indexado como z, cuyos valores
# se corresponden con los encontrados por el solver (valor), asi como el valor
# de la energia de la solucion
def sampledSolutionToNumPy(solution : DecodedSample, z: Array):
    
    # Obtenemos valor de e(z)
    sol_cost= solution.energy

    # Obtenemos los indices de las soluciones en z
    indices= [list(range(i)) for i in z.shape]
    
    z_idx= list(product(*indices))
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    # Generamos la solucion final numpy
    npsol= np.zeros(z.shape, dtype=int)
    
    # Asignamos cada componente de npsol a su valor de solucion
    for idx in z_idx:
        val= solution.array('z', tuple(idx))
        npsol[*idx]= val
    return npsol, sol_cost


# Para un Array z de PyQUBO, la funcion genera un diccionario 
# con los nombres de variables (clave) y un indice unico (valor entero)
def getVarIndices(z : Array):
    
    # Obtenemos todos los indices de las soluciones en z
    indices= [list(range(i)) for i in z.shape]
    z_idx= list(product(*indices)) 
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    var_ind= {} # Generamos diccionario (nombre de variable : indice entero)
    for i, ind in enumerate(z_idx):
        
        # Elimina prefijo Spin(' y postfijo ')
        name= str(z[tuple(ind.tolist())])[6:-2]
        var_ind[name]= i # Asignamos nombre de variable a indice
    return var_ind

    


###########################################################
# FORMULACION DE PROBLEMAS
###########################################################


# Dada una matriz de adyacencia de un grafo como entrada, la funcion
# devuelve las variables y el modelo compilado de formulacion de un problema de Max-Cut
def getMaxCutProblem(M : np.ndarray):

    # Creacion de variables para el modelo Ising
    n= len(M) # No. de variables
    z = Array.create('z', shape=(n,), vartype='SPIN')
    
    Ising= 0 # Modelo Ising
    # Calculamos formulacion del problema
    for i in range(M.shape[0]):
        for j in range(i+1, M.shape[1]):
            if M[i,j] != 0:
                Ising+= z[i]*z[j] # Modelo Ising, arista (vi, vj)
    
    # Creamos modelo teorico Ising
    model= Ising.compile()
    return z, model


# Dada una matriz de adyacencia de un grafo como entrada, la funcion
# devuelve las variables y el modelo compilado de formulacion de un problema de Vertex Cover
# El parametro opcional P es un escalar con la penalizacion a incluir
def getVertexCoverProblem(M : np.ndarray, P : float = 20):

    # Creacion de variables para el modelo Ising
    n= len(M) # No. de variables
    z = Array.create('z', shape=(n,), vartype='SPIN')

    Ising= 0 # Modelo Ising

    # Funcion de coste
    for i in range(n):
        Ising+= z[i]
        
    # Incluimos penalizaciones
    for i in range(n):
        for j in range(i+1, n):
            if M[i,j] != 0: # Penalizar exclusion de arista (vi, vj)
                Ising+= P*(1-z[i])*(1-z[j])

    # Creamos modelo teorico Ising
    model= Ising.compile()
    return z, model


# Dada una matriz de adyacencia de un grafo como entrada, la funcion
# devuelve las variables y el modelo compilado de formulacion de un
# problema de decision de coloreo de un grafo.
# El parametro K incluye el numero de colores maximo a usar
# P1 penaliza varios colores a un nodo, y P2 penaliza nodos adyacentes con mismo color
def getGraphColoringProblem(M : np.ndarray, K : int = 2, P1 : float = 2, P2 : float = 1):

    # Creacion de variables para el modelo Ising
    n= len(M) # No. de vertices
    z = Array.create('z', shape=(n,K), vartype='SPIN')
    
    Ising= 0 # Modelo Ising
        
    # Restriccion 1: Un nodo solo puede tener un color
    for i in range(n):
        Ising_aux=0
        for k in range(K):
            Ising_aux+= z[i][k]
        Ising_aux= (K-2+Ising_aux)**2
        Ising+= P1 * Ising_aux
    
    # Restriccion 2: Dos nodos adyacentes con color distinto
    for i in range(n):
        for j in range(i+1, n):
            if M[i,j]!= 0:
                Ising_aux= 0
                for k in range(K):
                    Ising_aux+= z[i][k]*z[j][k]
                Ising+= P2 * Ising_aux

    # Creamos modelo teorico Ising
    model= Ising.compile()
    return z, model



###########################################################
# EVALUACION DE PROBLEMAS 
###########################################################

# Transforma un modelo Ising a una secuencia de operadores de Pauli
def IsingToPauli(z, ising, show=False, to_little_endian= False):
    
    var_idx= getVarIndices(z) # Asignamos cada variable en z a un indice entero
    n= np.prod(z.shape) # Numero de qubits necesarios
    
    seq= [] # Secuencia de operadores de Pauli
    for ising_elm in ising:
        if not isinstance(ising_elm, float): # Omitimos termino independiente
            for ZiZj in ising_elm: # Iteramos sobre variables Zi o ZiZj
                
                # Creamos representacion str de operaciones ID sobre cada qubit
                pauli_tensor= ['I']*n 
                
                # Obtenemos variables Zi o ZiZj involucradas en el termino ZiZj
                var= (ZiZj,) if not isinstance(ZiZj, tuple) else ZiZj
                for zi in var: # Iteramos sobre ellas
                    idx= var_idx[zi] # Obtenemos el indice asignado a la variable
                    pauli_tensor[idx]= 'Z' # Aplicamos operacion Z sobre el qubit de la variable
                coef= ising_elm[ZiZj] # Obtenemos coeficiente multiplicador Jij * ZiZj
                
                # Pasamos lista pauli_tensor a cadena
                str_pauli= ''.join(var for var in pauli_tensor)
                if to_little_endian:
                    str_pauli= str_pauli[::-1]
                
                # Insertamos el par (str_pauli, coef) en la secuencia de operadores de Pauli
                seq.append( (str_pauli, coef) )
    if show:
        print('Lista de operadores de Pauli de H_P: {}'.format(seq))
    return SparsePauliOp.from_list(seq) # devolvemos seq como secuencia de operadores de Pauli


# Calcula el Hamiltoniano Ising en forma matricial 
# para el problema descrito por la secuencia de operadores de Pauli de entrada
def IsingHamiltonian(pauli : SparsePauliOp):
    
    n= pauli.num_qubits # Numero de variables del problema
    I, Z= np.eye(2), np.array([[1, 0], [0, -1]]) # Matrices de ID y Z
    H= np.zeros((2**n, 2**n)) # Matriz del hamiltoniano
    
    # Crear H_hat
    for oper in pauli:
        
        # Obtenemos coeficiente asociado al operador de Pauli (numero real)
        coef= float(oper.coeffs.squeeze().real)
        
        # Obtenemos cadena con la representacion de las puertas que conforman el operador
        gates= str( oper.paulis[0] )
        
        # Calculamos matriz asociada a las puertas
        prod= 1
        for matrix in gates:
            prod= np.kron(prod, Z if matrix=='Z' else I)
        H+= coef*prod # Incorporamos matriz al hamiltoniano
    return H


# Para una solucion binaria x=(x0, x1, ...) donde xi tiene valores 0/1, y dada
# una secuencia de operadores de Pauli H_P, la funcion devuelve la energia de la solucion
def energy_classic(x: np.ndarray, H_P : SparsePauliOp):
    
    z_spin= (2*x-1) # Movemos x al conjunto {-1, 1}
    Hz= 0 # Evaluamos H(z) inicializada a 0
    for pauli_op in H_P: # Iteramos sobre todos los operadores de Pauli
    
        # Obtenemos coeficiente asociado al operador de Pauli (numero real)
        coef= float(pauli_op.coeffs.squeeze().real)
        
        # Obtenemos cadena con la representacion de las puertas que conforman el operador
        gates= str( pauli_op.paulis[0] )
        
        # Obtenemos lista con las posiciones donde se encuentra la puerta Z
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Buscamos las posiciones del operador Z
            Zlist.append(z_pos.start())
        
        # Actualizacion de funcion de energia
        Hz+= coef*np.prod(z_spin[ Zlist ])
    return Hz


# Calculo pseudo-cuantico de la funcion de energia 
# de una solucion |x>=|x1x2...> representada en formato ket
# con respecto al hamiltoniano Ising H. Devuelve <x|H|x>
def energy_hamiltonian( x: int, H : np.array):

    quantum_x= np.zeros(len(H)) # Paso de x a |x>
    quantum_x[len(quantum_x)-1-x]= 1

    ket = quantum_x.reshape(-1,1) # Formato ket de la solucion
    bra= np.conjugate( np.transpose( ket ) ) # Formato bra de la solucion
    gx= bra @ H @ ket 
    return gx.squeeze()




###########################################################
# QAOA
###########################################################


# Construccion del circuito del exponencial del modelo Ising
# con parametro t
def ProblemCircuit(pauli : SparsePauliOp, t : float, reverse_ops : bool= False):
    
    # Generamos circuito
    n_qubits= pauli.num_qubits
    qc_problem= QuantumCircuit(n_qubits)
    
    # Oteramos sobre cada operador de pauli    
    for oper in pauli:
        
        # Obtenemos coeficiente 
        coef= float(oper.coeffs.squeeze().real) 
        
        # Obtenemos las matrices de pauli como cadena
        gates= str(oper.paulis[0])[::-1] if reverse_ops else str(oper.paulis[0])
        
        # Obtenemos posiciones de los qubits donde se realizan las puertas Z
        # Obtenemos lista con las posiciones donde se encuentra la puerta Z
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Buscamos las posiciones del operador Z
            Zlist.append(z_pos.start())
            
        if len(Zlist)==1: # Unica operacion Rz sobre un qubit
            qc_problem.rz(2*coef*t, Zlist[0])
        else: # Operacion Rzz sobre dos qubits
            qc_problem.rzz(2*coef*t, Zlist[0], Zlist[1])
        
    return qc_problem


# Creacion del circuito Mixer de QAOA con parametro beta
def MixerCircuit(n_qubits, beta):
    qc_mixer= QuantumCircuit(n_qubits) # Creacion del circuito
    qc_mixer.rx(2*beta, range(n_qubits)) # Inclusion de puertas Rx parametrizadas
    return qc_mixer


# Construccion del circuito de QAOA para el problema ising dado por la 
#  secuencia de operadores de pauli con L capas
def QAOAcirc(L : int, pauli : SparsePauliOp):
    
    # Generacion de parametros gamma/beta
    n_qubits= pauli.num_qubits
    gamma= ParameterVector(length= L, name='gamma')
    beta= ParameterVector(length= L, name= 'beta')
    
    # Creacion del circuito: superposicion 
    qc= QuantumCircuit(n_qubits)
    qc.h(range(n_qubits))
    
    # L capas de hamiltoniano+mixer
    for l in range(L):
        qc= qc.compose(ProblemCircuit(pauli, gamma[l]))
        qc= qc.compose(MixerCircuit(n_qubits, beta[l]))
    qc.measure_all()
    return gamma, beta, qc


# Calcula el valor de la esperanza de <x|H_P|x> a partir
# de las mediciones dadas en counts por la ejecucion del circuito
def ExpVal_from_counts(counts : dict, H_P: SparsePauliOp, reverse_ket= False):
    N= 0
    expval= 0
    for ket in counts:
        num_meas= counts[ket]
        N+= num_meas
        ket_rev= ket[::-1] if reverse_ket else ket
        ket_arr= np.array([int(xi) for xi in ket_rev])
        fx= energy_classic(ket_arr, H_P)
        expval+= fx*num_meas
    return expval/N


# Prepara la ejecucion de un circuito de optimizacion
# qaoa_circ con params valores de parametros para gamma y beta,
# usando el simulador sim con shots ejecuciones del circuito
# Devuelve la esperanza del observable implementado en qaoa_circ
def run_circuit_expectation(params, qaoa_circ, sim, shots, H_P, reverse_ket= False):
    qc= qaoa_circ.assign_parameters(params)
    counts= sim.run(transpile(qc, sim), shots= shots).result().get_counts()
    return ExpVal_from_counts(counts, H_P, reverse_ket)


# Obtiene la mejor (mas probable) solucion a un problema
# dadas las mediciones realizadas en counts
def getBestSolution(counts, to_big_endian= True):
    maxVal= 0
    bestket= None
    for ket in counts: # Buscamos el ket de maxima probabilidad de medicion
        if counts[ket] > maxVal:
            maxVal= counts[ket]
            bestket= ket
    return bestket[::-1] if to_big_endian else bestket


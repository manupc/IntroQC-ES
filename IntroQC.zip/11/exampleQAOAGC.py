"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""




import numpy as np
from OptimizationTools import getGraphColoringProblem as ProblemFormulation
from OptimizationTools import energy_classic, QAOAcirc, run_circuit_expectation, getBestSolution, IsingToPauli
from qiskit import transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
from scipy.optimize import minimize
from IPython.display import display


# Matriz de adyacencia del grafo
M= np.array([[0 , 1 , 1, 1],
             [1 , 0 , 0, 0],
             [1 , 0 , 0, 0],
             [1 , 0 , 0, 0]])

print('Representacion inicial del problema con la matriz de adyacencia:')
print(M)


# Creacion del modelo Ising
K, P1, P2= 2, 1, 1
z, model= ProblemFormulation(M, K, P1, P2)
ising= model.to_ising()

# Paso del modelo Ising a secuencia de operadores de Pauli
pauli= IsingToPauli(z, ising)

# Creacion del circuito QAOA con L capas y shots mediciones
L= 1
shots= 1024
gamma, beta, qaoa_circ= QAOAcirc(L, pauli)

# Preparacion del simulador y la funcion a ser optimizada
sim= AerSimulator()
to_be_minimized= lambda params : run_circuit_expectation(params, qaoa_circ, sim, shots, pauli)


# Parametros iniciales para beta y gamma
params_init= np.random.rand(2*L) #np.random.rand( 2*L )

# Optimizacion de gamma y beta con COBYLA
params = minimize(to_be_minimized,
               params_init,
               method='COBYLA').x

print('\nMejores parametros: {}'.format(params))

# Ejecucion del circuito QAOA con los mejores parametros
res_circ= qaoa_circ.assign_parameters(params)
shots= 1024
counts = sim.run(transpile(res_circ, sim), shots= shots).result().get_counts()

# Mostrar histograma de las mediciones
f= plot_histogram(counts)
display(f)

# Obtencion de la mejor solucion
solution_bin= getBestSolution(counts)
x= np.array([int(xi) for xi in solution_bin])
cost= energy_classic(x, pauli)

print('Mejor solucion encontrada (binario): {} con energia={}'.format(solution_bin, cost))

# Pasamos solucion a entero
x= x.reshape(-1, K)
for i, row in enumerate(x):
    print(row)
solution= np.zeros(len(M), dtype=int)
for i, row in enumerate(x):
    ones= np.where(row)[0] # Buscamos si hay algun 1
    if len(ones)!=1:
        raise Exception('Solucion no valida')
    else:
        solution[i]= ones[0]

print('Mejor solucion encontrada: {} con energia={}'.format(solution, cost))
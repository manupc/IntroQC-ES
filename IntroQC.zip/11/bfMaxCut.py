"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import exact_optimizer


# Definicion de la matriz de adyacencia del problema
M= np.array([[0, 1, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0],
             [0, 1, 0, 1, 0, 1],
             [0, 0, 1, 0, 1, 0],
             [0, 1, 0, 1, 0, 1],
             [1, 0, 1, 0, 1, 0]
            ], dtype= int)

print('Matriz de adyacencia del problema:')
print(M)


# Procedimiento para implementar la funcion de coste. Tiene como entrada
# la solucion x y la matriz de adyacencia M del problema.
# Como salida, devuelve un valor escalar con la funcion del coste
def f(x : np.ndarray, M : np.ndarray):
    
    n= len(x) # Tam. de la solucion
    fx= 0 # Valor de la funcion de coste
    for i in range(n): # Iteramos sobre indices xi
        for j in range(i+1, n): # Iteramos sobre indices xj
            e_ij= M[i][j] # 1 si la arista e_ij existe, 0 en caso contrario
            diff= 1 if x[i] != x[j] else 0 # v_i y v_j estan en conjuntos distintos
            fx+= e_ij * diff
    return -fx # Camcio de signo para problemas de minimizacion


# Funcion de coste como lambda para ajustar la funcion f al formato del solver
cost_f= lambda x: f(x, M)

n= len(M) # Numero de variables
D= [ [0, 1] ]*n # Dominio de cada variable

# Comprobacion de restricciones
check_constraints= None # No hay restricciones en el problema

# Llamada al algoritmo de optimizacion
x= exact_optimizer(n, D, check_constraints, cost_f)

fx= f(x, M) # Calcular funcion de coste

# Mostrar solucion 
print('Solucion x={}, con f(x)={}'.format(x, fx))


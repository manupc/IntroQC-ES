"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Matriz de adyacencia del grafo
M= np.array([[0 , 1 , 0 , 1 , 1 , 0],
             [1 , 0 , 1 , 0 , 1 , 1],
             [0 , 1 , 0 , 1 , 0 , 1],
             [1 , 0 , 1 , 0 , 0 , 0],
             [1 , 1 , 0 , 0 , 0 , 1],
             [0 , 1 , 1 , 0 , 1 , 0]])

print('Representacion inicial del problema con la matriz de adyacencia:')
print(M)

# Creacion de variables para el modelo QUBO
n= len(M) # No. de variables
x = Array.create('x', shape=(n,), vartype='BINARY')


### Modelo QUBO
# Calculamos funcion de coste f(x)=x1+x2+x3+x4+x5+x6
Q= 0
for i in range(n):
    Q+= x[i]
    
# Incluimos penalizaciones
P= 20 # Escalar de penalizacion comun a todas las restricciones
for i in range(n):
    for j in range(i+1, n):
        if M[i,j] != 0: # Penalizar exclusion de arista (vi, vj)
            Q+= P*(1-x[i]-x[j]+x[i]*x[j])


# Creamos modelo teorico QUBO
model= Q.compile()
qubo, offset= model.to_qubo()
print('\nModelo QUBO con penalizacion P={}:'.format(P))
for key in qubo:
    print(key, qubo[key])

# Creamos modelo cuadratico binario (BQM)
bqm= model.to_bqm()

# Aplicamos enfriamiento simulado para resolver el problema QUBO
# un total de n_shots veces
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nLas {} soluciones obtenidas: '.format(n_shots))
print(sampleset)

# Obtencion de la mejor solucion
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

# Paso de la solucion a NumPy
solution = np.zeros(len(M), dtype=int)
for var in best_sample_vars:
    for i, x_i in enumerate(x):
        if var in str(x_i):
            solution[i] = best_sample_vars[var]
    
# Mostramos solucion
# y funcion de perdida
print('\nMejor Solucion: x={} con coste f(x)={}'.format(solution, best_sample_cost))


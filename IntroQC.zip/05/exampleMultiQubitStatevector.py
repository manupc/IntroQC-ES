"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Creacion del estado 1/2(|000> + |001> + j|100> + j|101>)
sv= Statevector([1/2, 1/2, 0, 0,
                 1.j/2, 1.j/2, 0, 0])
print('\nEstado \i0+>= 1/2(|000> + |001> + j|100> + j|101>) : ', sv)

# Creacion del estado 1/sqrt(2)(|00> + |01>)
sv= Statevector([1/np.sqrt(2), 1/np.sqrt(2), 0, 0])
print('\nEstado |0+>= 1/sqrt(2)(|00> + |01>) : ', sv)


# Ejemplo de uso de from_int: Creacion de |0100>= |4>
sv= Statevector.from_int(i=3, dims=4)
print('\n|0011> (from int): ', sv)


# Ejemplo de uso de from_label: Creacion de |i0+>
sv= Statevector.from_label('r0+')
print('\n|i0+> (from label): ', sv)


# Ejemplo de medicion con sample_counts:
print('\nMedicion con get_counts:')
measurements= sv.sample_counts(shots= 1024)
for k in measurements:
    print('\t{} : {} times'.format(k, measurements[k]))

# Ejemplo de medicion con sample_memory:
measurements= sv.sample_memory(shots= 10)
print('\nSample memory with 10 shots: ', measurements)
    

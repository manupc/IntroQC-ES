"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator

# Circuito cuantico de 2 qubits
qc= QuantumCircuit(2)
qc.x(1)
qc.save_unitary()


# Simulacion
sim= AerSimulator()
qc= transpile(qc, sim)
results= sim.run( transpile(qc), shots=1 ).result()
U= results.get_unitary()
print('Matriz unitaria U=(I tensor X): \n', U)

# Evolucion de estado |00> con matriz unitaria U
print('\nAplicacion de U sobre un estado:')
sv= Statevector.from_label('00')
print('|00>: ', sv)

svp= sv.evolve(U)
print('U|00>', svp)


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

# Creacion de |0>, |1> y |+> en NumPy
np_ket0= np.array([1, 0], dtype=complex)
np_ket1= np.array([0, 1], dtype=complex)
np_ketplus= np.array([1/np.sqrt(2) , 1/np.sqrt(2)], dtype=complex)

# Creacion de |0>, |1> y |+> en Qiskit
ket0= Statevector(np_ket0)
ket1= Statevector(np_ket1)
ketplus= Statevector(np_ketplus)

# Acceso a los atributos de un estado
print('El estado |+> utiliza {} qubit/s y necesita {} amplitudes.'.format(ketplus.num_qubits, ketplus.dim))
print('Sus amplitudes son: {}'.format(ketplus.data))

# Transformacion de estado a diccionario
ketplus_dict= ketplus.to_dict()
print('En formato diccionario son: {}'.format(ketplus_dict))

# Comprobacion de validez de un estado cuantico
print('\nComprobar funcionamiento de is_valid:')
ketError= Statevector([2, 0]) # Creacion de un estado cuantico no valido
print('El estado |0> es valido: {}'.format(ket0.is_valid()))
print('El estado |error> es valido: {}'.format(ketError.is_valid()))

# Ejemplo de conjugate e inner
print('\nComprobar funcionamiento de conjugate e inner:')
np_ket_psi= np.array([1/np.sqrt(2) , 1/np.sqrt(2)*1.j], dtype= complex)
ket_psi= Statevector(np_ket_psi)
print('El estado |psi> es:\n{}'.format(ket_psi))
print('\nSu conjugado es:\n{}'.format(ket_psi.conjugate() ))
print('\nEl producto <0|1> es: {}'.format( ket0.inner(ket1) ))
print('El producto <0|psi> es: {}'.format( ket0.inner(ket_psi) ))
print('El producto <psi|psi> es: {}'.format( ket_psi.inner(ket_psi) ))

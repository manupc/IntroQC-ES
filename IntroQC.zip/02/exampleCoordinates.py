"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_bloch_vector
from SingleQubitUtils import Statevector_to_cartesian
from IPython.display import display
import numpy as np


# Mostrar estado |0>
ket= Statevector.from_label('0')
coords= Statevector_to_cartesian(ket)
print('Las coordenadas de |0> son: {}'.format(coords))
f= plot_bloch_vector(coords, title='|0>')
display(f)

# Mostrar estado |1>
ket= Statevector.from_label('1')
coords= Statevector_to_cartesian(ket)
print('Las coordenadas de |1> son: {}'.format(coords))
f= plot_bloch_vector(coords, title='|1>')
display(f)

# Mostrar estado |+>
ket= Statevector.from_label('+')
coords= Statevector_to_cartesian(ket)
print('Las coordenadas de |+> son: {}'.format(coords))
f= plot_bloch_vector(coords, title='|+>')
display(f)

# Mostrar estado |i>
ket= Statevector([1/np.sqrt(2), 1.j/np.sqrt(2)])
coords= Statevector_to_cartesian(ket)
print('Las coordenadas de |i> son: {}'.format(coords))
f= plot_bloch_vector(coords, title='|i>')
display(f)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
from SingleQubitUtils import MPStatevector
import numpy as np

# Creacion de estados |0>, |1>, |+> y |psi> con Statevector
ket0= Statevector.from_label('0')
ket1= Statevector.from_label('1')
ketplus= Statevector.from_label('+')
ketpsi= Statevector([ 1/np.sqrt(2), 1.j/np.sqrt(2) ])

# Pruebas del metodo from_Statevector
mp_ket0= MPStatevector.from_Statevector( ket0 )
mp_ket1= MPStatevector.from_Statevector( ket1 )
mp_ketplus= MPStatevector.from_Statevector( ketplus )
mp_ketpsi= MPStatevector.from_Statevector( ketpsi )

print('Estado |0>. La forma en magnitudes y fase {} se corresponde con el estado:\n{}'.format(mp_ket0, ket0))
print('Estado |1>. La forma en magnitudes y fase {} se corresponde con el estado:\n{}'.format(mp_ket1, ket1))
print('Estado |+>. La forma en magnitudes y fase {} se corresponde con el estado:\n{}'.format(mp_ketplus, ketplus))
print('Estado |psi>. La forma en magnitudes y fase {} se corresponde con el estado:\n{}'.format(mp_ketpsi, ketpsi))


# Ejemplo de to_Statevector
mp_ketminus= MPStatevector([ 1/np.sqrt(2), 1/np.sqrt(2), np.pi ])
ketminus= mp_ketminus.to_Statevector()
print('Estado |->. La forma en magnitudes y fase {} se corresponde con el estado:\n{}'.format(mp_ketminus, ketminus))

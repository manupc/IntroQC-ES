"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

# Creacion de |0> y |+> en NumPy
ket0= Statevector.from_label('0')
ketplus= Statevector.from_label('+')

# Ejemplo de uso de probabilities
print('Ejemplo de uso del metodo probabilities() vs calculo manual para |0>:')
p_ket0= np.abs(ket0.data)**2
print('Probabilidades de amplitud de |0>: {}'.format( ket0.probabilities() ))
print('Probabilidades de amplitud de |0> (manual): {}'.format( p_ket0 ))


# Ejemplo de uso de probabilities
print('\nEjemplo de uso del metodo probabilities() vs calculo manual para |+>:')
p_ketplus= np.abs(ketplus.data)**2
print('Probabilidades de amplitud de |+>: {}'.format( ketplus.probabilities() ))
print('Probabilidades de amplitud de |+> (manual): {}'.format( p_ketplus ))



# Ejemplo de uso de probabilities_dict
print('\nEjemplo de uso del metodo probabilities_dict():')
print('Probabilidades de amplitud de |0>: {}'.format( ket0.probabilities_dict() ))
print('Probabilidades de amplitud de |+>: {}'.format( ketplus.probabilities_dict() ))

# Ejemplo de uso de measure
shots= 2 # Numero de simulaciones de medicion a realizar
print('\nEjemplo de uso del metodo measure():')
for i in ['0', '+']:
    ket= Statevector.from_label(i)
    print('Simulacion de medicion sobre el ket |{}>:'.format(i))
    for n in range(shots):
        outcome, sv= ket.measure()
        print('Simulacion {}. Se obtiene |{}>= {}'.format(n+1, outcome, sv))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.visualization import plot_histogram
from qiskit.quantum_info import Statevector, DensityMatrix
from IPython.display import display


# Histograma tras simulacion de medicion del estado |0>
N= 1024
sv= Statevector.from_label('0')
print('\nEstado cuantico |0> en Qiskit:\n{}'.format(sv))
counts= sv.sample_counts(shots= N)
print('Resultados tras {} medidiones: {}'.format(N, counts))
f= plot_histogram(counts)
display(f)


# Histograma tras simulacion de medicion del estado |->
sv= Statevector.from_label('-')
print('\nEstado cuantico |-i> en Qiskit:\n{}'.format(sv))
counts= sv.sample_counts(shots= N)
print('Resultados tras {} medidiones: {}'.format(N, counts))
f= plot_histogram(counts)
display(f)


# Q-Esfera del estado |i>
sv= Statevector.from_label('r')
print('\nEstado cuantico |i> en Qiskit:\n{}'.format(sv))
f= sv.draw(output='qsphere')
display(f)


# Diagrama de Hinton del estado |-i>
sv= Statevector.from_label('l')
dm= DensityMatrix(sv)
print('\nMatriz de densidad del estado |-i>:\n{}'.format(dm))
f= dm.draw(output='hinton')
display(f)


# Diagrama de Hinton del estado |1>
sv= Statevector.from_label('1')
dm= DensityMatrix(sv)
print('\nEstado cuantico |1> en Qiskit:\n{}'.format(sv))
print('Su matriz de densidad:\n{}'.format(dm))
f= dm.draw(output='hinton')
display(f)


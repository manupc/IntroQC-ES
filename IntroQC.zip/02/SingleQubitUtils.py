"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

tol_default= 1e-5 # Tolerancia de error permitida por defecto

# Clase para representar un estado cuantico de un qubit en forma exponencial
class ExpStatevector:

    # Constructor. Crea un objeto para representar un Statevector en forma exponencial
    # ENTRADAS:
    #   data: Array conteniendo los valores [r0, theta0, r1, theta1]
    def __init__(self, data):
        assert(len(data) == 4)
        self.__r= np.array([data[0], data[2]], dtype=float)
        self.__theta= np.array([data[1], data[3]], dtype=float)
        assert(self.__is_valid())


    # Devuelve el numero de qubits utilizados para representar el estado cuantico
    def num_qubits(self):
        return 1


    # Comprueba si el estado cuantico representado es valido
    # ENTRADAS:
    #   tol: Tolerancia de error permitida
    def __is_valid(self, tol : float= tol_default):
        return (np.abs(np.sum( np.abs(self.__r)**2 ) - 1)<=tol)


    # Sobrecarga de __str__
    def __str__(self):
        txt= '{:.3f}e^({:.3f}*j) |0> + {:.3f}e^({:.3f}*j) |1>'.format(
            self.__r[0], self.__theta[0], self.__r[1], self.__theta[1])
        return txt


    # Accede a las magnitudes de las amplitudes del estado cuantico representado
    # ENTRADAS:
    #   i: Indice de la magnitud r_i a acceder
    # SALIDAS:
    #   La magnitud r_i del estado cuantico
    def r(self, i : int):
        assert(0<=i<2)
        return self.__r[i]


    # Accede a las fases de las amplitudes del estado cuantico representado
    # ENTRADAS:
    #   i: Indice de la fase theta_i a acceder
    # SALIDAS:
    #   La fase theta_i del estado cuantico
    def theta(self, i : int):
        assert(0<=i<2)
        return self.__theta[i]


    # Transforma el objeto actual a un objeto Statevector de Qiskit
    # SALIDAS:
    #   Un objeto Statevector de Qiskit que contiene el vector de estado representado en el objeto actual
    def to_Statevector(self):
        sv= [self.__r[0]*np.exp(1.j*self.__theta[0]), 
             self.__r[1]*np.exp(1.j*self.__theta[1])]
        return Statevector(sv)
    
    
    # Crea un objeto ExpStatevector a partir de un objeto Statevector de Qiskit
    # ENTRADAS:
    #   sv: Un objeto Statevector de Qiskit valido
    # SALIDAS:
    #   Un objeto ExpStatevector equivalente al objeto sv de entrada
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        r1, theta1= np.abs(sv.data[1]), np.angle(sv.data[1])
        return ExpStatevector([r0, theta0, r1, theta1])
    
    


# Clase para representar un estado cuantico de un qubit en forma de magnitud y fase
class MPStatevector:

    # Constructor. Crea un objeto para representar un Statevector en forma de magnitudes y fase
    # ENTRADAS:
    #   data: Array conteniendo los valores [r0, r1, theta]
    def __init__(self, data):
        assert(len(data) == 3)
        self.__r= np.array([data[0], data[1]], dtype=float)
        self.__theta= float( data[2] )
        assert(self.__is_valid())


    # Devuelve el numero de qubits utilizados para representar el estado cuantico
    def num_qubits(self):
        return 1


    # Comprueba si el estado cuantico representado es valido
    # ENTRADAS:
    #   tol: Tolerancia de error permitida
    def __is_valid(self, tol : float= tol_default):
        return (np.abs(np.sum( np.abs(self.__r)**2 ) - 1)<=tol)


    # Sobrecarga de __str__
    def __str__(self):
        txt= '{:.3f} |0> + {:.3f}e^({:.3f}*j) |1>'.format(
            self.__r[0], self.__r[1], self.__theta)
        return txt
    
    
    # Accede a las magnitudes de las amplitudes del estado cuantico representado
    # ENTRADAS:
    #   i: Indice de la magnitud r_i a acceder
    # SALIDAS:
    #   La magnitud r_i del estado cuantico
    def r(self, i : int):
        assert(0<=i<2)
        return self.__r[i]


    # Accede a la fase relativa del estado cuantico representado
    # SALIDAS:
    #   La fase theta del estado cuantico
    def theta(self):
        return self.__theta

    
    # Transforma el objeto actual a un objeto Statevector de Qiskit
    # SALIDAS:
    #   Un objeto Statevector de Qiskit que contiene el vector de estado representado en el objeto actual
    def to_Statevector(self):
        sv= [self.__r[0], self.__r[1]*np.exp(1.j*self.__theta)]
        return Statevector(sv)
    
    
    # Crea un objeto MPStatevector a partir de un objeto Statevector de Qiskit
    # ENTRADAS:
    #   sv: Un objeto Statevector de Qiskit valido
    # SALIDAS:
    #   Un objeto MPStatevector equivalente al objeto sv de entrada
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        r1, theta1= np.abs(sv.data[1]), np.angle(sv.data[1])
        theta= theta1-theta0
        return MPStatevector([r0, r1, theta])







# Clase para representar un estado cuantico de un qubit en forma trigonometrica
class TriStatevector:

    # Constructor. Crea un objeto para representar un Statevector en forma trigonometrica
    # ENTRADAS:
    #   data: Array conteniendo los valores [phi, theta]
    def __init__(self, data):
        assert(len(data) == 2)
        self.__phi= float( data[0] )
        self.__theta= float( data[1] )
        assert(self.__is_valid())


    # Devuelve el numero de qubits utilizados para representar el estado cuantico
    def num_qubits(self):
        return 1


    # Comprueba si el estado cuantico representado es valido
    # ENTRADAS:
    #   tol: Tolerancia de error permitida
    def __is_valid(self, tol : float= tol_default):
        return True


    # Sobrecarga de __str__
    def __str__(self):
        txt= 'cos({:.3f}/2)|0> + sin({:.3f}/2)*exp(j*{:.3f})|1>'.format(self.__phi, self.__phi, self.__theta)
        return txt


    # Accede al angulo phi de control de la magnitud del estado cuantico representado
    # SALIDAS:
    #   El angulo phi del estado cuantico en forma trigonometrica
    def phi(self):
        return self.__phi


    # Accede a la fase relativa del estado cuantico representado
    # SALIDAS:
    #   La fase theta del estado cuantico
    def theta(self):
        return self.__theta


    # Transforma el objeto actual a un objeto Statevector de Qiskit
    # SALIDAS:
    #   Un objeto Statevector de Qiskit que contiene el vector de estado representado en el objeto actual
    def to_Statevector(self):
        sv= [np.cos(0.5*self.__phi), 
             np.sin(0.5*self.__phi)*np.exp(1.j*self.__theta)]
        return Statevector(sv)    
    
    # Crea un objeto TriStatevector a partir de un objeto Statevector de Qiskit
    # ENTRADAS:
    #   sv: Un objeto Statevector de Qiskit valido
    # SALIDAS:
    #   Un objeto TriStatevector equivalente al objeto sv de entrada
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        theta1= np.angle(sv.data[1])
        theta= theta1-theta0
        phi= 2*np.arccos(r0)
        return TriStatevector([phi, theta])  





# Funcion que calcula las coordenadas cartesianas (x, y, z) de un estado cuantico de un qubit
# ENTRADAS: 
#   sv: un objeto Statevector conteniendo el estado cuantico de un qubit
# SALIDAS:
#   Una terna (x, y, z) con las coordenadas cartesianas del estado en la esfera de Bloch
def Statevector_to_cartesian(sv : Statevector):
    assert(sv.num_qubits == 1)
    
    # Transformacion del estado a forma trigonometrica
    tri_sv= TriStatevector.from_Statevector(sv)
    phi, theta= tri_sv.phi(), tri_sv.theta()
    
    z= np.cos(phi)
    y= np.sin(phi) * np.sin(theta)
    x= np.sin(phi) * np.cos(theta)
    return (x, y, z)

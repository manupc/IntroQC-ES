"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np


D34= np.eye(3, 4) # Matriz diagonal de 1s de tam. 3 filas y 4 columnas
Z33= np.zeros( (3, 3) ) # Matriz de ceros de tam. 3 filas y 3 columnas
O42= np.ones( (4, 2) ) # Matriz de unos de tam. 4 filas y 2 columnas

# Matriz de tam 2 filas y 4 columnas
M= np.array( [ [1, 2, 3, 4], # Fila 1
               [5, 6, 7, 8] # Fila 2
            ] )

print('Variable D34. Tam.: {}'.format(D34.shape))
print(D34)

print('Variable Z33. Tam.: {}'.format(Z33.shape))
print(Z33)

print('Variable O42. Tam.: {}'.format(O42.shape))
print(O42)

print('Variable M. Tam.: {}'.format(M.shape))
print(M)

print('Matriz traspuesta de M. Tam.: {}'.format(M.T.shape))
print(M.T)

M2= O42 + M.T # Suma de traspuesta de M + O42
print('M2. Suma de M.T + O42:')
print(M2)

M3= 2*D34@M2 # 2*D34 multiplicado por M2
print('Multiplicar 2*D34 por M2. Tam: {}'.format(M3.shape))
print(M3)

M4= M3*M3 # Producto de todas las entradas por ellas mismas
print('M3. Tam: {}'.format(M4.shape))
print(M4)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt

# Distribucion de probabilidad como diccionario
Pdict= {'lluvioso' : 0.5,
    'soleado'  : 0.3, 
    'nublado'  : 0.2
    }

# Valores de la variable como array NumPy
X= np.array([ key for key in Pdict])

# Distribucion de probabilidad como array numpy
P= np.array([ Pdict[key] for key in Pdict ])

print('Variable aleatoria X con valores: {}'.format(X))


N= 100000 # Tomamos N muestras de la variable
samples= np.random.choice(X, size=N, replace= True, p=P)

n= np.zeros( len(X) , dtype=int) # Array para guardar frecuencias absolutas
for i, x_i in enumerate(X):
    n[i]= np.sum( samples==x_i )
    print('Hay {} muestras de dia {}'.format(n[i], x_i))
print('En total: {} muestras'.format( np.sum(n) ))

f= n/N # Calculamos frecuencia relativa aproximando p(V[i])
for i, x_i in enumerate(X):
    print('Aproximacion de p({})= {}'.format(X[i], f[i]))

# Histograma de resultados obtenidos
f= plt.figure()
plt.hist(samples)
plt.show()
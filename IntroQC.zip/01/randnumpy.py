"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

N= 10000 # Numero de veces que se lanza la moneda. Valor 0= cara; 1= cruz
resultados= np.zeros(2, dtype=int) # Numero de veces que sale cara/cruz


# Lanzamiento de moneda usando rand
samples= np.random.rand(N) < 0.5 # Suponemos p(cara)= p(cruz)= 0.5
resultados[0]= np.sum(samples==0) # Contabilizar numero de caras
resultados[1]= np.sum(samples==1) # Contabilizar numero de cruces

print("\nUsando rand(size):")
print('Se ha obtenido cara un total de {} veces entre {} lanzamientos'.format(resultados[0], N))
print('Se ha obtenido cruz un total de {} veces entre {} lanzamientos'.format(resultados[1], N))


# Lanzamiento de moneda usando randint
samples= np.random.randint(low=0, high=2, size=N)
resultados[0]= np.sum(samples==0)
resultados[1]= np.sum(samples==1)

print("\nUsando randint(low, high, size):")
print('Se ha obtenido cara un total de {} veces entre {} lanzamientos'.format(resultados[0], N))
print('Se ha obtenido cruz un total de {} veces entre {} lanzamientos'.format(resultados[1], N))


# Ordena de forma aleatoria numeros entre 0 y 9 inclusive
perm= np.random.choice(a= range(10), size=10, replace=False)
print('10 elementos ordenados al azar: {}'.format(perm))
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

ec= np.eye(2, 2, dtype=complex)
mc= np.array([ [0, -1.j],
               [-1.j, 0]], dtype=complex)
mc2= np.array([ [0, -1.j],
               [1.j, 0]], dtype=complex)
vc= np.array([[1],
              [0]
             ], dtype= complex)


print('Matriz mc:\n{}'.format(mc))
hermitian1= np.all( mc == mc.conj().T )
print('mc es hermitica: {}'.format(hermitian1))
unitary1= np.all( (mc @ mc.conj().T) == ec )
print('mc es unitaria: {}'.format(unitary1))

# Operaciones matriciales: multiplicacion
print('Array de complejos vc:\n{}'.format(vc))
print('mc @ vc=\n{}'.format( mc@vc ))


print('\nMatriz mc2:\n{}'.format(mc2))
hermitian2= np.all( mc2 == mc2.conj().T )
print('mc2 es hermitica: {}'.format(hermitian2))
unitary2= np.all( (mc2 @ mc2.conj().T) == ec )
print('mc2 es unitaria: {}'.format(unitary2))


# Cambios de representacion de complejos en NumPy
c= 0 + 1.j
print('\nComplejo en forma binomica: {}'.format(c))

r, theta= np.abs(c), np.angle(c)
print('Complejo en forma polar: {}'.format( (r, theta )))
print('Complejo en forma exponencial: {}*e^({}*j)'.format( r, theta ))
print('Complejo en forma trigonometrica: {}*(cos({}) + sin({})*j)'.format( r, theta, theta ))
      

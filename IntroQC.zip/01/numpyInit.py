"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crear array de 5 elementos desde lista
a1= np.array( [1.2, 4, 3.1, -0.9, 2.2] )
print('Array a1: {}'.format(a1))

# Crear array de 3 elementos inicializados a cero
a2= np.zeros( 3 )
print('Array a2: {}'.format(a2))

# Crear array de 4 elementos inicializados a uno
a3= np.ones( 4 )
print('Array a3: {}'.format(a3))

# Crear array con valores en [0,1) espaciados por 0.2
a4= np.arange(0, 1, 0.2)
print('Array a4: {}'.format(a4))

# Crear array con valores en [0,1] conteniendo 6 elementos
a5= np.linspace(0, 1, 6)
print('Array a5: {}'.format(a5))
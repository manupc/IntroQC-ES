"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np


# Definicion de tres angulos en radianes
thetas= [0.25*np.pi, 0.75*np.pi, -0.75*np.pi]


for angle in thetas:
    
    print('\nAngulo: {:.2f} rads.'.format(angle))

    # Funciones sin, cos, tan 
    print('\tsin({:.2f})= {:.2f}; cos({:.2f})= {:.2f}; tan({:.2f})= {:.2f}'.format(
        angle, np.sin(angle), angle, np.cos(angle), angle, np.tan(angle)
        ))
    
    # Funciones arcsin, arccos arctan, arctan2 para theta1
    print('\tarcsin({:.2f})= {:.2f}; arccos({:.2f})= {:.2f}; arctan({:.2f})= {:.2f}'.format(
        np.sin(angle), np.arcsin(np.sin(angle)), 
        np.cos(angle), np.arccos(np.cos(angle)), 
        np.tan(angle), np.arctan(np.tan(angle))
        ))
    print('\tarctan2({:.2f}, {:.2f})= {:.2f}'.format(
        np.sin(angle), np.cos(angle), np.arctan2(np.sin(angle), np.cos(angle))
        ))
    
    
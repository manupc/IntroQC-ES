"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from IPython.display import display
        
qc= QuantumCircuit(1)
qc.h(0)
qc.z(0)
qc.h(0)

# Guardar el statevector previo a su medicion
qc.save_statevector()

# Circuito inicial:
display( qc.draw('mpl') )

# Instanciacion del simulador Aer
simulator = AerSimulator(method='statevector')

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qc, simulator) 
# Circuito tras transpile:
display( qct.draw('mpl') )

# Simulacion del circuito para obtener los resultados de medicion en diccionario
job= simulator.run(qct, shots=1)
result = job.result()

# Obtencion del statevector antes de la medicion
sv = result.get_statevector(qct)
print('\nStatevector simulado:')
print(sv)



"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import ZGate, HGate
from qiskit.quantum_info import Statevector
import numpy as np

# Creamos el estado |0> y lo mostramos
sv= Statevector.from_label('0')
print('Estado inicial |0>: {}'.format(sv))

# Creamos las puertas
Z, H= ZGate(), HGate()

# Aplicamos puerta sobre el estado
Hsv= sv.evolve(H)
print('Estado intermedio H|0> : {}'.format(Hsv))

# Aplicamos puerta Z sobre el resultado
ZHsv= Hsv.evolve(Z)
print('Estado intermedio ZH|+> : {}'.format(ZHsv))

# Aplicamos puerta H sobre el resultado
HZHsv= ZHsv.evolve(H)
print('Estado final HZH|+> : {}'.format(HZHsv))


# Creamos el estado |psi>= cos(pi/8)|0> + sin(pi/8)|1> y lo mostramos
alpha0= np.cos(np.pi/8)
alpha1= np.sin(np.pi/8)
sv= Statevector([alpha0, alpha1])
print('Estado inicial |q> : {}'.format(sv))


# Aplicamos la puerta sobre el estado
Hsv= sv.evolve(H)
print('Estado final H|q> : {}'.format(Hsv))
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import XGate
from qiskit.quantum_info import Statevector
import numpy as np

# Instanciamos la puerta
X_gate= XGate()

# Mostrar informacion del objeto 
print('Quantum X gate:')
print(X_gate)

# Creacion de estado cuantico |0> en NumPy
ket0= Statevector.from_label('0')
print('\n|0>:')
print(ket0)

# Simulacion de evolucion del estado
ketX0= ket0.evolve(X_gate)
print('\nX|0>:')
print(ketX0)

# Creacion de estado cuantico |0> en NumPy
alpha0= np.cos(np.pi/8)
alpha1= np.sin(np.pi/8)*np.exp(1.j*np.pi/2)
ketq= Statevector([alpha0, alpha1])
print('\n|q>:')
print(ketq)

# Simulacion de evolucion del estado
ketXq= ketq.evolve(X_gate)
print('\nX|q>:')
print(ketXq)

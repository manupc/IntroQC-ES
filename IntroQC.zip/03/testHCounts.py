"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
from IPython.display import display
qc= QuantumCircuit(1)
qc.h(0)
qc.measure_all()


# Instanciacion del simulador Aer
simulator = AerSimulator()

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qc, simulator) 

# Simulacion del circuito para obtener todos los resultados obtenidos por separado
result = simulator.run(qct, shots=10000).result()
counts= result.get_counts(qct)

print('Resultados obtenidos')
print(counts)

f= plot_histogram(counts)
display(f)

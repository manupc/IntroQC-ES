"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit.circuit.library import XGate, YGate
from IPython.display import display
       
qc1= QuantumCircuit(1, 1) # Circuito de 1 qubit
qc2= QuantumCircuit(1, 1) # Circuito de 1 qubit

qc1.append(XGate(), [0]) # Puerta X sobre qubit 0
qc1.append(YGate(), [0]) # Puerta Y sobre qubit 0
qc2.measure(0,0) # Medicion de todos los qubits

# Primer circuito:
display( qc1.draw('mpl') )

# Segundo circuito:
display( qc2.draw('mpl') )


qc= qc1.compose(qc2)
# Composicion de los dos circuitos:
display( qc.draw('mpl') )
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

## Ejemplo de uso de T
qc= QuantumCircuit(1)
qc.h(0)
qc.t(0)

# Guardamos la matriz unitaria del circuito
qc.save_statevector()


# Instanciacion del simulador Aer
simulator = AerSimulator(method='statevector')

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qc, simulator) 

# Instanciacion del simulador Aer
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResultado de aplicar T|+>:', sv)
print('Resultado esperado:', Statevector([1/np.sqrt(2), np.exp(1.j*np.pi/4)/np.sqrt(2)]))


## Ejemplo de uso de Tdg
qc= QuantumCircuit(1)
qc.h(0)
qc.tdg(0)


# Guardamos la matriz unitaria del circuito
qc.save_statevector()

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qc, simulator) 

# Instanciacion del simulador Aer
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResultado de aplicar Tdg|+>:', sv)
print('Resultado esperado:', Statevector([1/np.sqrt(2), np.exp(-1.j*np.pi/4)/np.sqrt(2)]))

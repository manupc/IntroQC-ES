"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import XGate, YGate
from qiskit.quantum_info import Statevector
import numpy as np

# Creamos el estado |0> y lo mostramos
sv= Statevector.from_label('0')
print('Estado inicial |0>: {}'.format(sv))

# Creamos las puertas X e Y
X, Y= XGate(), YGate()

# Aplicamos Y|sv>
Ysv= sv.evolve(Y)

# Transformamos el resultado a Statevector
print('Estado intermedio Y|0> : {}'.format(Ysv))

# Aplicamos puerta X sobre el resultado
XYsv= Ysv.evolve(X)
print('Estado final XY|0> : {}'.format(XYsv))


# Creamos el estado |psi>= cos(pi/8)|0> + sin(pi/8)e^(j*pi/4)|1> y lo mostramos
alpha0= np.cos(np.cos(np.pi/8))
alpha1= np.sin(np.pi/8)*np.exp(1.j*np.pi/4)
sv= Statevector([alpha0, alpha1])
print('Estado inicial |q> : {}'.format(sv))

# Aplicamos la puerta sobre el estado
Ysv= sv.evolve(Y)
print('Estado final Y|q> : {}'.format(Ysv))
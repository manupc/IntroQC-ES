"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np
from IPython.display import display
tol= 0.05 # Tolerancia de error

# Estado que deseamos modelar
phi, theta= np.pi/4, -np.pi/4
sv_target= Statevector([np.cos(phi/2), np.sin(phi/2)*np.exp(1.j*theta)])

# Circuito de preparacion del estado
qc_prep= QuantumCircuit(1,1)
qc_prep.sx(0)
qc_prep.t(0)
qc_prep.sxdg(0)
qc_prep.tdg(0)
qc_prep.save_statevector()

# Simulamos el estado que queremos preparar
sim= AerSimulator()
sv_prep= sim.run(transpile(qc_prep, sim), shots= 1).result().get_statevector()


print('El estado deseado:   {}'.format(sv_target))
print('El estado preparado: {}'.format(sv_prep))


# Circuitos para la medicion en los tres ejes
shots= 100000 # Mediciones a realizar
qc_measZ= QuantumCircuit(1,1) # Medicion en Z
qc_measZ.measure(0,0)

qc_measX= QuantumCircuit(1,1) # Medicion en X
qc_measX.h(0)
qc_measX.measure(0,0)

qc_measY= QuantumCircuit(1,1) # Medicion en Y
qc_measY.sdg(0)
qc_measY.h(0)
qc_measY.measure(0,0)


# Medimos counts en el eje Z
qc= qc_prep.compose( qc_measZ )

display(qc.draw('mpl')) # Circuito de medicion en Z

counts= sim.run(qc, shots=shots).result().get_counts()
print('Mediciones en Z: {}'.format(counts))
countsKet0= counts['0'] / shots

# Medimos counts en el eje X
qc= qc_prep.compose( qc_measX )

display(qc.draw('mpl')) # Circuito de medicion en X

counts= sim.run(qc, shots=shots).result().get_counts()
print('Mediciones en X: {}'.format(counts))
countsKetPlus= counts['0'] / shots
countsX_diff= (counts['0'] - counts['1'])/shots

# Medimos counts en el eje Y
qc= qc_prep.compose( qc_measY )

display(qc.draw('mpl')) # Circuito de medicion en Y

counts= sim.run(qc, shots=shots).result().get_counts()
print('Mediciones en Y: {}'.format(counts))
countsKetI= counts['0'] / shots
countsY_diff= (counts['0'] - counts['1'])/shots


# Aproximamos en que cuadrante de la esfera esta el vector
if 0.5-tol <= countsKet0  <=0.5+tol: # en el eje Z
    print('El qubit se encuentra en el ecuador de Z')
elif countsKet0 < 0.5-tol:
    print('El qubit se encuentra en el hemisferio sur de Z')
else:
    print('El qubit se encuentra en el hemisferio norte de Z')


if 0.5-tol <= countsKetPlus  <=0.5+tol: # en el eje X
    print('El qubit se encuentra en el ecuador de X')
elif countsKetPlus > 0.5+tol:
    print('El qubit se encuentra en el frente en X')
else:
    print('El qubit se encuentra en el fondo en X')


if 0.5-tol <= countsKetI  <=0.5+tol: # en el eje Y
    print('El qubit se encuentra en el ecuador de Y')
elif countsKetI > 0.5+tol:
    print('El qubit se encuentra a la derecha en Y')
else:
    print('El qubit se encuentra a la izquierda en Y')

phi_aprox= 2*np.arccos( np.sqrt(countsKet0) )
print('phi real={:.3f} y aprox={:.3f}'.format(phi, phi_aprox))


# Si countsY_diff ~= 0 y countsX_diff ~= 0, es el ket |0> o el |1>
if -tol <= countsX_diff < tol and -tol <= countsY_diff < tol:
    theta_aprox= 0
else:
    theta_aprox= np.arctan2(countsY_diff, countsX_diff)
print('theta real={:.3f} y theta aprox={:.3f}'.format(theta, theta_aprox))

alpha0= np.cos(phi_aprox/2)
alpha1= np.sin(phi_aprox)/2*np.exp(1.j*theta_aprox)
sv_resul= Statevector([alpha0, alpha1])
print('Estado simulado a aproximar: {}'.format( sv_prep ))
print('Estado reconstruido: {}'.format(sv_resul))

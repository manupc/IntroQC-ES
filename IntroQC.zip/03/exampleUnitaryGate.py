"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.circuit.library import UnitaryGate
from qiskit.quantum_info import Statevector

Xmatrix = np.array([[0, 1],
                    [1, 0]], dtype=complex)

Xgate = UnitaryGate(Xmatrix, label='NOT')

# Mostrar informacion del objeto UnitaryGate
print('Puerta cuantica NOT:')
print(Xgate)

# Mostrar informacion de la matriz unitaria
U = Xgate.params[0]
print('\nMatriz Unitaria U:', type(U))
print(U)

# Obtener la adjunta
UT = Xgate.adjoint().params[0]
print('\nAdjunta Unitaria UT:', type(UT))
print(UT)

# Verificacion de la matriz unitaria
print('\nU @ UT:')
print(U @ UT)

# Creacion del estado cuantico |0> en NumPy
psi = Statevector.from_label('0').data

# Simulacion de la evolucion del estado
psi_prime = U @ psi.reshape(-1, 1)
print('\nNOT|psi>:')
print(psi_prime.squeeze())
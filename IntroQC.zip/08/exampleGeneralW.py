"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np

# Numero de qubits
nqb= 5

# Circuito cuantico
qc= QuantumCircuit(nqb)

n= nqb
phi= 2*np.arccos(1/np.sqrt(n))
qc.ry(phi, 0)

for i in range(1, n-1):
    n= n-1
    phi= 2*np.arccos(1/np.sqrt(n))
    qc.cry(phi, i-1, i)

for i in reversed(range(1, nqb)):
    qc.cx(i-1, i)
qc.x(0)
qc.save_statevector()

# Simulacion
sim= AerSimulator()
sv= sim.run( transpile(qc, sim), shots= 1).result().get_statevector()

# Mostramos vector de estado
sv_dict= sv.to_dict(decimals=3)
print('Amplitudes del estado |W>_{}:'.format(nqb))
for ket in sv_dict:
    print('\t{} : {}'.format(ket[::-1], sv_dict[ket]))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np

# Angulos para crear el estado q_t a enviar
phi= np.pi/2
lmbda= np.pi/2

# Circuito de preparacion de estado
qc_s= QuantumCircuit(3)
qc_s.ry(phi, 0)
qc_s.p(lmbda, 0)

# Simulacion
qc= qc_s.copy()
qc.save_statevector()

sim= AerSimulator()
sv= sim.run(qc, shots= 1).result().get_statevector()
sv_dict= sv.to_dict(decimals= 3)
print('Estado inicial del qubit a teletransportar:')
for ket in sv_dict:
    print('\t{} : {}'.format(ket[-1], sv_dict[ket]))


# Circuito de entrelazamiento
qc_e= QuantumCircuit(3)
qc_e.h(1)
qc_e.cx(1, 2)

# Circuito de cambio de base
qc_b= QuantumCircuit(3)
qc_b.cx(0,1)
qc_b.h(0)

# Arreglos finales
qc_f= QuantumCircuit(3)
qc_f.cx(1, 2)
qc_f.cz(0, 2)


# Circuito final
qc= qc_s.compose(qc_e).compose(qc_b).compose(qc_f)
qc.save_statevector()

# Simulacion
sv= sim.run(transpile(qc, sim), shots= 1).result().get_statevector()
sv_dict= sv.to_dict()
print('\nEstado final del circuito:')
for ket in sv_dict:
    print('\t{} : {}'.format(ket[::-1], sv_dict[ket]))
    
# Calcular el estado de q_d individualmente
qd_state= np.zeros(2, dtype=complex)
qd_n_state= np.zeros(2, dtype=int)
for ket in sv_dict:
    state= int(ket[0])
    qd_state[ state ]+= sv_dict[ket]
    qd_n_state[ state ]+= 1

# Normalizamos las amplitudes
qd_state /= np.sqrt(qd_n_state)
print('\nEstado final del qubit q_d:')
for i in range(2):
    print('\t{} : {}'.format(i, qd_state[i]))
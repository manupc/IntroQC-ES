"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator
import numpy as np


# Funcion para aplicar el test SWAP sobre un circuito cuantico
# ENTRADAS
#   qc: Circuito cuantico sobre el que se aplica el test SWAP
#   qA, qB : Registros cuanticos a comparar
#   qD: Registro cuantico con el qubit donde se almacena la comparacion
# SALIDA: Una copia de qc con el test SWAP aplicado sobre qA y qB
def SWAPtest(qc : QuantumCircuit, 
             qA: QuantumRegister, qB: QuantumRegister, qD : QuantumRegister):
    
    # Obtenemos el tam. de los registros a comparar
    assert(len(qA) == len(qB))
    n= len(qA)
    
    qcSwaps= qc.copy()

    # Multi-qubit swap test
    qcSwaps.h(qD)
    for i in range(n):
        qcSwaps.cswap(qD, qA[i], qB[i])
    qcSwaps.h(qD)
    
    return qcSwaps
    
    
# Sample points
points= np.array( [[0, 0],
                   [0, 1],
                   [1, 0],
                   [1, 1]], dtype=float)
m= points.shape[1] # Dimension de cada punto


# Creacion de registros cuanticos
qA= QuantumRegister(size=m, name='qA')
qB= QuantumRegister(size=m, name='qB')
qD= QuantumRegister(size=1, name='qD')
cD= ClassicalRegister(size=1, name='cD')

# Creacion de parametros para codificacion de datos
param_A= ParameterVector(name='pA', length=m)
param_B= ParameterVector(name='pB', length=m)


# Circuito final
qc= QuantumCircuit(qD, qA, qB, cD)

# Codificacion de datos
for i in range(len(qA)):
    qc.rx(param_A[i]*np.pi, qA[i])
    qc.rx(param_B[i]*np.pi, qB[i])

# Aplicacion del test SWAP
qc= SWAPtest(qc, qA, qB, qD)

# Medicion
qc.measure(qD, cD)



### Simulacion
qcs= []
comparisons= {}
for a in range(len(points)):
    point_a= points[a, :]
    for b in range(a, len(points)):
        point_b= points[b, :]
        qc_current= qc.assign_parameters({
            param_A : point_a,
            param_B : point_b
            })
        qcs.append( qc_current)
        comparisons[ (a,b) ]= qc_current

sim= AerSimulator()
qct= transpile(qcs, sim)
nshots= 2048
results= sim.run( qcs, shots=nshots ).result()


# Resultados esperados de la simulacion (little endian)
for a in range(len(points)):
    for b in range(a, len(points)):
        circuit= comparisons[(a, b)]
        counts= results.get_counts(circuit)
        d_Q= (0 if '1' not in counts else counts['1'])/nshots
        print('d({}, {})= {:.3f}'.format(points[a], points[b], d_Q))
        
        euclidean= np.sqrt(np.sum( (points[a] - points[b])**2 ))
        print('\tEuclidean({}, {})= {:.3f}'.format(points[a], points[b], euclidean))
    

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, DensityMatrix
import numpy as np

#######
# Simulacion de resultados con estados mixtos

# ket |00>
ket00= np.zeros(4, dtype=complex)
ket00[0]= 1

# ket |10>
ket10= np.zeros(4, dtype=complex)
ket10[1]= 1 # indice 1 por la representacion little endian

# matriz de densidad |00><00|
rho00= ket00.reshape(-1, 1) @ ket00.reshape(1, -1)

# matriz de densidad |01><01|
rho10= ket10.reshape(-1, 1) @ ket10.reshape(1, -1)

# Matriz de densidad 0.5|00><00| + 0.5|01><01|
rho= 0.5*rho00 + 0.5*rho10


# Creacion de la matriz de densidad
mixed= DensityMatrix(data= rho)

print('Estado mixto inicial:')
print(mixed)

# Circuito cuantico
qc= QuantumCircuit(2)
qc.cx(0, 1)

# Simulacion del circuito
final_mixed= mixed.evolve(qc)
print('\nEstado final tras simular el circuito:')
print(final_mixed)


#######
# Simulacion del circuito con estados puros
sv= Statevector( (ket00 + ket10)/np.sqrt(2) )
print('\nEstado puro inicial:')
print( DensityMatrix(sv) )


# Simulacion del circuito
final_sv= sv.evolve(qc)
print('\nEstado puro final:')
print( DensityMatrix(final_sv) )

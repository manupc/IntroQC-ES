"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

# Preparacion de estado
qc_s= QuantumCircuit(3)
qc_s.h([0,1])

# Ansatz
qc_f= QuantumCircuit(3)
qc_f.ccx(0, 1, 2, '00')
qc_f.cx(0, 2)
qc_f.cx(1, 2)

# Circuito final
qc= qc_s.compose(qc_f)
qc.save_statevector()

# Simulacion
sim= AerSimulator()
sv= sim.run(transpile(qc, sim), shots= 1).result().get_statevector()

# Mostrar resultados
print('Estado final:')
sv_dict= sv.to_dict()
for ket in sv_dict:
    rev_ket= ket[::-1]
    print('\tEntradas: {}. Salida: {}'.format(rev_ket[:-1], rev_ket[-1]))
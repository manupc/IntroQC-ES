"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt

# Calculamos la DFT de una funcion discreta dada por una secuencia de puntos f
def DFT(f : np.ndarray):
    
    N= len(f) # Numero de muestras
    ns= np.arange(N) # indices de f
    ks= ns.reshape((N, 1)) # indices de g
    exps= np.exp(-2*np.pi*1.j*ks*ns/N) # exponenciales
    g = np.dot(exps, f)
    return g
        
# Calculamos la DFT inversa de una funcion discreta dada por una secuencia de puntos g
def IDFT(g : np.ndarray):

    N= len(g) # Number of samples
    ks= np.arange(N) # indices de g
    ns= ks.reshape((N, 1)) # indices de f
    exps= np.exp(2*np.pi*1.j*ns*ks/N) # exponenciales
    f = (np.dot(exps, g).real/N).astype(float)
    f[np.isclose(f, 0)]= 0 # Evitar errores de aproximacion
    return f


# Funcion para obtener N muestras de una funcion seno de frecuencia freq Hz
# a lo largo de duration segundos
sineWave= lambda N, duration, freq: (np.sin(2 * np.pi * np.arange(N * duration) * freq / N)).astype(np.float32)


# Funcion a representar
N = 100  # Numero de muestras (frecuencia de muestreo)
duration = 2  # Duracion de la onda (segundos)

# Generar funciones
freq = 2  # Frecuencia (Hz) de la onda
fa = 0.75*sineWave(N, duration, freq)
freq = 3  # Frecuencia (Hz) de la onda
fb = 0.5*sineWave(N, duration, freq)
f= fa + fb


# Mostramos onda muestreada
ts= 1/N # Periodo de muestreo
t = np.arange(0,duration,ts) # Instantes de tiempo donde se muestrea la onda

fig= plt.figure()
plt.plot(t, f)
plt.plot(t, f, '.')
plt.xlabel('t')
plt.ylabel('f')
plt.show()


g= DFT(f) # Pasamos f al dominio de la frecuencia

# Calculamos amplitudes/intensidad de cada onda individual
A= np.abs(g)/N
A[np.isclose(A, 0)]= 0


lenG= len(g) # Numeros de elementos en la funcion g
n= np.arange(lenG) # Cada uno de los elementos
Ts= lenG/N # Periodos entre frecuencias en g
freq = n/Ts # Frecuencias existentes en g
fig= plt.figure()
plt.stem(freq, A, 'o')
plt.show()

# Reconstruccion de f a partir de g
f_rev= IDFT(g)
fig= plt.figure()
plt.plot(t, f)
plt.xlabel('t')
plt.ylabel('f')
plt.plot(t, f_rev, '.')


# Calculamos amplitudes/intensidad de cada onda individual
# sin duplicidad por simetria
g= g[:len(g)//2]
A= np.abs(g)/N
A[np.isclose(A, 0)]= 0


lenG= len(g) # Numeros de elementos en la funcion g
n= np.arange(lenG) # Cada uno de los elementos
Ts= 2*lenG/N # Periodos entre frecuencias en g
freq = n/Ts # Frecuencias existentes en g

fig= plt.figure()
plt.stem(freq[:20], A[:20], 'o')
plt.xlabel('freq. (Hz)')
plt.ylabel('A')
plt.show()






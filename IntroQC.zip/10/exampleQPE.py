"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import QFTGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


# Modulo para incluir QPE de la puerta X en el circuito qc 
def QPE(qc : QuantumCircuit, b : QuantumRegister, psi: QuantumRegister):
    
    n= len(b)
    qc.h(b) # Puerta H inicial heredada del test de Hadamard

    for i in range(n): # Inclusion de CU**(2**n)
        exponent= 2**i
        for j in range(exponent):
            qc.cx(control_qubit= n-i-1, target_qubit= psi)
    for i in range(n//2): # Paso a little endian para QFT de Qiskit
        qc.swap(i, n-i-1)
    
    iqft= QFTGate(num_qubits=n) # Transformada de Fourier inversa
    
    qc.append(iqft.inverse(), b)
    return qc


# Vectores propios de la puerta Z
svs= { '0' : Statevector.from_label('0'), 
       '1' : Statevector.from_label('1'), 
       '+' : Statevector.from_label('+'), 
       '-' : Statevector.from_label('-'), }


n_shots= 2048
n= 2
for state in svs:
    
    # Obtencion de vector de prueba
    sv= svs[state]
    
    # Creacion del circuito
    b= QuantumRegister(size=n, name='qb')
    cb= ClassicalRegister(size=n, name='cb')
    psi= QuantumRegister(size=1, name='qpsi')

    qc= QuantumCircuit(b, psi, cb)
    qc.initialize(sv, psi[:])
    qc= QPE(qc, b, psi)
    qc.measure(b, cb)
    
    # Simulacion
    sim= AerSimulator()
    counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()
    
    if len(counts) != 1:
        print('\tEl estado |{}> no es vector propio de X. Mediciones: {}'.format(state, counts))
    else:
        ket= list(counts.keys())[0] # Obtenemos ket de salida
        binlambda= 0
        for k in range(len(ket)):
            bk= int(ket[k])
            binlambda+= bk*(2**(-k-1))
        lmbda= 2*np.pi*binlambda
        print('Estimacion de la fase del estado |{}>: {}'.format(state, lmbda))

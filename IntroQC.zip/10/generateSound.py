"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt


# Funcion para obtener N muestras de una funcion seno de frecuencia freq Hz
# a lo largo de duration segundos
sineWave= lambda N, duration, freq: (np.sin(2 * np.pi * np.arange(N * duration) * freq / N)).astype(np.float32)


# Funcion a representar
N = 100  # Numero de muestras (frecuencia de muestreo)
duration = 2  # Duracion de la onda (segundos)

# Mostrar funciones
freq = 2  # Frecuencia (Hz) de la onda
faplot = 0.75*sineWave(100, duration, freq)
freq = 3  # Frecuencia (Hz) de la onda
fbplot = 0.5*sineWave(100, duration, freq)
fplot= faplot+fbplot

ts= 1/N # Periodo de muestreo
t = np.arange(0,duration,ts) # Instantes de tiempo donde se muestrea la onda
plt.plot(t, faplot, '--')
plt.plot(t, fbplot, '.')
plt.plot(t, fplot)
plt.legend(['fa', 'fb', 'f'])
plt.show()


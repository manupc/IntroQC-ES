"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






N= 253 # N=p*q, desconocidos
e= 233 # Clave publica
d= 237 # Clave privada

# Funcion para encriptar y desencriptar un mensaje con RSA
#   v: mensaje (o mensaje encriptado)
#   k: Clave publica para encriptar, clave privada para desencriptar
#   N: Valor modular
def RSA(v:int, k:int, N:int):
    return (v**k)%N

# Encriptacion de una secuencia de mensajes
secuencia_m= 'DISFRUTA ESTE LIBRO.'
print('Mensaje a encriptar: {}'.format(secuencia_m))
encriptado= [ RSA( ord(m), e, N) for m in secuencia_m]

# Transformacion a texto de la secuencia a enviar
secuencia_cm_txt= ''.join(chr(cm) for cm in encriptado)

# Enviar mensaje encriptado
print('Se envia el siguiente mensaje encriptado: {}'.format(secuencia_cm_txt))

# Obtencion de la secuencia de mensajes encriptados en el destino
decodificado= [ RSA(ord(cm), d, N) for cm in secuencia_cm_txt ]
decodificado_txt= ''.join(chr(cm) for cm in decodificado)
print('El receptor ha decodificado: {}'.format(decodificado_txt))

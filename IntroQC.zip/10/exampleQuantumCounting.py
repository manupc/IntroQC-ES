"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import grover_operator, phase_estimation, ZGate
from qiskit.visualization import plot_histogram
from qiskit.quantum_info import Statevector
from qiskit.result import Counts
from qiskit_aer import AerSimulator
from IPython.display import display
import numpy as np


# Calcula un oraculo que marca a -1 los estados de entrada en list_states
def  OracleFunc(list_states : list[str], reverse_state= False):
    n= len(list_states[0])
    
    qc= QuantumCircuit(n)
    for state in list_states:
        rev_state= state[::-1] if reverse_state else state
        if rev_state[-1] == '0':
            qc.x(n-1)
        mcz= ZGate().control(num_ctrl_qubits=n-1, ctrl_state=rev_state[:-1][::-1])
        qc.append(mcz, list(range(n)))
        if rev_state[-1] == '0':
            qc.x(n-1)
    return qc


# Devuelve un objeto Statevector con el vector propio |G_+>
# del operador de grover que marca la lista de estados list_states
# dada como argumento.
def Gplus(list_states : list[str], reverse_state= False):

    n= len(list_states[0]) # No. qubits
    m= len(list_states) # No. estados marcados
    denM= np.sqrt(2*m)
    denMperp= np.sqrt(2*(2**n - m))
    
    # Inicializamos amplitudes del Statevector v con |M^\perp>
    v= 1.j*np.ones(2**n, dtype=complex)/denMperp 
    
    # Insertamos |M> en v
    for state in list_states:
        rev_state= state[::-1] if reverse_state else state
        int_state= int(rev_state, 2)
        v[int_state]= 1/denM
    return Statevector(v)


n= 3 # Numero de qubits sobre los que se aplica Grover
n_prec= 5 # Numero de qubits de precision de estimacion de la fase

# Estados a marcar por el oraculo
list_states= ['110','000', '011']

# Generacion del vector propio de Grover 
psi= Gplus(list_states)

# Generacion del operador de Grover con el oraculo 
Oracle= OracleFunc(list_states)
grv= grover_operator(oracle= Oracle)
    
# Registro para Grover
qr_grv= QuantumRegister(n, 'qrgrv')

# Registros para estimacion de la fase
qr_phase= QuantumRegister(n_prec, 'qrphase')
cr_phase= ClassicalRegister(n_prec, 'crphase')

# Circuito cuantico
qc= QuantumCircuit(qr_phase, qr_grv, cr_phase)

# Inicializar el vector propio de Grover
qc.initialize(psi, qr_grv[:])

# Algoritmo de QPE
qpe= phase_estimation(num_evaluation_qubits=n_prec, unitary=grv)    

# Insercion de QPE y medicion
qc.append(qpe, qr_phase[:]+qr_grv[:])
qc.measure(qr_phase, cr_phase)

# Simulacion
n_shots= 2048
sim= AerSimulator()
counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()

# Mostrar resultados de mediciones como histograma
f= plot_histogram(counts)
display(f)

# Mostrar resultados de mediciones por consola
print('Mediciones realizadas:')
for ket in counts:
    print('\t|{}> : {} veces.'.format(ket, counts[ket]))


# Estimacion de la fase
ket= Counts.most_frequent(counts)[::-1] # Obtenemos la medicion mas frecuente

# Calculamos la aproximacion de theta
bintheta= 0
for k in range(len(ket)):
    bk= int(ket[k])
    bintheta+= bk*(2**(-k-1))
theta= 2*np.pi*bintheta
print('La fase de Grover es theta= {}'.format(theta))

# Calcular el valor m
solution = np.round(2**n * np.sin(theta*0.5)**2)
print('\nLa solucion al problema de contabilizacion cuantica es: {}'.format(solution))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import QFTGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import random_statevector
import numpy as np

# Verificacion del funcionamiento de QFT e IQFT
# con un estado cuantico aleatorio
n= 2
sv= random_statevector(dims= 2**n)
print('Estado cuantico inicial: {}'.format(sv))

# Creacion del circuito cuantico
qc= QuantumCircuit(n)
qc.initialize(sv)

qft= QFTGate(num_qubits=n)
iqft= QFTGate(num_qubits=n).inverse()

qc.append(qft, list(range(n)))
qc.append(iqft, list(range(n)))
qc.save_statevector()

sim= AerSimulator()
svr= sim.run(transpile(qc, sim), shots=1).result().get_statevector()
isClose= np.all(np.isclose(sv.data, svr.data))
print('Estado cuantico resultante: {}'.format(svr))
print('El estado cuantico inicial coindice con el final: {}'.format(isClose))


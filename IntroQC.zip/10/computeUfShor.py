"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import XGate
from IPython.display import display

# Calcula la tabla de verdad de f(k)=x**k mod N,
# para valores dados de x y N y 0<=k<2**n
def TruthTable(x, n, N):
    
    K= 2**n
    logN= int(np.ceil(np.log2(N)))
    table= np.zeros((n+logN, K), dtype=int)
    
    for k in range(K):
        f_k= (x**k)%N
        bink= bin(k)[2:].rjust(n, '0')
        binf_k= bin(f_k)[2:].rjust(logN, '0')
        
        intk= np.array([int(k) for k in bink], dtype=int)
        intf_k= np.array([int(f_k) for f_k in binf_k], dtype=int)
        table[:n, k]= intk[:]
        table[n:, k]= intf_k[:]
    return table

# Crea el circuito que implementa la matriz unitaria Uf
# para calcular f(k)= x**k mod N para valores dados de x y N
# con valores de k en 0 <= k < 2**n
def CreateUf(x : int, n: int, N : int):
    
    logN= int(np.ceil(np.log2(N)))
    table= TruthTable(x, n, N)
    
    qc= QuantumCircuit(n+logN)
    for k in range(table.shape[1]): # Columna k
    
        # bit-esimo bit de salida a 1 en f(k)
        bits= n+np.where(table[n:, k] == 1)[0]

        # Crear puerta X controlada multiple por las entradas k            
        controls="".join(str(table[b, k]) for b in range(n))
        mcx= XGate().control(num_ctrl_qubits=n, ctrl_state=controls)
        for bit in bits:
            qc.append(mcx, list(range(n))+[bit])
    return qc



N= 6 # Numero a factorizar
x= 2 # valor x seleccionado
n= 3 # Precision para el calculo de r
logN= int(np.ceil(np.log2(N)))

# Calculamos la tabla de verdad
table= TruthTable(x, n, N)
print('Tabla de verdad:')
print(table)

#Creacion del circuito
qc_Uf= CreateUf(x, n, N)
f= qc_Uf.draw('mpl')
display(f)
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import grover_operator, ZGate
from qiskit.visualization import plot_histogram
from qiskit_aer import AerSimulator
import numpy as np
from IPython.display import display


n= 3 # Numero de qubits
m= 3 # Numero de estados marcados
qr= QuantumRegister(n, 'qr')
cr= ClassicalRegister(n, 'cr')

# Calcula un oraculo que marca a -1 los estados de entrada en list_states
def  OracleFunc(list_states : list[str], reverse_state= False):
    n= len(list_states[0])
    
    qc= QuantumCircuit(n)
    for state in list_states:
        rev_state= state[::-1] if reverse_state else state
        if rev_state[-1] == '0':
            qc.x(n-1)
        mcz= ZGate().control(num_ctrl_qubits=n-1, ctrl_state=rev_state[:-1][::-1])
        qc.append(mcz, list(range(n)))
        if rev_state[-1] == '0':
            qc.x(n-1)
    return qc


# Circuito cuantico
qc= QuantumCircuit(qr, cr)
qc.h(qr)

# Generacion del operador de Grover con el oraculo 
Oracle= OracleFunc(['010', '011', '111']) # Marcado de |010>, |011>, |111>
grv= grover_operator(oracle= Oracle)


# Numero de iteraciones a realizar con Grover
k= int(0.25*np.pi*np.sqrt(2**n / m) )
for i in range(k):
    qc.append(grv, qr[:])

# Transformamos de little endian a big endian
for i in range(int(np.ceil(n//2))): 
    qc.swap(i, n-i-1)
qc.measure(qr, cr)

# Simulacion
n_shots= 2048
sim= AerSimulator()
counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()

# Mostramos histograma de resultados
f= plot_histogram(counts)
display(f)

# Mosgtrmos resultados por consola
print('Mediciones para cada ket de la base computational tras {} ejecuciones:'.format(n_shots))
for ket in counts:
    print('\t|{}> : {} veces.'.format(ket, counts[ket]))
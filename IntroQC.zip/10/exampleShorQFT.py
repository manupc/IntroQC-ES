"""
This program is free software: you can redistribute it and/or modify it under  the terms of the GNU General Public License as published by the Free Software  Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for  more details.

You should have received a copy of the GNU General Public License along with  this program. If not, see <https://www.gnu.org/licenses/>. 
"""

from qiskit import QuantumCircuit, transpile, QuantumRegister, ClassicalRegister
from qiskit.circuit.library import QFTGate, XGate
from qiskit_aer import AerSimulator
from fractions import Fraction
import numpy as np



# Calcula la tabla de verdad de f(k)=x**k mod N,
# para valores dados de x y N y 0<=k<2**n
def TruthTable(x, n, N):
    
    K= 2**n
    logN= int(np.ceil(np.log2(N)))
    table= np.zeros((n+logN, K), dtype=int)
    
    for k in range(K):
        f_k= (x**k)%N
        bink= bin(k)[2:].rjust(n, '0')
        binf_k= bin(f_k)[2:].rjust(logN, '0')
        
        intk= np.array([int(k) for k in bink], dtype=int)
        intf_k= np.array([int(f_k) for f_k in binf_k], dtype=int)
        table[:n, k]= intk[:]
        table[n:, k]= intf_k[:]
    return table

# Crea el circuito que implementa la matriz unitaria Uf
# para calcular f(k)= x**k mod N para valores dados de x y N
# con valores de k en 0 <= k < 2**n
def CreateUf(x : int, n: int, N : int):
    
    logN= int(np.ceil(np.log2(N)))
    table= TruthTable(x, n, N)
    
    qc= QuantumCircuit(n+logN)
    for k in range(table.shape[1]): # Columna k
    
        # bit-esimo bit de salida a 1 en f(k)
        bits= n+np.where(table[n:, k] == 1)[0]

        # Crear puerta X controlada multiple por las entradas k            
        controls=''.join(str(table[b, k]) for b in range(n))
        mcx= XGate().control(num_ctrl_qubits=n, ctrl_state=controls)
        for bit in bits:
            qc.append(mcx, list(range(n))+[bit])
    return qc.to_gate()


# Devuelve el circuito para encontrar el periodo de f(k)=x**k mod N,
# con 0<=k<2**n
def PeriodFindingCircuit(x:int, n:int, N:int):
    
    logN= int(np.ceil(np.log2(N)))
    
    qP= QuantumRegister(size=n)
    cP= ClassicalRegister(size=n)
    qF= QuantumRegister(size=logN)
    qc = QuantumCircuit(qP, qF, cP)
    
    # Paso 1: Pasar K a superposicion
    qc.h(qP)
    
    # Paso 2: Aplicar Uf
    Uf= CreateUf(x, n, N)
    qc.append(Uf, qP[:]+qF[:])

    qft= QFTGate(num_qubits=n) # Paso 3: QFT sobre K
    
    qc.append(qft, qP)
    
    # Medicion final
    qc.measure(qP, cP)
    return qc


# Encuentra factores de N con precision n bits
def FindFactor(n:int, N:int, max_iter= 30, debug=True):
    
    Found= False
    iteration= 0
    while not Found:

        iteration+= 1 # Actualizar iteracion actual
        if debug:
            print('Iteracion: {}\n-------------'.format(iteration))
        
        # Finalizar por numero de iteraciones
        if max_iter is not None and iteration >= max_iter:
            return [None, None]
        
        # Seleccionar x
        x= np.random.randint(2, N)
        if debug:
            print('\t Seleccionado x={}'.format(x))
        
        # Si x ya es solucion, devolverla
        gcd= np.gcd(N, x)
        if gcd != 1:
            if debug:
                print('MCD({},{})={}. Hubo suerte.'.format(N, x, gcd))
            return [gcd, 1]

        # Ejecucion del circuito para encontrar la fase
        qc= PeriodFindingCircuit(x, n, N)
        sim = AerSimulator()
        counts= sim.run(transpile(qc, sim), shots=1).result().get_counts()
        ket= list(counts.keys())[0]
        
        # Hallamos periodo segun c/r= lmbda/(2**n)
        theta_K_frac = int(ket,2)/(2**n)
        if debug:
            print('\t Obtenida theta/K={}'.format(theta_K_frac))
        
        # Comprobamos que theta != 0. En otro caso, recalculamos
        if np.isclose(theta_K_frac, 0):
            continue
        
        # Calculamos r
        c_r_frac= Fraction(theta_K_frac).limit_denominator(N)
        r= c_r_frac.denominator
            
        # Hemos obtenido un periodo impar, recalculamos
        if r%2 != 0:
            if debug:
                print('No ha sido posible encontrar r par')
            continue
    
        # obtenemos factores
        factors = [np.gcd(x**(r//2)-1, N), np.gcd(x**(r//2)+1, N)]
        if debug:
            print('\t Factores encontrados = {}'.format(factors))
            
        # Comprobamos que no son triviales [1,N]
        for factor in factors:
            if factor not in [1,N] and (N % factor) == 0:
                Found= True
    return factors
    

# Ejemplo de funcionamiento
N=21  # Valor a factorizar
n= 5  # Numero de qubits a usar para la aproximacion de r

factors= FindFactor(n, N)
print('La salida del algoritmo es: {}'.format(factors))

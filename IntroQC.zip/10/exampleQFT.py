"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.visualization import plot_bloch_multivector
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, random_statevector
from IPython.display import display
import numpy as np

# Genera un circuito cuantico con la QFT de n qubits
def QFT(n : int):
    
    qc= QuantumCircuit(n)
    
    for k in range(n):
        qc.h(k)
        for j in range(k+1, n):
            qc.cp(theta= np.pi/(2**(j-k)), control_qubit=j, target_qubit=k)
    
    middle= n//2
    for k in range(middle):
        qc.swap(k, n-k-1)
    return qc.to_gate()
        
# Genera un circuito cuantico con la IQFT de n qubits
def IQFT(n : int):
    
    qc= QuantumCircuit(n)
    
    middle= n//2
    for k in range(middle-1, -1, -1):
        qc.swap(k, n-k-1)
    
    for k in range(n-1, -1, -1):
        for j in range(n-1, k, -1):
            qc.cp(theta= -np.pi/(2**(j-k)), control_qubit=j, target_qubit=k)
        qc.h(k)
    return qc.to_gate()

# Verificacion del funcionamiento de QFT e IQFT
# con un estado cuantico aleatorio
n= 2
sv= random_statevector(dims= 2**n)
print('Estado cuantico inicial: {}'.format(sv))

# Creacion del circuito cuantico
qc= QuantumCircuit(n)
qc.initialize(sv)
qc.append(QFT(n), list(range(n)))
qc.append(IQFT(n), list(range(n)))
qc.save_statevector()

sim= AerSimulator()
svr= sim.run(transpile(qc, sim), shots=1).result().get_statevector()
isClose= np.all(np.isclose(sv.data, svr.data))
print('Estado cuantico resultante: {}'.format(svr))
print('El estado cuantico inicial coindice con el final: {}'.format(isClose))


# Hacemos QFT de los kets de la base computacional
# de estados de n qubits
for k in range(2**n):
    
    binket= bin(k)[2:].rjust(n, '0')
    binket= binket[::-1] # Ajuste a little endian de Qiskit
    
    # Obtencion del estado cuantico de entrada
    sv= Statevector.from_label(binket)
    
    # Creacion del circuito de la QFT y simulacion
    qc= QuantumCircuit(n)
    qc.initialize(sv)
    qc.append(QFT(n), list(range(n)))
    
    # Intercambiamos los qubits debido a little endian de Qiskit
    middle= n//2
    for k in range(middle):
        qc.swap(k, n-k-1)
    qc.save_statevector()
    svr= sim.run(transpile(qc, sim), shots=1).result().get_statevector()

    # Mostrar esferas de Bloch de cada qubit para estados de entrada y salida
    f= plot_bloch_multivector(sv, title='Original: |{}>'.format(k))
    display(f)
    f= plot_bloch_multivector(svr, title='QFT|{}>'.format(k))
    display(f)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import phase_estimation, XGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


# Vectores propios de la puerta Z
svs= { '0' : Statevector.from_label('0'), 
       '1' : Statevector.from_label('1'), 
       '+' : Statevector.from_label('+'), 
       '-' : Statevector.from_label('-'), }


n_shots= 2048
n= 2
for state in svs:
    
    # Obtencion de vector de prueba
    sv= svs[state]
    
    # Creacion del circuito
    b= QuantumRegister(size=n, name='qb')
    cb= ClassicalRegister(size=n, name='cb')
    psi= QuantumRegister(size=1, name='qpsi')

    qc= QuantumCircuit(b, psi, cb)
    qc.initialize(sv, psi[:])
    QPE= phase_estimation(num_evaluation_qubits= n, unitary= XGate())
    qc.append(QPE, b[:]+psi[:])

    # Intercambiar qubits de little endian a big endian
    middle= n//2
    for k in range(middle):
        qc.swap(b[k], b[n-k-1])
    
    qc.measure(b, cb)
    
    # Simulacion
    sim= AerSimulator()
    counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()
    

    if len(counts) != 1:
        print('\tEl estado |{}> no es vector propio de X. Mediciones: {}'.format(state, counts))
    else:
        ket= list(counts.keys())[0] # Obtenemos ket de salida
        bintheta= 0
        for k in range(len(ket)):
            bk= int(ket[k])
            bintheta+= bk*(2**(-k-1))
        theta= 2*np.pi*bintheta
        print('Estimacion de la fase del estado |{}>: {}'.format(state, theta))

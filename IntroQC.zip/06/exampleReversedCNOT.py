"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator



# Circuito cuantico de 2 qubits
qc1= QuantumCircuit(2)
qc1.h(0)
qc1.cx(1, 0, ctrl_state='0')
qc1.x(1)
qc1.save_statevector()


# Circuito cuantico de 2 qubits descompuesto
qc2= QuantumCircuit(2)
qc2.h(0)
qc2.swap(0,1)
qc2.x(0)
qc2.cx(0,1)
qc2.x(0)
qc2.swap(0,1)
qc2.x(1)
qc2.save_statevector()


### Simulacion
sim= AerSimulator()
qcs= [ transpile(qc1, sim), transpile(qc2, sim)]
results= sim.run( qcs, shots=1 ).result()

# Resultados esperados de la simulacion (little endian)
print('Resultado del circuito sin descomponer:')
print(results.get_statevector(qcs[0]))
print('\nResultado del circuito descompuesto:')
print(results.get_statevector(qcs[1]))
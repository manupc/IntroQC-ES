"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
import numpy as np


# Circuito cuantico de 4 qubits
qc1= QuantumCircuit(4)
qc1.h(3)
qc1.swap(0, 2)
qc1.ccx(0, 3, 2, ctrl_state='10'[::-1])
qc1.cswap(1, 0, 3)
qc1.save_statevector()


# Circuito cuantico de 2 qubits descompuesto
qc2= QuantumCircuit(4)

# Nivel 1
qc2.h(3)
qc2.swap(1,2)
qc2.swap(0, 1)
qc2.swap(1,2)

# Nivel 2
qc2.swap(0, 1)
qc2.swap(2, 3)
qc2.x(2)
qc2.ccx(1, 2, 3)
qc2.x(2)
qc2.swap(2, 3)
qc2.swap(0, 1)

# Nivel 3
qc2.swap(0, 1)
qc2.swap(2, 3)
qc2.cswap(0, 1, 2)
qc2.swap(2, 3)
qc2.swap(0, 1)

qc2.save_statevector()


### Simulacion
sim= AerSimulator()
qcs= [ transpile(qc1, sim), transpile(qc2, sim)]
results= sim.run( qcs, shots=1 ).result()

# Resultados esperados de la simulacion
sv1= results.get_statevector(qcs[0])
sv2= results.get_statevector(qcs[1])

# Mostramos la diferencia maxima entre ambos vectores
diffs= np.abs(sv1.data-sv2.data)
total_diff= np.sum(diffs)
print('La distancia entre sv1 y sv2 es de {}'.format(total_diff))

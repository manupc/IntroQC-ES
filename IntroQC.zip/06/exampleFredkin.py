"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Circuito cuantico
qc= QuantumCircuit(3)
qc.x(1)
qc.cswap(0, 1, 2, ctrl_state='0')
qc.measure_all()


### Simulacion
sim= AerSimulator()
results= sim.run( transpile(qc, sim), shots=1024 ).result()

# Resultados esperados de la simulacion (little endian)
counts= results.get_counts(qc)
print('Salidas de la simulacion:')
for ket in counts:
    print('\tEstado resultante {}: {} veces.'.format( ket[::-1], counts[ket]))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
import numpy as np



# Parametro a usar en el circuito
a= Parameter('a')
b= Parameter('b')

# Circuito cuantico
qc= QuantumCircuit(3, 1)
qc.ry(theta= a, qubit= 0)
qc.ry(theta= b, qubit= 1)
qc.ccx(0, 1, 2, ctrl_state= '01'[::-1]) # Puerta CCNOT
qc.measure(2, 0)


### Simulacion

# Generacion de angulos para los parametros
angles= [ [0, 0],
          [0, np.pi],
          [np.pi, 0], 
          [np.pi, np.pi]]

sim= AerSimulator()
qcs= [ transpile(qc.assign_parameters( {a : angle[0], b : angle[1]} ), sim) for angle in angles]

results= sim.run( qcs, shots=1 ).result()

# Resultados esperados de la simulacion (little endian)
target_sv= ['0', '1', '0', '0']
for angle, qc, sv in zip(angles, qcs, target_sv):
    print('\nAngulos a={} y b={}.'.format(angle[0], angle[1]))
    print('\tEstado resultante: {}'.format( np.array(list(results.get_counts(qc).keys())).squeeze()))
    print('\tSe esperaba: ', sv)

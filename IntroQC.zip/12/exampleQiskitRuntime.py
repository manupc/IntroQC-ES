"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit_ibm_runtime import QiskitRuntimeService


# Obtenemos nuestro token que previamente hemos guardado a fichero
# AVISO: El resto del programa no funcionara correctamente si
# no hemos abierto la cuenta en IBM Cloud y seguido las instrucciones
# para almacenar el API token en el fichero APItoken.txt de la carpeta
# del codigo fuente asociado al libro
with open('APItoken.txt', 'r') as f:
    APIkey= f.readline()[:-1] # Evitamos el salto de linea '\n' final
    CRN= f.readline()[:-1]



# Solicitud de acceso al proveedor
service = QiskitRuntimeService(
    channel='ibm_quantum_platform',
    instance=CRN,
    token=APIkey
)

# Mostrar informacion del plan de acceso a recursos de computacion
print('\nInformacion del plan de acceso gratuito o suscripcion:')
usage= service.active_account()
for k in usage:
    if k=='token' or k=='instance':
        usage[k]= '(...)'
    print('\t{} : {}'.format(k, usage[k]))

# Instancias que tenemos activas en este momento
print('\nInstancias iniciadas o en ejecucion:')
instances= service.instances()
for instance in instances:
    print('Name: {}'.format(instance['name']))
    for data in instance:
        if data =='crn':
            instance[data]= '(...)'
        print('\t{} : {}'.format(data, instance[data]))

# Acceso al servicio de computacion cuantica. 
backend = service.least_busy(simulator=False, operational=True)
print('\nAcceso al back-end permitido. Datos del back-end:')
print('\tNombre: {}'.format(backend.name))
print('\tNo. qubits: {}'.format(backend.num_qubits))
print('\tVersion: {}'.format(backend.backend_version))
print('\tProveedor: {}'.format(backend.provider))
print('\tOperaciones soportadas: {}'.format(backend.operation_names))
print('\tDescripcion: {}'.format(backend.description))



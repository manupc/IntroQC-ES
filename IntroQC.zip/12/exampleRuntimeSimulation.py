"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_ibm_runtime.fake_provider import FakeSherbrooke as Simulator
from qiskit.visualization import plot_histogram
from IPython.display import display

# Creacion del circuito para generar el estado de Bell |Phi^+>
qr= QuantumRegister(2, 'qr')
cr= ClassicalRegister(2, 'cr')
qc = QuantumCircuit(qr, cr)
qc.h(qr[0])
qc.cx(qr[0], qr[1])
qc.measure(qr, cr)


# Acceso al servicio de computacion cuantica
backend = Simulator()
print('Back-end asignado: {} con {} qubits.'.format(backend.name, backend.num_qubits))


# Transformamos circuito al conjunto de instrucciones del computador cuantico asignado
qct= transpile(qc, backend)

# Mostramos circuito transpilado
f= qct.draw('mpl')
display(f)

print('Trabajo puesto en cola. A la espera de nuestro turno...')
results= backend.run([qct], shots= 1024).result()
counts= results.get_counts() # Obtenemos el no. veces de cada posible medicion
    
print('\nResultados: ')
for ket in counts:
    print('{}: {}'.format(ket, counts[ket]))
f= plot_histogram(counts)
display(f)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from time import sleep
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
from qiskit.visualization import plot_histogram
from IPython.display import display

# Creacion del circuito para generar el estado de Bell |Phi^+>
qr= QuantumRegister(2, 'qr')
cr= ClassicalRegister(2, 'cr')
qc = QuantumCircuit(qr, cr)
qc.h(qr[0])
qc.cx(qr[0], qr[1])
qc.measure(qr, cr)


# Obtenemos nuestro token que previamente hemos guardado a fichero
# AVISO: El resto del programa no funcionara correctamente si
# no hemos abierto la cuenta en IBM Cloud y seguido las instrucciones
# para almacenar el API token en el fichero APItoken.txt de la carpeta
# del codigo fuente asociado al libro
with open('APItoken.txt', 'r') as f:
    APIkey= f.readline()[:-1] # Evitamos el salto de linea '\n' final
    CRN= f.readline()[:-1]

# Solicitud de acceso al proveedor
service = QiskitRuntimeService(
    channel='ibm_quantum_platform',
    instance=CRN,
    token=APIkey
)

# Acceso al servicio de computacion cuantica
backend = service.least_busy(min_num_qubits=2, simulator=False, operational=True)
print('Back-end asignado: {} con {} qubits.'.format(backend.name, backend.num_qubits))

# Creacion del servicio para realizar mediciones
sampler = Sampler(backend)

# Transformamos circuito al conjunto de instrucciones del computador cuantico asignado
qct= transpile(qc, backend)

# Mostramos circuito transpilado
f= qct.draw('mpl')
display(f)

print('Trabajo puesto en cola. A la espera de nuestro turno...')
job= sampler.run([qct], shots= 1024)
print('ID de job: {}.'.format(job.job_id()))

while not job.in_final_state():
    sleep(10)
    print('Estado del trabajo: {} ({} s.)'.format(job.status(), job.usage()))
    print('Metricas del trabajo:')

    metrics= job.metrics()
    for m in metrics:
        print('\t{} : {}'.format(m, metrics[m]))

print('\nTRABAJO FINALIZADO.')

# Comprobacion de finalizacion del trabajo
try:
    done= job.done()
except:
    done= False
    
# Comprobacion de errores
error= False
if not done:
    try:
        error= job.errored() 
        errorMessage= job.error_message()
    except:
        error= False
    
# Mostrar resultados de la ejecucion
if error:
    print('El trabajo no pudo completarse: {}'.format(errorMessage))

elif done:
    # Obtenemos resultados
    sampler_results= job.result()[0]
    data= sampler_results.join_data() # Unimos todos los resultados de los bits
    counts= data.get_counts() # Obtenemos el no. veces de cada posible medicion
    
    print('\nResultados: ')
    for ket in counts:
        print('{}: {}'.format(ket, counts[ket]))
    f= plot_histogram(counts)
    display(f)
else:
    print('Error: No se obtuvieron resultados')
    
    
    
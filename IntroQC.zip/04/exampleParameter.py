"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator

phi= Parameter('phi') # Creacion del parametro phi

# Circuito cuantico parametrizado
qc= QuantumCircuit(1)
qc.ry(phi, 0)

qc.save_statevector()


# Valores posibles para los parametros
phi_values= [np.pi/2, np.pi]
expected_states= ['+', '1']

# Instanciar simulador con metodo por defecto 'automatic'
sim= AerSimulator()

for expected, phi_val in zip(expected_states, phi_values):

    # Asignacion de parametros al circuito
    qc_bounded= qc.assign_parameters({phi : phi_val})
    
    # Transpilacion y simulacion
    qct= transpile(qc_bounded, sim)
    sv= sim.run(qct, shots=1).result().get_statevector()
    
    print('\nStatevector resultado para phi={}:'.format(phi_val))
    print(sv)
    print('Statevector esperado:')
    print('|{}>: {}'.format(expected, Statevector.from_label(expected)))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np

# Carga de datos
dataset= np.load('iris.npy', allow_pickle=True).item()

# Obtencion de caracteristicas de los especimenes
X= dataset['data']
print('Forma de las caracteristicas: {}'.format(X.shape))
print('Significado de cada columna:')
for i, name in enumerate(dataset['feature_names']):
    print('\tColumna {}: {}'.format(i, name))


# Obtendicon de las especies de cada especimen
nombres_Y= ['Setosa', 'Versicolor', 'Virginica']
Y= dataset['target']
print('\nForma de las especies: {}'.format(Y.shape))

print('Especies existentes: ')
for i, name in zip(np.unique(Y), nombres_Y):
    print('\tValor {}: especie {}'.format(i, name))

print('\nCaracteristicas del primer ejemplar: ', X[0, :])
print('Especie del primer ejemplar: {}'.format(nombres_Y[Y[0]]))

print('\nCaracteristicas del ultimo ejemplar: ', X[-1, :])
print('Especie del ultimo ejemplar: {}'.format(nombres_Y[Y[-1]]))


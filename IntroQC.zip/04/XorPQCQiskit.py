"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

# Parametros individuales
thetas= ParameterVector('theta', 2)

# Construccion del circuito
qc_prep= QuantumCircuit(1)
qc_prep.h(0)
qc_prep.p(thetas[0], 0)
qc_prep.p(thetas[1], 0)
# Circuito de codificacion de entradas:
display(qc_prep.draw('mpl'))

# Modularizacion del circuito
encoding_module= qc_prep.to_instruction(label='encoding')


# Ansatz
qc_ansatz= QuantumCircuit(1)
qc_ansatz.h(0)
# Circuito ansatz:
display(qc_ansatz.draw('mpl'))

# Modularization del circuito
ansatz_module= qc_ansatz.to_instruction(label='ansatz')

# Circuito final
qc= QuantumCircuit(1)
qc.append(encoding_module, [0])
qc.append(ansatz_module, [0])
qc.measure_all()

# Circuito modular:
display(qc.draw('mpl'))


# RESOLUCION DEL PROBLEMA
# Creacion del conjunto de datos
data= np.array([ 
        [0, 0, 0], # x1=0, x2=0, y=0
        [0, 1, 1], # x1=0, x2=1, y=1
        [1, 0, 1], # x1=1, x2=0, y=1
        [1, 1, 0], # x1=1, x2=1, y=0
      ])
X, Y= data[:, :-1], data[:, -1] # Obtenemos entradas X y salidas Y

W_val= np.pi*X  # Codificacion de parametros desde X en W

# Instanciar simulador con metodo por defecto 'automatic'
sim= AerSimulator()

# Asignacion de valores de parametros: Tantos circuitos como opciones
allCircuits= [transpile( qc.assign_parameters({thetas: values}).decompose(), sim )  for values in W_val]


y_pred= [] # Lista de salidas del algoritmo

# Ejecutamos cada circuito
for qct in allCircuits:
    counts= sim.run(qct, shots=1).result().get_counts()
    y_pred.append(0 if '0' in counts else 1)
y_pred= np.array(y_pred) # Transformamos salidas a np.array

# Calculamos cuantas veces hemos acertado
for x, y, pred in zip(X, Y, y_pred):
    print('XOR({}, {})= {} y el circuito devuelve {}'.format(x[0], x[1], y, pred))
accuracy= np.mean(Y == y_pred)
print('Hemos acertado el {}% de las veces'.format(accuracy*100))



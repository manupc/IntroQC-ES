"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator



# Carga del conjunto de datos y seleccion de caracteristicas
dataset= np.load('iris.npy', allow_pickle=True).item()
X, Y_all= dataset['data'][:, -2:], dataset['target']

# Transformacion de X a angulos
mini, maxi= np.min(X, axis=0), np.max(X, axis=0)
X= np.pi*(X-mini)/(maxi-mini)

# Construccion del modelo de clasificacion en Qiskit
# 1. Circuito de preparacion de estados
x_par= ParameterVector('x', 2) # Codificacion de parametros de entrada

# Codificacion de los atributos de la flor en magnitud y fase
qc_p= QuantumCircuit(1, 1)
qc_p.rx(x_par[0], 0) 
qc_p.rz(x_par[1], 0)


# 2. Circuito ansatz
thetas= ParameterVector('theta', 3) # Parametros del ansatz
qc_a= QuantumCircuit(1, 1)
qc_a.rx(thetas[0], 0)
qc_a.ry(thetas[1], 0)
qc_a.rz(thetas[2], 0)

# 3. Construccion del circuito de decision completo
qc_model= qc_p.compose(qc_a)
qc_model.save_statevector()


# Escogemos 3 valores de parametros thetas al azar
param= np.random.rand(3)
print('Valores para thetas: {}\n'.format(param))

# Instanciamos el simulador Aer
sim= AerSimulator(method='statevector')


# Obtenemos el circuito de codificacion
# para cada patron (flor)
qcs= [qc_model.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X]

# Optimizamos todos los circuitos y ejecutamos simulacion sobre ellos
qcts= transpile(qcs, sim)

# Ejecucion 
result= sim.run(qcts, shots=1).result()

# Obtencion de resultados
svs= [result.get_statevector(qc) for qc in qcs]

print('Primer ejemplar: ', X[0, :])
print('\tEstado cuantico de salida del primer ejemplar: ', svs[0])

print('Ultimo ejemplar: ', X[-1, :])
print('\tEstado cuantico de salida del ultimo ejemplar: ', svs[-1])
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator


# Carga del conjunto de datos y seleccion de caracteristicas
dataset= np.load('iris.npy', allow_pickle=True).item()
X, Y= dataset['data'][:, -2:], dataset['target']

# Transformacion de X a angulos
mini, maxi= np.min(X, axis=0), np.max(X, axis=0)
X= np.pi*(X-mini)/(maxi-mini)


n_shots= 2048 # Numero de ejecuciones a realizar

# Construccion del modelo de clasificacion en Qiskit
# 1. Circuito de preparacion de estados
x_par= ParameterVector('x', 2) # Codificacion de parametros de entrada

# Codificacion de los atributos de la flor en magnitud y fase
qc_p= QuantumCircuit(1, 1)
qc_p.rx(x_par[0], 0) 
qc_p.rz(x_par[1], 0)

# 2. Circuito ansatz
thetas= ParameterVector('theta', 3) # Parametros del ansatz
qc_a= QuantumCircuit(1, 1)
qc_a.rx(thetas[0], 0)
qc_a.ry(thetas[1], 0)
qc_a.rz(thetas[2], 0)

# 3. Construccion del circuito de decision completo
qc_model= qc_p.compose(qc_a)


# 4. Circuitos para medicion en los tres ejes
# Medicion en el eje Z: No necesita cambio de base
qc_ejez= QuantumCircuit(1, 1) 
qc_ejez.measure(qubit= 0, cbit= 0)

# Cambio de base para medir en el eje X
qc_ejex= QuantumCircuit(1, 1)
qc_ejex.h(0)
qc_ejex.measure(qubit= 0, cbit= 0)

# Cambio de base para medir en el eje Y
qc_ejey= QuantumCircuit(1, 1)
qc_ejey.sdg(0)
qc_ejey.h(0)
qc_ejey.measure(qubit= 0, cbit= 0)


# Creamos circuitos de los modelos para medicion en los tres ejes
qc_modelZ= qc_model.compose(qc_ejez)
qc_modelX= qc_model.compose(qc_ejex)
qc_modelY= qc_model.compose(qc_ejey)


# Instanciamos el simulador Aer
sim= AerSimulator(method='statevector')

# Funcion que ejecuta el modelo de estimacion (Circuito cuantico)
# ENTRADAS:
#   X: Valores de entrada
#   param: Parametros del modelo de estimacion
# SALIDAS:
#   counts_pred, las salidas estimadas por el modelo
def model(X, param):

    # Obtenemos el circuito de medicion en los tres ejes
    # para cada patron (flor)
    qcs= [qc_modelZ.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X]
    qcs.extend( [qc_modelX.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X] )
    qcs.extend( [qc_modelY.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X] )


    # Optimizamos todos los circuitos y ejecutamos simulacion sobre ellos
    qcts= transpile(qcs, sim)
    result= sim.run(qcts, shots=n_shots).result()
    
    # Calculamos veces que se mide cada ket de interes
    countsZ, countsX, countsY= [], [], []
    for i, circuit in enumerate(qcs):
        counts= result.get_counts( circuit )
        value= 0 if '0' not in counts else counts['0']
        if i < len(X):
            countsZ.append(value)
        elif i < 2*len(X):
            countsX.append(value)
        else:
            countsY.append(value)

    # Agrupamos veces que se mide |0>, |+>, |i>
    counts_pred= np.array([countsZ, countsX, countsY], dtype=int).T
    y_pred= np.argmax(counts_pred, axis=1) 
    return y_pred


# Evalua un circuito sobre un conjunto de datos y calcula el error cometido
E_f= lambda param : 100*np.mean( model(X, param) != Y )

   
# Optimizamos el circuito
thetas_init= [0.5, 0.2, 0.25] # Suposicion inicial para thetas

from scipy.optimize import minimize
print('Buscando mejores parametros. Espere, por favor...')
result = minimize(fun=E_f, 
                  x0=thetas_init, 
                  method='COBYLA')
thetas_best= result.x
print('Terminado. Mejores parametros: {}'.format(thetas_best))

# Prueba de fuego: El test final
# (Descomentar siguiente linea para comprobar el ejemplo del libro)
error_best= E_f(thetas_best)
print('\nMejor error: {:.2f} %'.format(error_best))

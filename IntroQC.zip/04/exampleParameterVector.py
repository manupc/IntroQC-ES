"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

thetas= ParameterVector('theta', 3) # Creacion de un array de parametros

# Circuito de preparacion de estados
qc= QuantumCircuit(1)
qc.ry(thetas[0], 0)
qc.p(thetas[1], 0)
qc.ry(thetas[2], 0)

qc.save_statevector()

# circuito final
display(qc.draw('mpl'))

# Codificacion de parametros desde X en W
thetas_values= [ [np.pi, np.pi, 0], # thetas
                 [np.pi/2, np.pi, np.pi/2] # otros thetas
               ]

expected_svs= [Statevector([0, -1]),
             Statevector.from_label('0')]


# Asignacion de valores de parametros: Tantos circuitos como opciones
sim= AerSimulator()
allCircuits= [transpile(qc.assign_parameters({thetas: values}), sim)  for values in thetas_values]


# Simulacion
results= sim.run(allCircuits, shots=1).result()


# Calculamos cuantas veces hemos acertado
for exp_sv, qc, params in zip(expected_svs, allCircuits, thetas_values):
    sv= results.get_statevector(qc)
    print('\nStatevector obtenido para thetas={}:'.format(params))
    print(sv)
    print('Statevector esperado:')
    print(exp_sv)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

# Creacion del conjunto de datos
data= np.array([ 
        [0, 0, 0], # x1=0, x2=0, y=0
        [0, 1, 1], # x1=0, x2=1, y=1
        [1, 0, 1], # x1=1, x2=0, y=1
        [1, 1, 0], # x1=1, x2=1, y=0
      ])

X, Y= data[:, :-1], data[:, -1] # Obtenemos entradas X y salidas Y

# Array de parametros del circuito
thetas= ParameterVector('theta', 2) 

# Valores de los parametros
thetas_val= X*np.pi


# Circuito de preparacion de estados
qc_p= QuantumCircuit(1)
qc_p.h(0)
qc_p.p(thetas[0], 0)
qc_p.p(thetas[1], 0)

# Circuito ansatz
qc_a= QuantumCircuit(1)
qc_a.h(0)

# Circuito final
qc= qc_p.compose( qc_a )
qc.measure_all()

# Circuito final:
display(qc.draw('mpl'))

# Asignacion de valores de parametros: Tantos circuitos como opciones
sim= AerSimulator()
allCircuits= [transpile(qc.assign_parameters({thetas: values}), sim)  for values in thetas_val]

# Simulacion
result= sim.run(allCircuits, shots=1).result()

# Comprobar resultados
y_pred= [] # Lista de salidas del algoritmo
for x, y, qct in zip(X, Y, allCircuits):
    counts= sim.run(qct, shots=1).result().get_counts()
    y_pred.append(0 if '0' in counts else 1)
    print('XOR({}, {})= {} y el circuito devuelve {}'.format(x[0], x[1], y, y_pred[-1]))

# Calculamos cuantas veces hemos acertado
accuracy= np.mean(Y == y_pred)
print('Hemos acertado el {}% de las veces'.format(accuracy*100))

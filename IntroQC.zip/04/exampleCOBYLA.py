"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt


# Creacion de un dataset 

# Caracteristicas de entrada
X= np.linspace(start=-10, stop=10, num=101)

# Valores de salida esperados (supuestamente desconocidos a priori)
epsilon= 2*np.random.randn(len(X))
Y= 1.5*(X**2)-1.5*X + 7 + epsilon

f= plt.figure()
plt.plot(X, Y, '.')
plt.title('Conjunto de datos inicial')

# Definicion del modelo lineal f1
def model_f1(X, thetas):
    return X*thetas[1] + thetas[0]

# Definicion del modelo cuadratico f2
def model_f2(X, thetas):
    return thetas[0] + thetas[1]*X +thetas[2]*(X**2)

# Funcion de error
def error(y, y_hat):
    return np.sum(np.abs(y - y_hat))

# Funcion para calcular el rendimiento del modelo 1
E_f1= lambda thetas : error(Y, model_f1(X, thetas))

# Funcion para calcular el rendimiento del modelo 2
E_f2= lambda thetas : error(Y, model_f2(X, thetas))


# Valores iniciales para los parametros del modelo f1
thetas_init= np.random.rand(2)
print('Valores iniciales de thetas para f1:', thetas_init)

# Optimizacion del modelo f1 con COBYLA
result= minimize(fun= E_f1,
                 x0=thetas_init,
                 method='COBYLA')
f1_param_star= result.x # Obtenemos parametros optimizados


# Valores iniciales para los parametros del modelo f2
thetas_init= np.random.rand(3)
print('Valores iniciales de thetas para f2:', thetas_init)

# Optimizacion del modelo f2 con COBYLA
result= minimize(fun= E_f2,
                 x0=thetas_init,
                 method='COBYLA')
f2_param_star= result.x # Obtenemos parametros optimizados


# Prediccion con los parametros optimos de ambos modelos
y_hat_f1= model_f1(X, f1_param_star)
y_hat_f2= model_f2(X, f2_param_star)

print('El modelo f1 produce un error de {} con parametros {}'.format( error(Y, y_hat_f1), f1_param_star ))
print('\t El modelo f1 es: f(x)= {:.2f}x + {:.2f}'.format(f1_param_star[1], f1_param_star[0]))
print('El modelo f2 produce un error de {} con parametros {}'.format( error(Y, y_hat_f2), f2_param_star ))
print('\t El modelo f2 es: f(x)= {:.2f}x**2 + {:.2f}x + {:.2f}'.format(f2_param_star[2], f2_param_star[1], f2_param_star[0]))

f= plt.figure()
plt.plot(X, Y, '.') # Datos iniciales
plt.plot(X, y_hat_f1, 'g') # Datos predichos por modelo 1
plt.plot(X, y_hat_f2, 'r') # Datos predichos por modelo 2
plt.legend(['reales', 'f1', 'f2'])
plt.show()

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np


## Ejemplo de uso de RXGate
qcrx= QuantumCircuit(1)
qcrx.rx(theta=np.pi/2, qubit=0)

# Guardamos la matriz unitaria del circuito
qcrx.save_statevector()

# Instanciacion del simulador Aer
simulator = AerSimulator(method='statevector')

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qcrx, simulator) 

# Instanciacion del simulador Aer
result = simulator.run(qct, shots=1).result()
svrx = result.get_statevector(qct)


## Ejemplo de uso de H y Sdg
qc_HSdg= QuantumCircuit(1)
qc_HSdg.h(qubit=0)
qc_HSdg.sdg(qubit=0)

# Guardamos la matriz unitaria del circuito
qc_HSdg.save_statevector()

# Instanciacion del simulador Aer
simulator = AerSimulator(method='statevector')

# Reescribir circuito para que cumpla con las condiciones del dispositivo
# donde se va a ejecutar
qct = transpile(qc_HSdg, simulator) 

# Instanciacion del simulador Aer
result = simulator.run(qct, shots=1).result()
sv_HSdg = result.get_statevector(qct)


print('\nResultado de aplicar Rx(pi/2)|0>:', svrx)
print('SdgH|0>:', sv_HSdg)


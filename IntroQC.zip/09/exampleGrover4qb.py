"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import grover_operator
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
import numpy as np
from qiskit.visualization import plot_histogram


# Construccion del oraculo: Marcar los estados |0101> y |1101>
oracle= Statevector.from_label('+101'[::-1])

# Construccion del operador de Grover
GroverOp= grover_operator(oracle=oracle)

# Construccion del circuito
num_qubits= 4
qc= QuantumCircuit(num_qubits)

qc.h( list(range(num_qubits)) ) # Preparacion del estado inicial en superposicion

# Aplicacion del operador de Grover sqrt(n) veces
GroverOp= GroverOp.power( np.sqrt(num_qubits) )

# Insercion de Grover en el circuito
qc.append(GroverOp, list(range(num_qubits)))

# Medicion final
qc.measure_all()


# Simulacion
sim= AerSimulator()
counts= sim.run( transpile(qc, sim), shots= 1024).result().get_counts(qc)

# Mostrar resultados
print('Resultados obtenidos:')
for ket in counts:
    print('\t{} : {}'.format(ket[::-1], counts[ket]))

f= plot_histogram(counts)
display(f)

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Implementacion de la funcion constante f(x)=0
def Fcte0():
    return QuantumCircuit(2, 1) # 2 qb, 1 bit


# Implementacion de la funcion constante f(x)=1
def Fcte1():
    qc= QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.x(1)
    return qc


# Implementacion de la funcion balanceada f(x)=x
def FbalX():
    qc= QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.cx(0,1)
    return qc


# Implementacion de la funcion balanceada f(x)=1-x
def FbalNotX():
    qc= QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.cx(0,1, ctrl_state='0')
    return qc


# Definicion de diccionario con las posibles funciones
func= {'f(x)=0' : Fcte0(), 'f(x)=1': Fcte1(), 
       'f(x)=x' : FbalX(), 'f(x)=1-x': FbalNotX()}


# Instanciacion del simulador
sim= AerSimulator()


# Simulacion de todas las funciones
for f in func:
    
    # Construccion del circuito
    qc= QuantumCircuit(2, 1) # 2 qubits, 1 bit
    qc.h(0) # Pasamos x a superposicion |+>
    qc.x(1) # Pasamos y a |->
    qc.h(1)

    # Aplicacion de f
    qc= qc.compose(func[f])
    
    # Hadamard final sobre x
    qc.h(0)
    
    # Medicion
    qc.measure(0, 0)

    # Simulacion
    state= list(sim.run(transpile(qc, sim), shots=1).result().get_counts(qc).keys())[0]
    ftype= 'f. cte' if state == '0' else 'f. bal.'
    print('Resultado para {} : {}'.format(f, ftype))
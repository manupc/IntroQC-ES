"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Implementacion de la funcion f(x)= x.s= x0
def Fx0():
    qc= QuantumCircuit(3, 2) # 3 qb, 2 bit
    qc.cx(0, 2)
    return qc


# Instanciacion del simulador
sim= AerSimulator()

# Simulacion con Deutsch-Jozsa
    
# Construccion del circuito
qc= QuantumCircuit(3, 2) # 2 qubits, 1 bit
qc.h([0,1]) # Pasamos x a superposicion |+>
qc.x(2) # Pasamos y a |->
qc.h(2)

# Aplicacion de f
qc= qc.compose( Fx0() )
    
# Hadamard final sobre x
qc.h([0,1])
    
# Medicion
qc.measure([0, 1], [0, 1])

# Simulacion
s= list(sim.run(transpile(qc, sim), shots=1).result().get_counts(qc).keys())[0]
print('La clave secreta de Fx0 es s={}'.format(s[::-1]))

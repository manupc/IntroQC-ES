"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, transpile
from qiskit_aer import AerSimulator
from itertools import product
import numpy as np

# Implementacion de la funcion 1 
def F1():
    
    qx= QuantumRegister(size= 3, name= 'qx')
    qy= QuantumRegister(size= 3, name= 'qy')
    qc= QuantumCircuit(qx, qy)
    
    qc.cx(qx[0], qy[0], ctrl_state='0')
    qc.cx(qx[1], qy[1], ctrl_state='0')
    qc.cx(qx[2], qy[2])
    
    return qc.to_gate()


# Implementacion de la funcion 2
def F2():
    
    qx= QuantumRegister(size= 3, name= 'qx')
    qy= QuantumRegister(size= 3, name= 'qy')
    qc= QuantumCircuit(qx, qy)
    
    qc.x(qy[0])
    qc.ccx(qx[0], qx[1], qy[1], ctrl_state='00')
    qc.ccx(qx[0], qx[1], qy[1], ctrl_state='11')
    qc.cx(qx[2], qy[2])
    
    return qc.to_gate()

Fs= {1: F1, 2: F2}

# Instanciacion del simulador
sim= AerSimulator()

# Simulacion con Deutsch-Jozsa
n= 3 # Longitud de la cadena de bits
for idx in Fs:

    F= Fs[idx] # Obtenemos funcion 

    # Construccion del circuito
    qc= QuantumCircuit(2*n) # 3 qubits entrada y 3 salida

    qc.h([0, 1, 2]) # Pasamos x a superposicion 
    qc.append(F(), list(range(2*n))) # Insertamos oraculo
    qc.h([0, 1, 2]) # Sacamos x de superposicion 

    qc.measure_all()


    # Simulacion
    qct= transpile(qc, sim)
    
    # Contabilizar aciertos en N veces
    aciertos= 0
    N= 5
    print('\nComienza evaluacion de F{}'.format(idx))
    for i in range(N):
    
        # Generamos los posibles valores de s
        s= set( product( *([[0,1]]*n) ) ) 
        
        # Simulamos circuito
        counts= sim.run(qct, shots=2*n).result().get_counts(qct)
        
        for ket in counts:
            k= [int(c) for c in ket[::-1][:n]] # Obtenemos k
                
            # Busqueda por fuerza bruta de los s que hacen s*k=0 mod 2
            s_copy= s.copy()
            for s_val in s_copy:
                if (np.dot(s_val, k)%2 != 0) and (s_val in s):
                    s.remove(s_val)
        print('Ejecucion {}. s esta en {}'.format(i+1, s))
        if len(s) > 2:
            print('\tError de calculo')
        elif len(s) == idx:
            aciertos+= 1
            
    print('\nSimon ha acertado un total de {}/{} veces'.format(aciertos, N))





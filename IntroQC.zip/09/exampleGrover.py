"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import ZGate
from qiskit_aer import AerSimulator

# Funcion que genera el operador de difusion de Grover para n qubits
def GroverDiffusionOperator(n : int):
    
    qcG= QuantumCircuit(n)
    qcG.h( list(range(n)) ) # Puerta H para todas los qubits
    qcG.x( list(range(n)) ) # Puerta X para todas los qubits
    
    # Puerta Z controlada por n-1 qubits
    CnZGate= ZGate().control(num_ctrl_qubits=n-1)
    qcG.append(CnZGate, list(range(n))) # Aplicacion de puerta Z controlada
    
    qcG.x( list(range(n)) ) # Puerta X final para todas los qubits
    qcG.h( list(range(n)) ) # Puerta H final para todas los qubits
    return qcG


# Devuelve un oraculo para devolver el estado |01> de dos qubits
def Oracle01():
    qcO= QuantumCircuit(2)
    qcO.cz(control_qubit=0, target_qubit=1, ctrl_state='0')
    return qcO


# Devuelve un oraculo para devolver el estado |00> de dos qubits
def Oracle00():
    qcO= QuantumCircuit(2)
    qcO.x(0) 
    qcO.cz(control_qubit=1, target_qubit=0, ctrl_state='0')
    qcO.x(0)
    return qcO


# Devuelve un circuito de preparacion de estados de dos qubits
# conteniendo el estado |++>
def StatePreparation():
    qcS= QuantumCircuit(2)
    qcS.h([0,1])
    return qcS



sim= AerSimulator() # Simulador a usar

# Diccionario con los oraculos a aplicar
Oracles= {'01' : Oracle01 , '00': Oracle00}

for oracle_ket in Oracles:
    oracle= Oracles[oracle_ket] # Obtenemos la funcion del oraculo

    # Creacion del circuito para ejecutar Grover
    qc= QuantumCircuit(2)
    qc= qc.compose( StatePreparation() ) # Preparacion del estado inicial
    qc= qc.compose( oracle() ) # Incorporacion del oraculo
    qc= qc.compose( GroverDiffusionOperator(2) ) # Operador de difusion
    qc.measure_all() # Medicion de todos los qubits

    # Simulacion
    counts= sim.run( transpile(qc, sim), shots= 1024).result().get_counts(qc)

    # Mostramos resultados
    print('\nResultados del operador de Grover sobre el estado {}'.format(oracle_ket))
    for ket in counts:
        print('\t{} : {}'.format(ket[::-1], counts[ket]))
    
    
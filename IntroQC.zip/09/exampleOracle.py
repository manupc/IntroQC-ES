"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

# Oraculo de la ecuacion 10.1
qcOracle= QuantumCircuit(2)
qcOracle.cz(control_qubit=0, target_qubit=1, ctrl_state='0')


# Circuito cuantico para preparar |x>
qcState= QuantumCircuit(2)
qcState.h([0, 1]) # Hacer |x>= 0.5(|00> + |01> + |10> + |11>)


# Circuito final
qc= qcState.compose(qcOracle)
qc.save_statevector()


# Simulacion
sim= AerSimulator()
sv= sim.run(qc, shots= 1).result().get_statevector(qc)

# Mostramos vector de estado
sv_dict= sv.to_dict()
for ket in sv_dict:
    print('{} : {}'.format(ket[::-1], sv_dict[ket]))
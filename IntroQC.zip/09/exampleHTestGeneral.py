"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


# Vectores propios de la puerta Z
svs= { '+' : np.array([np.cos(np.pi/4), np.sin(np.pi/4)], dtype=complex), 
       'q' : np.array([np.cos(np.pi/8), np.sin(np.pi/8)], dtype=complex)}

# Matriz del observable Z
Z= np.array([[1,  0],
             [0, -1]], dtype=complex)

n_shots= 2048
for state in svs:
    
    # Obtencion de vector |psi>
    sv= Statevector(svs[state])
    
    # Creacion del circuito
    qc= QuantumCircuit(2, 1)
    qc.initialize(sv, [1])
    qc.h(0)
    qc.cz(0, 1)
    qc.h(0)
    qc.measure(0, 0)
    
    # Simulacion
    sim= AerSimulator()
    counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()
    
    # Aproximacion de <psi|Z|psi>
    prob_0s= counts['0']/n_shots if '0' in counts else 0
    prob_1s= counts['1']/n_shots if '1' in counts else 0
    
    exp_val_0s= 2*prob_0s-1
    exp_val_1s= -(2*prob_1s-1)
    exp_val= (exp_val_0s + exp_val_1s)/2
    print('La esperanza calculada del observable <{}|Z|{}> es: {}'.format(state, state, exp_val))
    
    # Valor real
    ket= svs[state].reshape(-1, 1)
    bra= ket.conjugate().transpose()
    exp_val_real= (bra@Z@ket).squeeze().real
    print('El valor real de <{}|Z|{}> es: {}'.format(state, state, exp_val_real))
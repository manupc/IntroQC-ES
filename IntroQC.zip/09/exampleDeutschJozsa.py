"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Implementacion de la funcion constante f(x)=0
def Fcte0():
    return QuantumCircuit(3, 2) # 3 qb, 2 bit


# Implementacion de la funcion balanceada f(x_0,x_1)=x_0 + x_1
def FbalXOR():
    qc= QuantumCircuit(3, 2) # 3 qb, 2 bit
    qc.cx(0,2)
    qc.cx(1,2)
    return qc


# Definicion de diccionario con las posibles funciones
func= {'f(x)=0' : Fcte0(), 'f(x0, x1)=x0+x1': FbalXOR()}


# Instanciacion del simulador
sim= AerSimulator()

# Simulacion de todas las funciones
for f in func:
    
    # Construccion del circuito
    qc= QuantumCircuit(3, 2) # 3 qubits, 2 bit
    qc.h([0,1]) # Pasamos x a superposicion |+>
    qc.x(2) # Pasamos y a |->
    qc.h(2)

    # Aplicacion de f
    qc= qc.compose(func[f])
    
    # Hadamard final sobre x
    qc.h([0,1])
    
    # Medicion
    qc.measure([0, 1], [0, 1])

    # Simulacion
    state= list(sim.run(transpile(qc, sim), shots=1).result().get_counts(qc).keys())[0]
    ftype= 'f. cte' if state == '00' else 'f. bal.'
    print('Resultado para {} : {}'.format(f, ftype))
    
    
    
    
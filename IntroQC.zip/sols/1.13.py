"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir el vector original en la base canónica
v = np.array([5, -1])
print("Vector original v: {}".format(v))

# Definir los vectores de la nueva base ortonormal
u1 = np.array([0.6, 0.8])
u2 = np.array([-0.8, 0.6])
print("\nVector de la nueva base u1: {}".format(u1))
print("Vector de la nueva base u2: {}".format(u2))

# Calcular las nuevas coordenadas (vp_1, vp_2)
# v'_1 = <v, u1> (producto escalar de v y u1)
vp_1 = np.dot(v, u1)

# v'_2 = <v, u2> (producto escalar de v y u2)
vp_2 = np.dot(v, u2)

# Crear un nuevo array para el vector en la nueva base
vp = np.array([vp_1, vp_2])

print("\nVector v en la nueva base B': {}".format(vp))
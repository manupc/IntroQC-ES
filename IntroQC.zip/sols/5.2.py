"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator


# Estado
sv= Statevector.from_label( '+0'[::-1] ) # Invertimos estado por little-endian


# Circuito
qc= QuantumCircuit(2)
qc.h(1)
qc.swap(0,1)
qc.save_statevector()

sim= AerSimulator(method='statevector')
svc= sim.run(qc, shots=1).result().get_statevector()


print('Son equivalentes: ', sv.equiv(svc))
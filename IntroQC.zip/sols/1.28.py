"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definiciones Globales 

# Matriz H
H = (1/np.sqrt(2))*np.array([[1, 1], [1, -1]], dtype=complex)

# Matriz Z 
Z = np.array([[1, 0], [0, -1]], dtype=complex)

# Vectores de la base |0> y |1>
ket_0 = np.array([1, 0], dtype=complex)
ket_1 = np.array([0, 1], dtype=complex)

# Función de Verificación
# Esta función toma dos kets (u, v) y verifica si la propiedad se cumple.
def check(ket_u, ket_v):
    print("\nVerificando para |u> = {} y |v> = {}".format(ket_u, ket_v))

    # LADO IZQUIERDO: (H|u>) ⊗ (Z|v>)
    Hu = H @ ket_u
    Zv = Z @ ket_v
    lhs = np.kron(Hu, Zv)

    # LADO DERECHO: (H ⊗ Z) |uv> 
    H_tensor_Z = np.kron(H, Z)
    ket_uv = np.kron(ket_u, ket_v)
    rhs = H_tensor_Z @ ket_uv

    # Comparación y Resultado
    comp = np.allclose(lhs, rhs)

    if comp:
        print("\tLa propiedad se cumple. Ambos lados son iguales a {}".format(np.round(lhs, decimals=5)))
        
    else:
        print("\tLa propiedad NO se cumple.")
    
    print("-" * 50)

# Ejecución de los cuatro casos
check(ket_0, ket_0)
check(ket_1, ket_1)
check(ket_0, ket_1)
check(ket_1, ket_0)

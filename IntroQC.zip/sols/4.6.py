"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
from IPython.display import display
import numpy as np

phi= [0, np.pi/4, np.pi/2, 3*np.pi/4, np.pi]
theta= [0, np.pi/4, np.pi/2, 3*np.pi/4, np.pi, 5*np.pi/4, 3*np.pi/2, 7*np.pi/4, 2*np.pi]



# Rx
par= Parameter(name='param')

qc= QuantumCircuit(1)
qc.rx(par, 0)
qc.save_statevector()

sim= AerSimulator(method='statevector')

for ang in phi:
    qct= transpile(qc.assign_parameters({par : ang}))
    r= sim.run(qct, shots=1).result()
    sv= r.get_statevector()
    display(sv.draw('bloch'))




# Ry
par= Parameter(name='param')

qc= QuantumCircuit(1)
qc.ry(par, 0)
qc.save_statevector()

sim= AerSimulator(method='statevector')

for ang in phi:
    qct= transpile(qc.assign_parameters({par : ang}))
    r= sim.run(qct, shots=1).result()
    sv= r.get_statevector()
    display(sv.draw('bloch'))


# Rz
par= Parameter(name='param')

qc= QuantumCircuit(1)
qc.h(0)
qc.rz(par, 0)
qc.save_statevector()

sim= AerSimulator(method='statevector')

for ang in theta:
    qct= transpile(qc.assign_parameters({par : ang}))
    r= sim.run(qct, shots=1).result()
    sv= r.get_statevector()
    display(sv.draw('bloch'))


# P
par= Parameter(name='param')

qc= QuantumCircuit(1)
qc.h(0)
qc.p(par, 0)
qc.save_statevector()

sim= AerSimulator(method='statevector')

for ang in theta:
    qct= transpile(qc.assign_parameters({par : ang}))
    r= sim.run(qct, shots=1).result()
    sv= r.get_statevector()
    display(sv.draw('bloch'))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





import gymnasium as gym
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
from qiskit.circuit.library import XGate


qc= QuantumCircuit(10+2, 2) # 10 entradas, 2 salidas (hit, stop)


# R1: Sin Ace, hit
qc.cx(0, 10, ctrl_state='0')

# Dealer value 9 y jugador= 10, hit
gate= XGate().control(num_ctrl_qubits=8, ctrl_state='10011010'[::-1])
qc.append(gate, [1, 2, 3, 4, 6, 7, 8, 9, 10])

# Por defecto, para
qc.x(11)

qc.measure([10, 11], [0,1]) 

sim= AerSimulator()


# Función de selección de acción del estado s con el circuito cuántico qc
def a(s, qc, sim):
    player_sum, dealer_card, ace= s[0], s[1], s[2]
    
    b_player= bin(player_sum)[2:].rjust(5, '0')
    b_dealer= bin(dealer_card)[2:].rjust(4, '0')
    b_ace= bin(ace)[2]
    
    
    state= b_ace+b_dealer+b_player+'00'
    qc_play= QuantumCircuit(12, 2)
    qc_play.initialize( Statevector.from_label(state[::-1]) )
    qc_play= qc_play.compose(qc)
    counts= list(sim.run(transpile( qc_play, sim ), shots=1).result().get_counts().keys())[0]
    action= 0 if counts[0]=='1' else 1
    return action
    
    


env= gym.make('Blackjack-v1')

avgR= 0
gain= 0
max_trials= 100
for trial in range(max_trials):
    end= False
    t= 0
    s, _= env.reset()
    R= 0 # Recompensa total

    while not end:
        
        action= a(s, qc, sim)
        sp, r, t1, t2, _= env.step(action)
        R+= r
        t+= 1
        end= t1 or t2
        s= sp
    gain+= R
    print('Tras {} jugadas: R avg.={}'.format(trial+1, gain/(trial+1)))

print('He terminado en {} pasos con R media={}'.format(t, gain/max_trials))
        

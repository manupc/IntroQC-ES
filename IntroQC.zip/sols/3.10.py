"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import sys
from qiskit.quantum_info import SparsePauliOp, Statevector
import numpy as np

# Verificamos si podemos construir el operador
try:
    oper = SparsePauliOp.from_list([("X", 0.5), ("Z", 0.5)]).to_operator()
except:
    print('No se puede construir el operador 0.5X+0.5Z')
    sys.exit(0)

# Comprobar si es hermitico
hermit= np.allclose( oper.to_matrix(), oper.to_matrix().conjugate().T)
if hermit:
    print('Es un observable')
else:
    print('NO es un observable')
    sys.exit(0)

# Valor esperado
sv= Statevector.from_label('0')
print('Valor esperado del observable: ', sv.expectation_value(oper))
    
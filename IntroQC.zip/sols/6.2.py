"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator


# Toffoli 
qct= QuantumCircuit(3)
qct.ccx(0, 1, 2)
qct.save_unitary()

# Simulacion
qcs= QuantumCircuit(3)
qcs.h(2)
qcs.cx(1,2)
qcs.tdg(2)
qcs.cx(0,2)
qcs.t(2)
qcs.cx(1,2)
qcs.tdg(2)
qcs.cx(0,2)
qcs.tdg(1)
qcs.t(2)
qcs.cx(0,1)
qcs.h(2)
qcs.tdg(1)
qcs.cx(0,1)
qcs.t(0)
qcs.s(1)
qcs.save_unitary()


sim= AerSimulator(method='unitary')
Ut= sim.run(transpile(qct, sim), shots=1).result().get_unitary()
Us= sim.run(transpile(qcs, sim), shots=1).result().get_unitary()

print('El circuito simulado equivale a CCNOT: {}'.format(Ut.equiv(Us)))
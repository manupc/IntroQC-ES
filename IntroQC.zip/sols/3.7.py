"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.circuit.library import XGate
import numpy as np

# Vector propio |+>
qc1= QuantumCircuit(1)
qc1.h(0)
qc1.save_statevector()

# Vector propio |->
qc1= QuantumCircuit(1)
qc1.x(0)
qc1.h(0)
qc1.save_statevector()


X= XGate().to_matrix()

sim= AerSimulator(method='statevector')
sv1= sim.run(transpile(qc1), shots= 1).result().get_statevector().data
sv2= sim.run(transpile(qc1), shots= 1).result().get_statevector().data

eig_val, eig_vec= np.linalg.eig(X)
print('Vectores propios de X:')
for vec in eig_vec.T:
    print(vec)
    
print('Vector propio |+>:', sv1)
print('Vector propio |->:', sv2)



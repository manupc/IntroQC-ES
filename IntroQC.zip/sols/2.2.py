"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generacion de los estados
ls= [ # Lista de estados
      Statevector([np.exp(2*np.pi*1j), 0]),
      Statevector([np.sqrt(2)/2, 1j*np.sqrt(2)/2]),
      Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
      Statevector([np.sqrt(2)/2, np.sqrt(2)/2]),
      Statevector([0, np.exp(2*np.pi*1j)]),
      Statevector([1/np.sqrt(2), -1j/np.sqrt(2)])
    ]

# Etiquetas
labels= ['+', 'r', '0', 'l', '-', '1']

# Iteramos sobre todas las etiquetas
for label in labels:
    sv= Statevector.from_label(label)
    print('Estado |{}>= {}'.format(label, sv.data))
    
    # Comprobamos equivalencia salvo fase global
    for i, ket in enumerate(ls):
        if ket.equiv(sv):
            print('\tEquivale a |psi_{}>= {}'.format(i+1, ls[i]))


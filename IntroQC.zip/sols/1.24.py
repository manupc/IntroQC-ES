"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir el vector v y la matriz U
v= (1 / np.sqrt(2)) * np.array([0, 1, 1, 0])
U= np.array([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0]
])

#Calcular el vector resultante w = U * v
w= U @ v

# Calcular la norma de los vectores v y w
norm_v= np.linalg.norm(v)
norm_w= np.linalg.norm(w)

# Comprobar si las normas son iguales
comp= np.allclose(norm_v, norm_w)

# Mostrar los resultados
print("Vector original v:\n", v)
print("Matriz unitaria U:\n", U)
print("\nVector resultante w = U @ v:\n", w)

print(f"Norma de v: {norm_v:.4f}")
print(f"Norma de w: {norm_w:.4f}")

if comp:
    print("La norma del vector se ha preservado después de la transformación.")
else:
    print("La norma del vector ha cambiado.")
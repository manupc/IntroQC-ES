"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector, Pauli



# Estados
svs= {'i': Statevector.from_label('r'),
     '-i': Statevector.from_label('l') }

# Observables
Os= {'Z': Pauli('Z'), 'X': Pauli('X')}


for sv_str in svs:
    sv= svs[sv_str]
    for O_str in Os:
        O= Os[O_str]
        exp= sv.expectation_value(O)
        print('<{}|{}|{}>= {}'.format(sv_str, O_str, sv_str, exp))
        

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator
import numpy as np

par= ParameterVector(name='params', length=2)

vector= np.random.rand(2)

qc= QuantumCircuit(1)
qc.ry(par[0]*np.pi, 0)
qc.rz(par[1]*np.pi*2, 0)
qc.save_statevector()

qc= transpile(qc.assign_parameters({par : vector}))
sim= AerSimulator(method='statevector')

sv_final= sim.run(qc, shots=1).result().get_statevector()
print('vector=', vector)
print('sv=', sv_final)

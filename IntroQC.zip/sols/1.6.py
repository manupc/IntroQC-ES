"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crea un array NumPy con ángulos en grados
ad = np.array([0, 30, 45, 60, 90, 180])

# Convierte los ángulos de grados a radianes
ar = np.deg2rad(ad)

# Calcula el seno de cada ángulo en radianes
sin = np.sin(ar)

# Imprime todos los arrays
print("Ángulos originales en grados: {}".format(ad))
print("Ángulos en radianes: {}".format(ar))
print("Seno de los ángulos: {}".format(sin))
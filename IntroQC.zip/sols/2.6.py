"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generacion de los estados
ls= [
     Statevector([-1, 0]),
     Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([-1/np.sqrt(2), 1/np.sqrt(2)]),
     Statevector([1, 0]),
     Statevector([1j/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1j/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1/np.sqrt(2)]),
     ]

# Iteramos sobre todos
for i, sv in enumerate(ls):

    # Obtenemos representación numpy
    np_rep= sv.data

    # Iteramos por amplitudes
    txtbin, txtmp, txttri= '', '', ''
    # Forma binomica
    txtbin= '{}'.format(np_rep[0])+'|0>  + '+'{}'.format(np_rep[1])+'|1>'
        
    # forma polar de cada amplitud
    mag0, ang0= np.abs(np_rep[0]), np.angle(np_rep[0])
    mag1, ang1= np.abs(np_rep[1]), np.angle(np_rep[1])

    txtmp= '{}e^({}i)'.format(mag0, ang0)+'|0> + '+'{}e^({}i)'.format(mag1, ang1)+'|1>' 
        
    # Trigonométrica
    phi= 2*np.arccos(mag0)
    theta= ang1-ang0
    txttri='cos({}/2)'.format(phi)+'|0> + '+'sin({}/2)e^({}i)'.format(phi, theta)+'|1>' 

    # Mostramos resultados
    print('-'*10)        
    print('\tForma binomica: '+txtbin)
    print('\tForma en magnitudes y fase: '+txtmp)
    print('\tForma trigonométrica: '+txttri)
    
    

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





import gymnasium as gym
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
import numpy as np


qc= QuantumCircuit(4+2, 2) # 4 entradas, 2 salidas (derecha o abajo)

# codificación de entradas
par= ParameterVector(name='par', length=4)
for i in range(len(par)):
    qc.ry(par[i]*np.pi, i)


# R1: Bajar si estamos en fila 2, columnas 3 o 4
gate= XGate().control(num_ctrl_qubits=3, ctrl_state='101')
qc.append(gate, [0, 1, 2, 4])

# R2: Bajar si estamos en filas 0 o 1, columna 3
gate= XGate().control(num_ctrl_qubits=3, ctrl_state='010')
qc.append(gate, [0, 2, 3, 4])

# R3: Por defecto, ir a derecha
qc.x(5)
qc.measure([4, 5], [0,1])

sim= AerSimulator()


# Función de selección de acción del estado s con el circuito cuántico qc
def a(s, qc, sim):
    b_row= bin(s//4)[2:].rjust(2, '0') # Pasamos fila a binario 00/01/10/11
    b_col= bin(s%4)[2:].rjust(2, '0') # Pasamos columna a binario 00/01/10/11
    
    rotations= [int(b_row[0]), int(b_row[1]), # Obtrenemos valores de rotación de las filas
                int(b_col[0]), int(b_col[1])] # Obtrenemos valores de rotación de las columnas
    
    # Ejecución del circuito
    out= list(sim.run(transpile( qc.assign_parameters(rotations), sim ), shots=1).result().get_counts().keys())[0][::-1]
    
    # Selección de acción
    if out[0]== '1':
        action= 1
    elif out[1] == '1':
        action= 2
    else:
        raise Exception('ERROR al seleccionar la acción')
    return action
    
    


env= gym.make('FrozenLake-v1', is_slippery=False)
s, _= env.reset()
R= 0 # Recompensa total

end= False
maximum= 1000
t= 0
while not end:
    action= a(s, qc, sim)
    sp, r, t1, t2, _= env.step(action)
    R+= r
    t+= 1
    end= t1 or t2 or t>= maximum
    s= sp

print('He terminado en {} pasos con R={}'.format(t, R))
    

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





import gymnasium as gym
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
import numpy as np

"""
 La toma de decisiones óptima es la siguiente:

LULU
L-L-
UDL-
-RD-
     
L -> Izquierda (0)
D -> Abajo (1)
R -> Derecha (2)
U -> Arriba (3)
- -> No aplica
"""

# Pasamos las acciones a array
actions= [0,3,0,3,0,-1,0,-1,3,1,0,-1,-1,2,1,-1]

qc= QuantumCircuit(4+4, 4) # 4 entradas, 4 salidas 

# codificación de entradas
par= ParameterVector(name='par', length=4)
for i in range(len(par)):
    qc.ry(par[i]*np.pi, i)


# Implementamos las reglas
for s in range(16):
    b_s= bin(s)[2:].rjust(4, '0') # little endian
    if actions[s] >= 0:
        gate= XGate().control(num_ctrl_qubits=4, ctrl_state=b_s)
        qc.append(gate, [0, 1, 2, 3, 4+actions[s]])
    

qc.measure([4, 5, 6, 7], [0, 1, 2, 3])

sim= AerSimulator()


# Función de selección de acción del estado s con el circuito cuántico qc
def a(s, qc, sim):
    b_s= bin(s)[2:].rjust(4, '0')[::-1] # little endian
    
    rotations= [int(b_s[0]), int(b_s[1]), # Obtrenemos valores de rotación de las filas
                int(b_s[2]), int(b_s[3])] # Obtrenemos valores de rotación de las columnas
    
    
    
    # Ejecución del circuito
    out= list(sim.run(transpile( qc.assign_parameters(rotations), sim ), shots=1).result().get_counts().keys())[0][::-1]
    
    # Selección de acción
    if out[0]== '1':
        action= 0
    elif out[1] == '1':
        action= 1
    elif out[2] == '1':
        action= 2
    else:
        action= 3
    
    
    return action
    
    


env= gym.make('FrozenLake-v1', is_slippery=True)

solved= 0
max_e= 10 # Máximo de ejecuciones
for exper in range(max_e):
    end= False
    maximum= 1000
    t= 0
    s, _= env.reset()
    R= 0 # Recompensa total

    print('Nuevo entorno. Esperimento {}'.format(exper+1))
    while not end:
        action= a(s, qc, sim)
        sp, r, t1, t2, _= env.step(action)
        R+= r
        t+= 1
        end= t1 or t2 or t>= maximum
        s= sp
    
    print('He terminado en {} pasos con R={}'.format(t, R))
    if R>0:
        solved+= 1
        
perc_solved= solved/max_e * 100
print('He resuelto el entorno un {}% de las veces'.format(perc_solved))
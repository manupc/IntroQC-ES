"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler



# Generación de la matriz del problema
S= np.array([1, 2, 3, 4, 5, 6], dtype= int)
n= len(S)
print('Representacion inicial del problema:')
print(S)


# Creacion de variables para el modelo Ising
z = Array.create('z', shape=(n,), vartype='SPIN')

# Matriz de coeficientes del problema y formulacion
Ising= 0 # Modelo Ising

# Formulación de función de coste
for i in range(len(S)):
    # Modelo QUBO: S[i]*z[i] suma S[i] cuando z[i]=1 y lo resta cuando z[i]=-1
    Ising+= S[i]*z[i]
Ising= Ising**2 # Al cuadrado para que la diferencia sea positiva


model= Ising.compile()
ising_description= model.to_ising()

print('\nModelo Ising:')
for coefs in ising_description:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])

# Creamos modelo cuadratico binario (BQM)
bqm= model.to_bqm()

# Aplicamos enfriamiento simulado para resolver el problema QUBO
# un total de n_shots veces
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nLas {} soluciones obtenidas: '.format(n_shots))
print(sampleset)

# Obtencion de la mejor solucion
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

solution = np.zeros(n, dtype=int)
for var in best_sample_vars:
    for i, z_i in enumerate(z):
        if var in str(z_i):
            solution[i] = best_sample_vars[var]
    
print('\nMejor Solucion: z={} con coste f(x)={}'.format(solution, best_sample_cost))


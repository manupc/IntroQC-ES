"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir las matrices A y B
A = np.array([[1, 2],
              [3, 4]])

B = np.array([[0, 6],
              [5, 7]])

print("Matriz A:\n", A)
print("\nMatriz B:\n", B)

# Calcular el producto Kronecker A_tensor_B = A otimes B
A_tensor_B = np.kron(A, B)

print("\nProducto de Kronecker A otimes B:")
print(A_tensor_B)
print("Forma de A tensor B:", A_tensor_B.shape)

# Calcular el producto de Kronecker B_tensor_A = B otimes A
B_tensor_A = np.kron(B, A)

print("\nProducto de Kronecker B otimes A:")
print(B_tensor_A)
print("Forma de B tensor A:", B_tensor_A.shape)
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from scipy.linalg import expm

# Definir la matriz Y del ejercicio anterior
Y= np.array([
    [0, -1j],
    [1j,  0]
])

# Construir la matriz del exponente: (i * pi/2 * Y)
M= 1j * (np.pi / 2) * Y

# Calcular la matriz U = exp(exponent_matrix) usando SciPy
U = expm(M)

# Comprobar si la matriz U resultante es unitaria
U_dagger = np.conjugate(U).T
prod = U_dagger @ U
I = np.identity(2)
unitary = np.allclose(prod, I)

# 5. Mostrar los resultados
print("Matriz Y:\n", Y)
print("\nMatriz U = exp(i * pi/2 * Y):\n", np.round(U, decimals=5))
print("\nProducto U† * U:\n", np.round(prod, decimals=5))

if unitary:
    print("La matriz U resultante es unitaria.")
else:
    print("La matriz U resultante NO es unitaria.")
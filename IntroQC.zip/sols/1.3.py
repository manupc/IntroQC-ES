"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crear el array de temperaturas
t= np.array([24.6, 18.3, 29.5, 27, 22.8, 15, 22.1])

print("Temperaturas diarias: {}".format(t))

# Calcular media, mínimo y máximo
avg_t, min_t, max_t= t.mean(), t.min(), t.max()

print("Temperatura máxima: {:.1f}°C".format(max_t))
print("Temperatura mínima: {:.1f}°C".format(min_t))
print("Temperatura promedio: {:.1f}°C".format(avg_t))

#  Seleccionar y mostrar las temperaturas superiores a 24.0
high_t= t[t > 24.0]

print("Temperaturas superiores a 24.0°C: {}".format(high_t))
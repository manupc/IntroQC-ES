"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import XGate
from qiskit.circuit import QuantumRegister
from qiskit_aer import AerSimulator
from qiskit.quantum_info import DensityMatrix
import numpy as np

"""
    Utilizaremos el sumador de registros de un qubit del libro para crear el sumador
    de registros de dos qubits
"""

# Circuito modular: Sumador de 1 qubit
def SingleQubitAdder():
    
    # Operacion CCCNOT
    CCCNOT_001= XGate().control(num_ctrl_qubits=3, ctrl_state='001'[::-1])
    CCCNOT_110= XGate().control(num_ctrl_qubits=3, ctrl_state='110'[::-1])
    
    # Asignacion de qubits:
    #  q0: q_x; q1: q_y; q2: q_c; q3: q_z
    adder= QuantumCircuit(4, name='Adder')
    
    # Calculo de qz= q_x+q_y+q_c
    adder.cx(0, 3)
    adder.cx(1, 3)
    adder.cx(2, 3)
    
    # Actualizacion de CARRY
    adder.append(CCCNOT_001, [0, 1, 3, 2])
    adder.append(CCCNOT_110, [0, 1, 3, 2])
    return adder.to_instruction()

# Circuito sumador de registros de dos qubits
def TwoQubitsAdder(qx, qy, qz, qcarry):
    qc= QuantumCircuit(qx, qy, qz, qcarry)
    sqa= SingleQubitAdder()
    qc.append(sqa, [qx[0], qy[0], qcarry[0], qz[0]])
    qc.append(sqa, [qx[1], qy[1], qcarry[0], qz[1]])
    return qc.to_instruction()
    

# Registros cuánticos de entrada y salida
qx= QuantumRegister(size=2, name='qx')
qy= QuantumRegister(size=2, name='qy')
qz= QuantumRegister(size=2, name='qz')
qcarry= QuantumRegister(size=1, name='qcarry')

# Circuito sumador
adder= TwoQubitsAdder(qx, qy, qz, qcarry)


# Preparamos mezcla estadística desde matriz de densidad, por simplicidad
qc= QuantumCircuit(qx, qy, qz, qcarry)
qc.h(qx)
qc.h(qy)


# Obtenemos matriz de densidad 
dm= DensityMatrix.from_instruction(qc.to_instruction())
np_dm= dm.data


# Hacemos elementos de fuera de la diagonal igual a cero
diag = np.diag(np_dm)
temp = np.identity(len(np_dm))
np_dm= diag*temp

# Creamos matriz de densidad de estado mixto
dm= DensityMatrix(np_dm)

# Evolucionamos con el circuito
dm= dm.evolve(adder)


dmd= dm.to_dict()
for k in dmd:
    if not np.isclose(dmd[k], 0):
        rev_k= k[:len(k)//2]
        bcarry= rev_k[0]
        bz= rev_k[1:3]
        by= rev_k[3:5]
        bx= rev_k[5:7]
        print('{} + {}= {} con acarreo {}'.format(bx, by, bz, bcarry))
        
print('El diseño de un estado mixto no afecta en este caso a la medición. Sin embargo, el estado mixto no es directamente ejecutable en un computador cuántico.')
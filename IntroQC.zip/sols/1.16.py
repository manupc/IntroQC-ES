"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir la matriz M
M = np.array([[4, 1],
              [2, 3]])

print("Matriz M:\n", M)

# Calcular los valores propios y vectores propios
eigenvalues, eigenvectors = np.linalg.eig(M)

print("\nValores propios (eigenvalues):", eigenvalues)
print("\nVectores propios (eigenvectors - cada columna es un vector propio):\n", eigenvectors)

# 3. Verificar la relación Mv = λv para cada par
print("\nVerificación de Mv = λv:")

# Iterar sobre cada par valor propio-vector propio
for i in range(len(eigenvalues)):
    lambda_val = eigenvalues[i]
    v_vec = eigenvectors[:, i] 

    # Calcular M * v
    Mv = M @ v_vec

    # Calcular lambda * v
    lambdav = lambda_val * v_vec

    print("\nPara el par:")
    print("\tValor propio (λ): {:.4f}".format(lambda_val))
    print("\tVector propio (v): {}".format(v_vec))
    print("\tMv: {}".format(Mv))
    print("\tλv: {}".format(lambdav))

    # Verificar si Mv es aproximadamente igual a λv
    # Usamos np.allclose() por la precisión de punto flotante
    if np.allclose(Mv, lambdav):
        print("Mv = λv")
    else:
        print("Mv != λv. Hay un problema.")
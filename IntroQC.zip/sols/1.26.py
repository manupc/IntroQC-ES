"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definiciones 

# Definir las matrices H y Z
H = (1 / np.sqrt(2)) * np.array([
    [1, 1],
    [1, -1]
], dtype=complex)

Z = np.array([
    [1, 0],
    [0, -1]
], dtype=complex)

# Definir los vectores de la base (kets)
# ket_0 representa |0>
ket_0 = np.array([1, 0], dtype=complex)

# ket_1 representa |1>
ket_1 = np.array([0, 1], dtype=complex)


# Cálculos 

# Calcular la primera operación: H * Z * H * |0>
r_1 = H @ Z @ H @ ket_0

# Calcular la segunda operación: Z * H * Z * |1>
r_2 = Z @ H @ Z @ ket_1


# Mostrar Resultados

print("Matrices y Vectores Iniciales")
print("Matriz H:\n", H)
print("\nMatriz Z:\n", Z)
print("\nVector |0>:", ket_0)
print("\nVector |1>:", ket_1)
print("\n\n")

print("Resultados de las Operaciones")

print("Resultado de HZH|0>: {}".format(np.round(r_1, decimals=5)))
print("Resultado de ZHZ|1>: {}".format(np.round(r_2, decimals=5)))

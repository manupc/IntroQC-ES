"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
from qiskit.quantum_info import state_fidelity


# Estado
sv= Statevector([0.6, 0.8j])

# Inicializamos el circuito
qc= QuantumCircuit(1)
qc.initialize(sv)

# Definimos puertas permitidas
gates = ['h', 's', 'sdg', 'sx', 'sxdg', 't', 'tdg']

# Descomponemos circuito y lo mostramos por consola
qc_gen = transpile(qc, basis_gates=gates, optimization_level=3)
print(qc_gen.draw('text'))


# Simulamos
qc_gen.save_statevector()
sim= AerSimulator(method='statevector')

sv_res= sim.run(qc_gen, shots=1).result().get_statevector()

# Calculamos fidelidad
f= state_fidelity(sv, sv_res)
print('Fidelidad entre estados: ', f)
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir cada número complejo según su forma
z1 = -1+np.sqrt(3)*1j # z1: Forma binómica directa

theta_z2 = 2 * np.pi / 3
z2 = 2*(np.cos(theta_z2)+1j * np.sin(theta_z2)) # z2: A partir de su forma polar (módulo y argumento)

z3 = 2*(np.cos(2*np.pi/3) + 1j*np.sin(2*np.pi/3)) # z3: A partir de su forma trigonométrica

z4 = 2*np.exp(1j*2*np.pi/3) # z4: A partir de su forma exponencial (Fórmula de Euler)

# Agrupar los números en un array de NumPy
num = np.array([z1, z2, z3, z4])

# Imprimir la forma binómica de cada uno para verificación visual
print("Formas binómicas calculadas:")
for i, z in enumerate(num, 1):
    print("z{}: {}".format(i, z))
print("-" * 30)


# Comparación 
for i in range(len(num)-1):
    for j in range(i+1, len(num)):
        comp= np.isclose(num[i], num[j])
        print('z{} y z{} son iguales: {}'.format(i, j, comp))

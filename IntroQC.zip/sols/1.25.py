"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir la matriz hermítica Z
Z = np.array([
    [1, 0],
    [0, -1]
])

# Definir el vector columna v
v = np.array([
    [1 / np.sqrt(2)],
    [1j / np.sqrt(2)]
])

# Calcular la traspuesta conjugada de v (v-dagger)
v_dagger = np.conjugate(v).T

# Calcular el valor E = v† * Z * v
E = v_dagger @ Z @ v

# Mostrar los resultados
result = E.squeeze().item()

print("Vector v:\n", v)
print("\nMatriz Z:\n", Z)
print("\nValor calculado de E = v† Z v: {}".format(result))
print("Parte imaginaria de E: {}".format(result.imag))


# Comprobación final
if np.isclose(result.imag, 0):
    print("El resultado E es un número real, como se esperaba.")
else:
    print("El resultado E no es un número real.")
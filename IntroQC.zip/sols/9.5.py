"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram



def Oracle():
    qc= QuantumCircuit(3)
    qc.ccx(0, 1, 2)
    return qc.to_instruction()


def Diffuser():
    qc= QuantumCircuit(2)
    qc.h([0,1])
    qc.x([0,1])
    qc.cz(0, 1)
    qc.x([0,1])
    qc.h([0,1])
    return qc.to_instruction()


qc= QuantumCircuit(3, 2)
qc.h([0,1])
qc.append(Oracle(), [0, 1, 2])
qc.append(Diffuser(), [0, 1])
qc.measure([0, 1], [0, 1])


# Simulacion
n_shots= 2048
sim= AerSimulator()
counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()
for k in counts:
    print(k[::-1], ':', counts[k]/n_shots)
display(plot_histogram(counts))
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator
import numpy as np

data= [[0,0,1],
       [0,1,0],
       [1,0,0],
       [1,1,1]]

# Preparación de estados
par= ParameterVector(name='param', length=2)
qc_prep= QuantumCircuit(1)
qc_prep.h(0)
qc_prep.rz(par[0]*np.pi, 0)
qc_prep.rz(par[1]*np.pi, 0)


# Ansatz
qc_ans= QuantumCircuit(1)
qc_ans.h(0)
qc_ans.x(0)

qc= qc_prep.compose(qc_ans)
qc.measure_all()
sim= AerSimulator()

for row in data:
    X, y= row[:2], row[2]
    
    qct= transpile(qc.assign_parameters({par : X}))
    ket= list(sim.run(qct, shots=1).result().get_counts().keys())[0]
    iket= int(ket)
    print('Para las entradas X={} devuelve {} y debería devolver {}'.format(X, iket, y))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import re
import numpy as np
from itertools import product
from pyqubo import Array
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit.quantum_info import SparsePauliOp
from qiskit import transpile
from qiskit_aer import AerSimulator
from scipy.optimize import minimize


####################################
# Funciones de OptimizationTools.py
####################################

# Para un Array z de PyQUBO, la funcion genera un diccionario 
# con los nombres de variables (clave) y un indice unico (valor entero)
def getVarIndices(z : Array):
    
    # Obtenemos todos los indices de las soluciones en z
    indices= [list(range(i)) for i in z.shape]
    z_idx= list(product(*indices)) 
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    var_ind= {} # Generamos diccionario (nombre de variable : indice entero)
    for i, ind in enumerate(z_idx):
        
        # Elimina prefijo Spin(' y postfijo ')
        name= str(z[tuple(ind.tolist())])[6:-2]
        var_ind[name]= i # Asignamos nombre de variable a indice
    return var_ind




# Transforma un modelo Ising a una secuencia de operadores de Pauli
def IsingToPauli(z, ising, show=False, to_little_endian= False):
    
    var_idx= getVarIndices(z) # Asignamos cada variable en z a un indice entero
    n= np.prod(z.shape) # Numero de qubits necesarios
    
    seq= [] # Secuencia de operadores de Pauli
    for ising_elm in ising:
        if not isinstance(ising_elm, float): # Omitimos termino independiente
            for ZiZj in ising_elm: # Iteramos sobre variables Zi o ZiZj
                
                # Creamos representacion str de operaciones ID sobre cada qubit
                pauli_tensor= ['I']*n 
                
                # Obtenemos variables Zi o ZiZj involucradas en el termino ZiZj
                var= (ZiZj,) if not isinstance(ZiZj, tuple) else ZiZj
                for zi in var: # Iteramos sobre ellas
                    idx= var_idx[zi] # Obtenemos el indice asignado a la variable
                    pauli_tensor[idx]= 'Z' # Aplicamos operacion Z sobre el qubit de la variable
                coef= ising_elm[ZiZj] # Obtenemos coeficiente multiplicador Jij * ZiZj
                
                # Pasamos lista pauli_tensor a cadena
                str_pauli= ''.join(var for var in pauli_tensor)
                if to_little_endian:
                    str_pauli= str_pauli[::-1]
                
                # Insertamos el par (str_pauli, coef) en la secuencia de operadores de Pauli
                seq.append( (str_pauli, coef) )
    if show:
        print('Lista de operadores de Pauli de H_P: {}'.format(seq))
    return SparsePauliOp.from_list(seq) # devolvemos seq como secuencia de operadores de Pauli


# Para una solucion binaria x=(x0, x1, ...) donde xi tiene valores 0/1, y dada
# una secuencia de operadores de Pauli H_P, la funcion devuelve la energia de la solucion
def energy_classic(x: np.ndarray, H_P : SparsePauliOp):
    
    z_spin= (2*x-1) # Movemos x al conjunto {-1, 1}
    Hz= 0 # Evaluamos H(z) inicializada a 0
    for pauli_op in H_P: # Iteramos sobre todos los operadores de Pauli
    
        # Obtenemos coeficiente asociado al operador de Pauli (numero real)
        coef= float(pauli_op.coeffs.squeeze().real)
        
        # Obtenemos cadena con la representacion de las puertas que conforman el operador
        gates= str( pauli_op.paulis[0] )
        
        # Obtenemos lista con las posiciones donde se encuentra la puerta Z
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Buscamos las posiciones del operador Z
            Zlist.append(z_pos.start())
        
        # Actualizacion de funcion de energia
        Hz+= coef*np.prod(z_spin[ Zlist ])
    return Hz


# Calcula el valor de la esperanza de <x|H_P|x> a partir
# de las mediciones dadas en counts por la ejecucion del circuito
def ExpVal_from_counts(counts : dict, H_P: SparsePauliOp, reverse_ket= False):
    N= 0
    expval= 0
    for ket in counts:
        num_meas= counts[ket]
        N+= num_meas
        ket_rev= ket[::-1] if reverse_ket else ket
        ket_arr= np.array([int(xi) for xi in ket_rev])
        fx= energy_classic(ket_arr, H_P)
        expval+= fx*num_meas
    return expval/N


# Prepara la ejecucion de un circuito de optimizacion
# qaoa_circ con params valores de parametros para gamma y beta,
# usando el simulador sim con shots ejecuciones del circuito
# Devuelve la esperanza del observable implementado en qaoa_circ
def run_circuit_expectation(params, qaoa_circ, sim, shots, H_P, reverse_ket= False):
    qc= qaoa_circ.assign_parameters(params)
    counts= sim.run(transpile(qc, sim), shots= shots).result().get_counts()
    return ExpVal_from_counts(counts, H_P, reverse_ket)



# Obtiene la mejor (mas probable) solucion a un problema
# dadas las mediciones realizadas en counts
def getBestSolution(counts, to_big_endian= True):
    maxVal= 0
    bestket= None
    for ket in counts: # Buscamos el ket de maxima probabilidad de medicion
        if counts[ket] > maxVal:
            maxVal= counts[ket]
            bestket= ket
    return bestket[::-1] if to_big_endian else bestket


# Construccion del circuito del exponencial del modelo Ising
# con parametro t
def ProblemCircuit(pauli : SparsePauliOp, t : float, reverse_ops : bool= False):
    
    # Generamos circuito
    n_qubits= pauli.num_qubits
    qc_problem= QuantumCircuit(n_qubits)
    
    # Oteramos sobre cada operador de pauli    
    for oper in pauli:
        
        # Obtenemos coeficiente 
        coef= float(oper.coeffs.squeeze().real) 
        
        # Obtenemos las matrices de pauli como cadena
        gates= str(oper.paulis[0])[::-1] if reverse_ops else str(oper.paulis[0])
        
        # Obtenemos posiciones de los qubits donde se realizan las puertas Z
        # Obtenemos lista con las posiciones donde se encuentra la puerta Z
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Buscamos las posiciones del operador Z
            Zlist.append(z_pos.start())
            
        if len(Zlist)==1: # Unica operacion Rz sobre un qubit
            qc_problem.rz(2*coef*t, Zlist[0])
        else: # Operacion Rzz sobre dos qubits
            qc_problem.rzz(2*coef*t, Zlist[0], Zlist[1])
        
    return qc_problem


# Creacion del circuito Mixer de QAOA con parametro beta
def MixerCircuit(n_qubits, beta):
    qc_mixer= QuantumCircuit(n_qubits) # Creacion del circuito
    qc_mixer.rx(2*beta, range(n_qubits)) # Inclusion de puertas Rx parametrizadas
    return qc_mixer


# Construccion del circuito de QAOA para el problema ising dado por la 
#  secuencia de operadores de pauli con L capas
def QAOAcirc(L : int, pauli : SparsePauliOp):
    
    # Generacion de parametros gamma/beta
    n_qubits= pauli.num_qubits
    gamma= ParameterVector(length= L, name='gamma')
    beta= ParameterVector(length= L, name= 'beta')
    
    # Creacion del circuito: superposicion 
    qc= QuantumCircuit(n_qubits)
    qc.h(range(n_qubits))
    
    # L capas de hamiltoniano+mixer
    for l in range(L):
        qc= qc.compose(ProblemCircuit(pauli, gamma[l]))
        qc= qc.compose(MixerCircuit(n_qubits, beta[l]))
    qc.measure_all()
    return gamma, beta, qc

####################################
# Solución
####################################



# Generación de la matriz del problema
n=6
M= np.zeros((n,n), dtype=int)
for i in range(n):
    for j in range(n):
        if i!= j:
            M[i][j]= i+j

print('Representacion inicial del problema con la matriz de adyacencia:')
print(M)

# Creacion de variables para el modelo Ising
z = Array.create('z', shape=(len(M),), vartype='SPIN')

# Matriz de coeficientes del problema y formulacion
Ising= 0 # Modelo Ising

# Formulación de función de coste
for i in range(M.shape[0]):
    for j in range(i+1, M.shape[1]):
        if M[i,j] != 0:
            
            # Modelo Ising: Resta M[i,j] sólo si z[i] != z[j], suma en caso contrario
            Ising+= M[i, j]*z[i]*z[j]

model= Ising.compile()
ising= model.to_ising()

print('\nModelo Ising:')
for coefs in ising:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])


# Transformacion de modelo Ising a secuencia de operadores de Pauli
pauli= IsingToPauli(z, ising, to_little_endian= False)

# Creacion del circuito QAOA con L capas y shots mediciones
L= 1
shots= 20000
gamma, beta, qaoa_circ= QAOAcirc(L, pauli)

# Preparacion del simulador y la funcion a ser optimizada
sim= AerSimulator()
to_be_minimized= lambda params : run_circuit_expectation(params, qaoa_circ, sim, shots, pauli)


# Parametros iniciales para beta y gamma
params_init= np.zeros(2*L) #np.random.rand(2*L) 

# Optimizacion de gamma y beta con COBYLA
params = minimize(to_be_minimized,
               params_init,
               method='COBYLA').x

print('\nMejores parametros: {}'.format(params))

# Ejecucion del circuito QAOA con los mejores parametros
res_circ= qaoa_circ.assign_parameters(params)
counts = sim.run(transpile(res_circ, sim), shots= shots).result().get_counts()


# Obtencion de la mejor solucion
solution_bin= getBestSolution(counts)
x= np.array([int(xi) for xi in solution_bin])
cost= energy_classic(x, pauli)

print('Mejor solucion encontrada (binario): {} con coste energia={}'.format(x, cost))



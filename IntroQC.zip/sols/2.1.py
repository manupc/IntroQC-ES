"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generacion de los estados
ls= [ # Lista de estados
      Statevector([np.exp(2*np.pi*1j), 0]),
      Statevector([np.sqrt(2)/2, 1j*np.sqrt(2)/2]),
      Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
      Statevector([np.sqrt(2)/2, np.sqrt(2)/2]),
      Statevector([0, np.exp(2*np.pi*1j)]),
      Statevector([1/np.sqrt(2), -1j/np.sqrt(2)])
    ]

# Vectores de la base computacional
ket0= Statevector([1, 0])
ket1= Statevector([0, 1])

# Iteramos sobre todos los estados
for ket in ls:
    print('-'*10)
    print('Estado {}'.format(ket))
    print('Validez : {}'.format(ket.is_valid()))
    
    # Comparacion con base computacional
    isket0= ket == ket0
    isket1= ket == ket1
    
    if isket0:
        print('Equivale a |0>')
    elif isket1:
        print('Equivale a |1>')
    else:
        print('Estado de superposición no estándar')
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from itertools import product


###########################################################
# METODO DE FUERZA BRUTA 
###########################################################


# Algoritmo exacto por fuerza bruta para encontrar 
# la solucion optima a un problema de optimizacion (minimizacion)
# Como entrada necesita el numero de variables del problema (n), una lista D de
# n listas con los valores posibles de cada variable, una funcion
# constraints_f(x) booleana para verificar que una solucion x al problema cumple
# con las restricciones del mismo (devuelve True) o no (devuelve False), 
# y una funcion de coste cost_f(x) que devuelve el coste de una solucion
# Como salida, devuelve una solucion x optima al problema (np.ndarray)
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx= None # Inicializacion de la solucion optima
    fbx= np.inf # Coste de la solucion optima
    
    all_solutions_generator= product(*D) # Generador de todas las posibles soluciones
    for x in all_solutions_generator:
        
        x= np.array(x)
        
        # Comprobar si x cumple las restricciones
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx= cost_f(x) # Calcular coste de la solucion
        if fx < fbx: # Actualizamos mejor solucion encontrada
            bx, fbx= x, fx
    return np.array(bx)





###########################################################
# METODO DE ENFRIAMIENTO SIMULADO 
###########################################################


# Algoritmo de enfriamiento simulado. Necesita:
#   x_init: Solucion inicial valida al problema
#   cost_f: Funcion de costo cost_f(x)
#   neighbor_f: Funcion de generacion de vecino neighbor_f(x)
#   T_init: Temperatura inicial
#   T_factor: Factor multiplicativo de enfriamiento de la temperatura
#   max_iter: Maximo de iteraciones del algoritmo sin mejora de la mejor solucion
# Devuelve una solucion x al problema (np.ndarray)
def SA_optimizer(x_init : np.ndarray, cost_f : callable, 
                 neighbor_f : callable, T_init : float, T_factor : float, 
                 max_iter : int):
    
    # Inicializacion de parametros
    T= T_init # Temperatura
    x, fx= x_init.copy() , cost_f(x_init) # Solucion actual y coste
    bx, fbx = x.copy(), fx # Mejor solucion encontrada hasta el momento y coste
    
    iter_count= 0 # Contador de numero de iteraciones del algoritmo sin mejora de bx
    while iter_count < max_iter: # Bucle principal
    
        update= False # Para comprobar si hemos actualizado la mejor solucion
    
        # Generar una solucion vecina
        xp= neighbor_f(x) 
        fxp = cost_f(xp)
        
        # Decision sobre la aceptacion de la solucion generada
        f_diff= fxp - fx
        
        # Si la nueva solucion es mejor, la aceptamos siempre.
        # Si es peor, la aceptamos con una probabilidad decreciente (Criterio de Metropolis).
        if f_diff < 0 or np.random.uniform() < np.exp(-f_diff / T):
            x, fx = xp, fxp
            
            # Actualizamos la mejor solucion encontrada hasta ahora si es necesario
            if fx < fbx:
                bx, fbx = x.copy(), fx
                update= True

        # Reiniciamos el contador de iteraciones porque hemos mejorado
        # o lo actualizamos si no es asi
        iter_count= 0 if update else iter_count+1
            
        # Enfriamiento del sistema r el sistema
        T*= T_factor

    return bx


# Funcion para devolver una solucion vecina a la solucion x
# Modifica una componente aleatoria 
def neighbour_generator(x : np.array):

    x_prime= x.copy()
    pos= np.random.randint(low=0, high=len(x), size=2)
    x_prime[pos]= 1-x_prime[pos]
    return x_prime




###########################################################
# FUNCIÓN DE COSTE 
###########################################################


# Procedimiento para implementar la funcion de coste. Tiene como entrada
# la solucion x y el conjunto de números S del problema.
# Como salida, devuelve un valor escalar con la funcion del coste
def f(x : np.ndarray, S : np.ndarray):
    return np.abs( np.sum( S[x==0] ) - np.sum( S[x==1] ) )



# No hay restricciones
check_constraints= None




###################
# Solución con fuerza bruta
###################


# Formulación del problema
S= np.array( [1, 2, 3, 4, 5, 6] , dtype=int)
n= len(S) # Número de nodos (variables)
D= [ list(range(2)) ]*n # Dominios


# Funcion de coste como lambda para ajustar la funcion f al formato del solver
cost_f= lambda x: f(x, S)


# Cálculo de la solución
x= exact_optimizer(n, D, check_constraints, cost_f)

print('El algoritmo de fuerza bruta ha devuelto la solución x={} con coste f(x)={}'.format(x, cost_f(x)))




###################
# Solución con enfriamiento simulado
###################

x_init= np.zeros(n, dtype=int) # Solución inicial, cada nodo un color porque n<K

# Parametros del algoritmo
T_init= 60 # Temperatura inicial
T_factor= 0.9 # Factor de enfriamiento
max_iter= 30

# Llamada al algoritmo de optimizacion
x= SA_optimizer(x_init, cost_f, neighbour_generator, T_init, T_factor, max_iter)


# Mostrar solucion 
print('El algoritmo de enfriamiento simulado ha devuelto la solución x={} con coste f(x)={}'.format(x, cost_f(x)))


"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from itertools import product
import numpy as np


"""
    Supondremos la siguiente tabla de verdad para el cálculo de la función:
        f(0000)= 1000     f(1000)= 1110
        f(0001)= 1100     f(1001)= 1010
        f(0010)= 1010     f(1010)= 1100
        f(0011)= 1110     f(1011)= 1000
        f(0100)= 1001     f(1100)= 1111
        f(0101)= 1101     f(1101)= 1011
        f(0110)= 1011     f(1110)= 1101
        f(0111)= 1111     f(1111)= 1001
"""
def F():
    qc= QuantumCircuit(8) 
    qc.x(4)
    qc.ccx(0, 3, 5, ctrl_state='01'[::-1])
    qc.ccx(0, 3, 5, ctrl_state='10'[::-1])
    qc.ccx(0, 2, 6, ctrl_state='01'[::-1])
    qc.ccx(0, 2, 6, ctrl_state='10'[::-1])
    qc.cx(1, 7)
    return qc


# Instanciacion del simulador
sim= AerSimulator()


n= 4
qc= QuantumCircuit(2*n)
qc.h(range(n))
qc.append(F(), list(range(2*n))) # Insertamos oraculo
qc.h(range(n))
qc.measure_all()

qct= transpile(qc, sim)

print('\nComienza evaluacion de F:')

# Generamos los posibles valores de s
s= set( product( *([[0,1]]*n) ) ) 

# Simulamos circuito
counts= sim.run(qct, shots=2*n).result().get_counts(qct)

for ket in counts:
    k= [int(c) for c in ket[::-1][:n]] # Obtenemos k
        
    # Busqueda por fuerza bruta de los s que hacen s*k=0 mod 2
    s_copy= s.copy()
    for s_val in s_copy:
        if (np.dot(s_val, k)%2 != 0) and (s_val in s):
            s.remove(s_val)
            

s= list(s)
if len(s) > 2:
    print('\tError de calculo')
elif len(s) == 1:
    s='0'*n
else:
    if s[0] == '0'*n:
        s= s[1]
    else:
        s= s[0]
print('Clave secreta: {}'.format(s))
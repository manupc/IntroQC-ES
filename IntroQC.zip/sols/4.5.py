"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
import numpy as np

par= Parameter(name='param')

qc1= QuantumCircuit(1)
qc1.rz(par, 0)
qc1.ry(par, 0)
qc1.save_statevector()


qc2= QuantumCircuit(1)
qc2.ry(par, 0)
qc2.rz(par, 0)
qc2.save_statevector()

value= np.pi/2
qc1= transpile(qc1.assign_parameters({par : value}))
qc2= transpile(qc2.assign_parameters({par : value}))

sim= AerSimulator(method='statevector')
r= sim.run([qc1, qc2], shots=1).result()
sv1= r.get_statevector(qc1)
sv2= r.get_statevector(qc2)

c= sv1.equiv(sv2)
print('Conmutan para par={}: {}'.format(value, c))



"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crear el array de NumPy con los números complejos
c= np.array([1/np.sqrt(2) + 1j/np.sqrt(2), 1/np.sqrt(3) + np.sqrt(2/3)*1j])

# Extraer componentes para las diferentes formas
# Partes real e imaginaria para la forma binómica
re= c.real
im= c.imag

# Módulo y argumento para las formas polar, trigonométrica y exponencial
mod= np.abs(c)
arg_rad = np.angle(c)
arg_deg = np.rad2deg(arg_rad)

# Imprimir los resultados
for i, z in enumerate(c):
    print("Número complejo: {}".format(z))

    # 1. Forma Binómica: a + bi
    print("Forma Binómica: {} + {}i".format(re[i], im[i]))

    # 2. Forma Polar: (r, theta)
    print("Forma Polar: ({}, {}°)".format(mod[i], arg_deg[i]))

    # 3. Forma Trigonométrica: r * (cos(theta) + i * sin(theta))
    print("Forma Trigonométrica: {}*cos({}) + {}*sin({})*i".format(mod[i], arg_rad[i], mod[i], arg_rad[i]))

    # 4. Forma Exponencial: r * e^(i*theta)
    print("Forma Exponencial: {} * e^(i * {})".format(mod[i], arg_rad[i]))
    print("-" * 30)




"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Vector original v
v = np.array([2, 3])
print("Vector original v: {}".format(v))

# Aplicar transformación lineal
vp_1 = 2 * v[0] + 1 * v[1]
vp_2 = 3 * v[1] 

# Crear el vector transformado 
vp = np.array([vp_1, vp_2])
print("Vector transformado v': {}".format(vp))

# Cálculo y aplicación de la función inversa
vr_1 = vp[0]/2 - vp[1]/6
vr_2 = vp[1]/3

# Crear el vector recuperado
vr = np.array([vr_1, vr_2])
print("Vector recuperado después de la transformación inversa: {}".format(vr))

# Verificar si el vector recuperado es esencialmente el mismo que el original
if np.allclose(v, vr):
    print("\n¡Verificación exitosa! El vector original se recuperó correctamente.")
else:
    print("\nAdvertencia: El vector original no se recuperó exactamente. Podría haber problemas de precisión.")
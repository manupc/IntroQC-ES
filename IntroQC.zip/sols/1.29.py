"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definición de Parámetros 

N= 1000000 # N es el número total de puntos aleatorios a generar.
l = 1.0 # Longitud del lado del cuadrado
r = l / 2 # radio del círculo

# Generación de Puntos
pt = np.random.uniform(low=0.0, high=1.0, size=(N,2))

# Comprobación de Puntos Dentro del Círculo
d= np.sum((pt-0.5)**2, axis=1)


# Se cuenta cuántos puntos cumplen la condición de estar dentro del círculo.
circ= np.sum(d <= r**2)

# Aproximación de Probabilidad de dentro del circulo
p= circ / N

# Se despeja pi de la fórmula p = (pi * r^2) / l^2
a_pi= 4*p

# Mostrar Resultados
print("Número total de puntos generados: {}".format(N))
print("Puntos que cayeron dentro del círculo: {}".format(circ))
print("Ratio de puntos (p): {:.4f}".format(p))
print("Aproximación de π: {:.6f}".format(a_pi))


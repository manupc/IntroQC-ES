"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


st= {'00':Statevector.from_label('00'),
     '01':Statevector.from_label('01'),
     '10':Statevector.from_label('10'),
     '11':Statevector.from_label('11')}

qc_2= QuantumCircuit(2)
qc_2.h(0)
qc_2.x(1)
qc_2.cz(0,1)
qc_2.h(0)



sim= AerSimulator(method='statevector')
for sv in st:
    qc= QuantumCircuit(2)
    qc.initialize(st[sv])
    qc= qc.compose(qc_2)
    qc.save_statevector()

    svc= sim.run(transpile(qc, sim), shots=1).result().get_statevector()
    ket= None
    svp= svc.probabilities_dict()
    for k in svp:
        if np.isclose(svp[k], 1):
            ket= k[::-1] # little endian a big endian
    if ket is not None:
        print('Estado inicial: |{}>'.format(sv))
        print('Estado final: |{}>'.format(ket))
        if sv[0] != ket[0]:
            print('\tRETROCESO DE FASE!')
    else:
        print('ERROR AL PROCESAR ', sv)
    

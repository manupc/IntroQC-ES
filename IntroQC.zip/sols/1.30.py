"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt



# Definición de los vectores
ket_a = np.array([0, np.exp(1j * np.pi)])  # [0, -1]
ket_b = (1/np.sqrt(2)) * np.array([1, 1j])
ket_c = np.array([np.sqrt(0.25), np.sqrt(0.75)])

kets= [ket_a, ket_b, ket_c]

# Muestras a generar
N= 1000

# Ejecución del análisis para cada vector 
for ket in kets:
    
    print('-'*10)
    print('Experimentos sobre {}'.format(ket))
    
    # Calcular la distribución de probabilidad teórica
    possible = [0, 1] # Representando |0> y |1>
    p = np.abs(ket)**2
    print('Distribución de probabilidad teórica:')
    for val, prob in zip(possible, p):
        print('\tp(X=|{}>) = {}'.format(val, prob))


    # Generar N muestras de la variable aleatoria 
    samples = np.random.choice(possible,  size=N, p=p)
    
    # Calcular la frecuencia de los resultados del muestreo
    (results, counts) = np.unique(samples, return_counts=True)

    # Asegurarse de que ambos resultados (0 y 1) están presentes para el gráfico
    estimated_counts = np.zeros(2)
    for i, res in enumerate(results):
        estimated_counts[res] = counts[i]
        
    distribution_approx = estimated_counts / N


    print('Distribución de probabilidad empírica:')
    for r, c in zip(results, estimated_counts):
        print('\tp(X=|{}>) = {}'.format(r, c/N))



    # Crear un histograma con Matplotlib 
    

    # Configuración del gráfico de barras
    labels = ['|0>', '|1>']
    x = np.arange(len(labels))
    width = 0.35

    fig, ax = plt.subplots(figsize=(8, 6))
    rects1 = ax.bar(x - width/2, p, width, label='Teórica')
    rects2 = ax.bar(x + width/2, distribution_approx, width, label=f'Estimada (N={N})')

    # Añadir títulos y etiquetas
    ax.set_ylabel('Probabilidad')
    ax.set_title('Distribución de Probabilidad para el vector {}'.format(ket))
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    ax.set_ylim(0, 1.1)

    # Añadir etiquetas de valor sobre las barras
    ax.bar_label(rects1, padding=3, fmt='%.2f')
    ax.bar_label(rects2, padding=3, fmt='%.2f')

    fig.tight_layout()
    plt.show()
    


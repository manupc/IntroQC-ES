"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crear array
a= np.array([25, 30, 22, 35, 28])

# Calcular el promedio, el minimo y el maximo
avg_a, min_a, max_a= np.mean(a), np.min(a), np.max(a)

# Imprimir los resultados
print("El array de edades es: {}".format(a))
print("La edad promedio es: {:.2f}".format(avg_a))
print("Las edades mínima y máxima son: {} y {}".format(min_a, max_a))
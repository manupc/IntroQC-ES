"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Crear ángulos
x= np.linspace(0, np.pi, 10)

# Calcula el seno y el coseno
s = np.sin(x)
c = np.cos(x)

# Eleva al cuadrado
s2 = s**2
c2 = c**2

# Suma los elementos de la identidad
I= s2 + c2

# Imprime por consola los resultados
print("Valores de x: {}".format(x))
print("Resultados de sin^2(x) + cos^2(x): {}".format(I))

# ¿Son todos los valores cercanos a 1?
V= np.allclose(I, 1)
print("¿Son todos los valores muy cercanos a 1? : {}".format(V))

"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Matriz de transformación T del ejercicio anterior
T = np.array([[3, -1],
              [2, 5]])

# Vector original v del ejercicio anterior
v = np.array([5, 2])

# Vector transformado v_prima del ejercicio anterior (T @ v)
# Aseguramos que v_prima se calcula aquí por si este script se ejecuta de forma independiente
vp = T @ v

print("Vector original (v): {}".format(v))
print("Matriz de transformación (T):\n", T)
print("\nVector transformado (v'): {}".format(vp))

# Calcular la inversa de T 
try:
    Tinv = np.linalg.inv(T)
    print("\nMatriz inversa de T (T^(-1)):\n", Tinv)

    # Aplicar la transformación inversa a vp
    vr = Tinv @ vp
    print("\nVector recuperado (vr): {}".format(vr))

    # Verificar si el vector recuperado es el original
    if np.allclose(v, vr):
        print("\nEl vector original se recuperó correctamente.")
    else:
        print("\nEl vector original NO se recuperó exactamente. Puede haber problemas de precisión.")

except:
    print("\nError: La matriz T no es invertible (su determinante es cero).")
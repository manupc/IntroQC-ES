"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, Pauli


qc= QuantumCircuit(3, 1)

# Codificacion de datos
qc.x(1)

# Test
qc.h(0)
qc.cz(0, 1)
qc.cx(0, 2)
qc.h(0)
qc.measure(0, 0)



# Simulacion
n_shots= 2048
sim= AerSimulator()
counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()

# Aproximacion de <psi|Z|psi>
prob_0s= counts['0']/n_shots if '0' in counts else 0
prob_1s= counts['1']/n_shots if '1' in counts else 0

exp_val_0s= 2*prob_0s-1
exp_val_1s= -(2*prob_1s-1)
exp_val= (exp_val_0s + exp_val_1s)/2
print('La esperanza calculada del observable <10|ZX|10> es: {}'.format(exp_val))

# Valor real
# Estado inicial
sv0= Statevector.from_label('010')
exp_val_real= sv0.expectation_value(Pauli('ZX'[::-1]))
print('El valor real de <10|ZX|10> es: {}'.format(exp_val_real))
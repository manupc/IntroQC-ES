"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit.circuit.library import XGate
import numpy as np


# Circuito encoder
qce= QuantumCircuit(4+2, 2)

# codificar 0100
gate= XGate().control(num_ctrl_qubits=4, ctrl_state='0100'[::-1])
qce.append(gate, [0,1,2,3,5])

# codificar 0010
gate= XGate().control(num_ctrl_qubits=4, ctrl_state='0010'[::-1])
qce.append(gate, [0,1,2,3,4])

# codificar 0001
gate= XGate().control(num_ctrl_qubits=4, ctrl_state='0001'[::-1])
qce.append(gate, [0,1,2,3,4])
qce.append(gate, [0,1,2,3,5])
qce.measure([4, 5], [0, 1]) 

# Simulacion
lst= ['100000', '010000', '001000', '000100']
sim= AerSimulator()
for str_sv in lst:
    sv= Statevector.from_label(str_sv[::-1]) # Gestión de little endian
    qc_prep= QuantumCircuit(4+2, 2)
    qc_prep.initialize(sv)
    
    qc= transpile(qc_prep.compose(qce), sim)
    result= list(sim.run(qc, shots=1).result().get_counts().keys())[0][::-1] # gestión de little endian
    
    print('{} se codifica como {}'.format(str_sv[:-2], result))
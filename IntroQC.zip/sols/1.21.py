"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir la matriz H
H= (1 / np.sqrt(2)) * np.array([
    [1, 1],
    [1, -1]
])

# Calcular la traspuesta conjugada (adjunta hermítica) de H
H_dagger= np.conjugate(H).T

# Multiplicar la adjunta por la matriz original
prod= H_dagger@H

# Comprobar si el resultado es la matriz identidad
I = np.identity(2)
unitary= np.allclose(prod, I)

# Mostrar los resultados
print("Matriz H:\n", H)
print("\nProducto H† * H:\n", prod)

if unitary:
    print("La matriz H es unitaria.")
else:
    print("La matriz H NO es unitaria.")
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir el vector original en la base canónica
v= np.array([2, -3])
print("Vector original v (en base canónica): {}".format(v))

# Definir los vectores de la nueva base B
b1= np.array([1, 2])
b2= np.array([3, 1])
print("\nVectores de la nueva base B:")
print("\tb1: {}".format(b1))
print("\tb2: {}".format(b2))

# Construir la matriz de cambio de base P_B_to_E
P_B_to_E= np.array([b1, b2]).T # .T transpone para que b1 y b2 sean columnas
print("\nMatriz de cambio de base P_B_to_E (de B a E):\n{}".format(P_B_to_E))

# Calcular la inversa de P_B_to_E para obtener P_E_to_B
try:
    P_E_to_B= np.linalg.inv(P_B_to_E)
    print("\nMatriz de cambio de base P_E_to_B (de E a B, inversa de P_B_to_E):\n{}".format(P_E_to_B))

    # Calcular las coordenadas del vector v en la nueva base B
    vp= P_E_to_B @ v
    print("\nCoordenadas del vector v en la nueva base B (v'): {}".format(vp))

except:
    print("\nError: La matriz P_B_to_E no es invertible. Los vectores de la base B podrían no ser linealmente independientes.")
"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Generación del problema
S= np.array([1, 2, 3, 4, 5, 6], dtype= int)

print('Representacion inicial del problema:')
print(S)

# Creacion de variables para el modelo QUBO
x = Array.create('x', shape=(len(S),), vartype='BINARY')

# Matriz de coeficientes del problema QUBO y formulacion
Q= 0 # Modelo QUBO

# Formulación de función de coste
for i in range(len(S)):
    # Modelo QUBO: (2*x[i]-1)*S[i] suma S[i] cuando x[i]=1 y resta cuando x[i]=0
    Q+= (2*x[i]-1)*S[i]
Q= Q**2 # Al cuadrado para que la diferencia sea positiva


# Creamos modelo teorico QUBO
model= Q.compile()
qubo, offset= model.to_qubo()
print('\nModelo QUBO:')
for key in qubo:
    print(key, qubo[key])

# Creamos modelo cuadratico binario (BQM)
bqm= model.to_bqm()

# Aplicamos enfriamiento simulado para resolver el problema QUBO
# un total de n_shots veces
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nLas {} soluciones obtenidas: '.format(n_shots))
print(sampleset)

# Obtencion de la mejor solucion
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

solution = np.zeros(len(S), dtype=int)
for var in best_sample_vars:
    for i, x_i in enumerate(x):
        if var in str(x_i):
            solution[i] = best_sample_vars[var]
    
print('\nMejor Solucion: x={} con coste f(x)={}'.format(solution, best_sample_cost))


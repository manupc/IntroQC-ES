"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definir la matriz de transformación T
T= np.array([[3, -1],
              [2, 5]])

# Definir el vector original v
v= np.array([5, 2])

# Aplicar la transformación lineal: vp = T @ v
# El operador '@' realiza la multiplicación de matrices en NumPy
vp= T @ v

# Mostrar los resultados
print("Vector original (v): {}".format(v))

print("\nMatriz de transformación (T):")
print(T)

print("\nVector transformado (v'): {}".format(vp))


